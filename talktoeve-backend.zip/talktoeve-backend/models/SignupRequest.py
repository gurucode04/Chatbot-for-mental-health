from pydantic import BaseModel, EmailStr

class SignupRequest(BaseModel):
    user_name: str
    email: EmailStr
    password: str
    token : str