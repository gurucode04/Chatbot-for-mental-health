from pydantic import BaseModel, EmailStr
from typing import Union

class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    model_name: Union[str, None] = None 
