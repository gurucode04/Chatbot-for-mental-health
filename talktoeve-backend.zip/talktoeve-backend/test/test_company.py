import asyncio
from datetime import datetime
from db.schema.Company import Company
from db.session import get_db, AsyncSessionLocal
from db.GenericAccessProvider import GenericAccessProvider
from db.services.CompanyServiceProvider import CompanyServiceProvider

class TestCompanyServiceProvider:
    def __init__(self):
        # Create an event loop
        self.loop = asyncio.get_event_loop()

    async def setup(self):
        # Create a new database session
        self.db_session = AsyncSessionLocal()

        # Create the access provider and service provider
        self.company_access_provider = GenericAccessProvider(Company, self.db_session)
        self.company_service = CompanyServiceProvider(self.company_access_provider)

    async def teardown(self):
        # Close the database session
        await self.db_session.close()

    async def test_add_dummy_company(self):
        # Set up the test
        await self.setup()

        try:
            # Define the dummy company data
            dummy_data = {
                "company_name": "Dummy Company",
                "email": "dummy@company.com",
                "phone": "123-456-7890",
                "street": "123 Dummy Street",
                "city": "Dummytown",
                "postal_code": "12345",
                "country": "Dummyland",
                "registration_number": "DUMMY12345",
                "tax_identification_number": "TAXDUMMY123",
                "vat_number": "VATDUMMY123",
                "industry_type": "Dummy Industry",
                "legal_form": "LLC",
                "incorporation_date": datetime.utcnow(),
                "number_of_employees": 10,
                "annual_revenue": 1000000.00,
                "website_url": "https://dummycompany.com",
                "status": "pending"
            }

            # Add the dummy company using the service provider
            new_company = await self.company_service.add_row(dummy_data)

            # Check if the company was added successfully
            if new_company and new_company.company_name == "Dummy Company":
                print("Test Passed: Dummy company added successfully")
            else:
                print("Test Failed: Dummy company was not added successfully")

        except Exception as e:
            print(f"Test Failed: Exception occurred - {e}")
        finally:
            # Tear down the test
            await self.teardown()

    def run_tests(self):
        self.loop.run_until_complete(self.test_add_dummy_company())

if __name__ == "__main__":
    # Create an instance of the test class
    test_instance = TestCompanyServiceProvider()

    # Run the tests
    test_instance.run_tests()
