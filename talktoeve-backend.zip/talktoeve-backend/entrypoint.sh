#!/bin/sh

# Start SSH service
service ssh start

if [ "$RUN_TESTS" -eq 1 ]; then
    exec pytest

elif [ "$LOCAL" -eq 1 ]; then
    exec uvicorn main:app --host 0.0.0.0 --port 8000

else
    exec uvicorn main:app --host 0.0.0.0 --port 8000
    
fi
