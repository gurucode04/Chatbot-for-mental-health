import requests  
import json  
  
# Replace these with your Azure OpenAI endpoint and API key  
endpoint = "https://dev-test-2.openai.azure.com/"  
api_key = "7535acae5fe648208168aa9e5f29f83b"  
  
# The deployment name of your model, which you set up in Azure  
deployment_name = "dev-test-2"  
  
# Endpoint URL for the chat completion  
url = f"{endpoint}openai/deployments/{deployment_name}/completions?api-version=2022-12-01"  
  
# Set up headers for the request  
headers = {  
    "Content-Type": "application/json",  
    "api-key": api_key,  
}  
  
def generate_response(prompt):  
    # Set up the data for the request  
    data = {  
        "prompt": prompt,  
        "max_tokens": 150,  
        "temperature": 0.7,  
        "top_p": 1.0,  
        "n": 1,  
        "stop": None,  
    }  
  
    # Make the POST request to the Azure OpenAI endpoint  
    response = requests.post(url, headers=headers, json=data)  
  
    if response.status_code == 200:  
        response_data = response.json()  
        return response_data["choices"][0]["text"].strip()  
    else:  
        return f"Error: {response.status_code} - {response.text}"  
  
# Simple chat loop  
def chat():  
    print("Welcome to the Azure OpenAI Chat! Type 'exit' to quit.")  
    while True:  
        user_input = input("You: ")  
        if user_input.lower() == "exit":  
            break  
        bot_response = generate_response(user_input)  
        print(f"Bot: {bot_response}")  
  
if __name__ == "__main__":  
    chat()  
