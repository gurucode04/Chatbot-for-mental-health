import urllib.request
import json
import os

# import ssl

# def allowSelfSignedHttps(allowed):
#     # bypass the server certificate verification on client side
#     if allowed and not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None):
#         ssl._create_default_https_context = ssl._create_unverified_context

# allowSelfSignedHttps(True) # this line is needed if you use self-signed certificate in your scoring service.

class GeneralChat:
    def __init__(self):
        self.url = os.getenv("AZURE_GEN_CHAT_URL")
        self.api_key = os.getenv("AZURE_GEN_CHAT_KEY")
        self.headers = {'Content-Type': 'application/json', 'Authorization': f'Bearer {self.api_key}'}

    def ask_question(self, question, chat_history, summary=None):
        if not self.api_key:
            raise Exception("A key should be provided to invoke the endpoint")

        data = {"chat_history": chat_history, "question": question, "summary": summary}
        body = str.encode(json.dumps(data))

        req = urllib.request.Request(self.url, body, self.headers)

        try:
            response = urllib.request.urlopen(req)
            result = response.read()
            return json.loads(result)
        except urllib.error.HTTPError as error:
            print(f"The request failed with status code: {error.code}")
            print(error.info())
            print(error.read().decode("utf8", 'ignore'))
            return None

