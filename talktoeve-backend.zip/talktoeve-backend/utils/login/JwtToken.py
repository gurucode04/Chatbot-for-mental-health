import jwt
import datetime

access_token_expiry = 1440
refresh_token_expiry = 1440
admin_token_expiry = 1440

secret = "key_secret"
algorithm = "HS256"

def get_token(payload):
    token = jwt.encode(payload, secret, algorithm)
    if isinstance(token, str):
        return token
    return str(token)[2:-1]

def get_token_values(token):
    return jwt.decode(token.encode(), secret, algorithms=[algorithm])

def verify_token(token, type="access_token"):
    if token:
        try:
            if token.startswith("Bearer "):
                token = token.split(" ")[1]

            decoded = get_token_values(token)
            if decoded.get("type") == type:
                return True, decoded
            else:
                return False, "You are not Authorized"

        except jwt.ExpiredSignatureError:
            return False, "Expired Token"
        except Exception as e:
            return False, str(e)
    else:
        return False, "You are not Authorized"
