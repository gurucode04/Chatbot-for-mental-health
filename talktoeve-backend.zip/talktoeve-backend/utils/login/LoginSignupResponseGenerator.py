import datetime
from utils.login.JwtToken import get_token
from utils.login.JwtToken import access_token_expiry, refresh_token_expiry
from typing import Dict


class LoginSignupResponseGenerator:
    @staticmethod
    async def get_tokens(user_id: int, company_id: int, role: str) -> Dict[str, str]:
        access_token = get_token(
            {"type": "access_token", "user_id": user_id, "company_id": company_id,"role": role,
             "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=access_token_expiry)}
        )
        refresh_token = get_token(
            {"type": "refresh_token", "user_id": user_id, "company_id": company_id,
             "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=refresh_token_expiry)}
        )

        return {"access_token": access_token,"refresh_token": refresh_token}
