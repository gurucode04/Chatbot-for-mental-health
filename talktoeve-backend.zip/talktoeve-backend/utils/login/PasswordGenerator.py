import hashlib
from passlib.hash import pbkdf2_sha256

class PasswordGenerator:
    def __init__(self):
        self.pbkdf2_prefix = "$pbkdf2-sha256$1000$"

    def encrypt(self, password):
        hashed_password = hashlib.md5(password.encode()).hexdigest()  # Entered password
        encrypted_pwd = pbkdf2_sha256.hash(hashed_password, rounds=1000, salt_size=8).replace(self.pbkdf2_prefix, "")
        return encrypted_pwd

    def verify(self, entered_password, encrypted_password):
        hashed_password = hashlib.md5(entered_password.encode()).hexdigest()  # Entered password
        encrypted_password = f"{self.pbkdf2_prefix}{encrypted_password}"
        return pbkdf2_sha256.verify(hashed_password, encrypted_password)

# if __name__ == "__main__":
#     password_generator = PasswordGenerator()
#     print(password_generator.encrypt("admin@eve"))
#     print(password_generator.verify("admin@eve", "kpKy1vqfkxI$OHbeNUcB2e/ZPcToYv4YMI4OoSjt.UY0Kb0dcToOHL8"))