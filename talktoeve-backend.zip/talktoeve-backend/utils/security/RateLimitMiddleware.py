from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from collections import defaultdict, deque
from time import time
from utils.logger import setup_logger
import asyncio
import threading

logger = setup_logger()

class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, dispatch=None):
        super().__init__(app, dispatch)
        self.requests_per_second = defaultdict(lambda: deque())
        self.requests_per_minute = defaultdict(lambda: deque())
        self.lock = threading.Lock()
        self.max_requests_per_second = 20
        self.max_requests_per_minute = 100

    async def dispatch(self, request: Request, call_next):
        client_ip = request.client.host
        current_time = time()
        logger.info(f"Requests per second: {self.requests_per_second[client_ip]}")
        logger.info(f"Requests per minute: {self.requests_per_minute[client_ip]}")
        with self.lock:
            # Clean up old requests
            self._cleanup_requests(self.requests_per_second[client_ip], 1)
            self._cleanup_requests(self.requests_per_minute[client_ip], 60)

            # Check request limits
            if len(self.requests_per_second[client_ip]) >= self.max_requests_per_second:
                logger.error(f"Rate limit exceeded for {client_ip}")
                return Response(content=f"Rate limit exceeded: {self.max_requests_per_second} requests per second", status_code=429)
            
            if len(self.requests_per_minute[client_ip]) >= self.max_requests_per_minute:
                return Response(content=f"Rate limit exceeded: {self.max_requests_per_minute} requests per minute", status_code=429)

            # Log the current request
            self.requests_per_second[client_ip].append(current_time)
            self.requests_per_minute[client_ip].append(current_time)
        
        response = await call_next(request)
        return response

    def _cleanup_requests(self, requests_deque, time_frame):
        while requests_deque and requests_deque[0] < time() - time_frame:
            requests_deque.popleft()