from fastapi import Request, HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from db.session import get_db
from db.schema.User import User
from utils.login.JwtToken import verify_token
import time
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

class TokenVerifier:
    def __init__(self):
        pass

    async def verify_token_general(self,token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)):
        if token:
            print(f"Token in verify_token_general: {token}")
            is_valid, result = verify_token(token)
            if is_valid:
                    return await self._get_user_details(result,db)
            else:
                raise HTTPException(status_code=403, detail="Forbidden: Invalid Token")
        else:
            raise HTTPException(status_code=401, detail="Unauthorized: No token provided, Please Login Again.")

    async def verify_super_admin(self,token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)):
        if token:
            print(f"Token in verify_super_admin: {token}")
            is_valid, result = verify_token(token)
            if is_valid:
                if result.get('role') == 'super_admin':
                    return await self._get_user_details(result,db)
                else:
                    raise HTTPException(status_code=403, detail="Forbidden: Insufficient permissions")
            else:
                raise HTTPException(status_code=401, detail="Unauthorized: Invalid Token")
        else:
            raise HTTPException(status_code=401, detail="Unauthorized: No token provided, Please Login Again.")

    async def verify_company_admin(self,token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)):
        if token:
            is_valid, result = verify_token(token)
            if is_valid:
                if result.get('role') in ['company_admin','super_admin'] :
                    return await self._get_user_details(result,db)
                else:
                    raise HTTPException(status_code=403, detail="Forbidden: Insufficient permissions")
            else:
                raise HTTPException(status_code=401, detail="Unauthorized: Invalid Token")
        else:
            raise HTTPException(status_code=401, detail="Unauthorized: No token provided, Please Login Again.")

    async def verify_employee(self,token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)):
        start = time.time()
        if token:
            is_valid, result = verify_token(token)
            if is_valid:
                if result.get('role') in ['employee','company_admin','super_admin'] :
                    end = time.time()
                    print(f"Time taken to verify token: {end-start}")
                    return await self._get_user_details(result,db)
                else:
                    raise HTTPException(status_code=403, detail="Forbidden: Insufficient permissions")
            else:
                raise HTTPException(status_code=401, detail="Unauthorized: Invalid Token")
        else:
            raise HTTPException(status_code=401, detail="Unauthorized: No token provided, Please Login Again.")

    async def _get_user_details(self, result,db):
        user_id = result.get('user_id')
        user = await db.execute(select(User).where(User.id == user_id))
        user_details = user.scalar()
        if not user_details:
            raise HTTPException(status_code=401, detail="Unauthorized: User does not exist")
        elif not user_details.is_active:
            raise HTTPException(status_code=401, detail="Unauthorized: User is not active")
        return user_details, result

