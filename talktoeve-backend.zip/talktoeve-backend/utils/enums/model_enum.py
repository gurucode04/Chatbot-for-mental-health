from enum import Enum

class OpenaiModelNames(Enum):
    GPT4O = 'gpt-4o'
    GPT4MINI = 'gpt-4o-mini'
    GPT4 = 'gpt-4-turbo'