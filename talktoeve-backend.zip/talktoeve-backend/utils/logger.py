import logging
import os

def setup_logger():
    # Create a logger object
    logger = logging.getLogger("fastapi")
    logger.setLevel(logging.INFO)

    # Create file handler which logs even debug messages
    if not os.path.exists('logs'):
        os.makedirs('logs')
    fh = logging.FileHandler('logs/app.log')

    # Create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)

    # Add the handlers to the logger
    logger.addHandler(fh)

    return logger
