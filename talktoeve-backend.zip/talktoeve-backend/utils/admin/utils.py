from cryptography.fernet import Fernet
import json

# Generate a key for encryption and decryption
def generate_key():
    return b'3sEynz9fQ2M1QzBDmdHYjYkuGP3cS46xFtzCVxvS768='

# Function to encrypt data and create a token
def encrypt_data(data, key):
    cipher_suite = Fernet(key)
    token = cipher_suite.encrypt(data.encode())
    return token

# Function to decrypt token
def decrypt_token(token, key):
    cipher_suite = Fernet(key)
    decrypted_data = cipher_suite.decrypt(token).decode()
    return decrypted_data

if __name__ == "__main__":
    token = "gAAAAABmbdQ4kihkEvSB-26tnVPSCIhaVXhWys_uVCMmV-y-NovYe27xuII5pJoPLz4N_R1tBilzLiVcHci-sz2wIjrRtoiYAag62CpJrYMEyl1_JPXews9AVgW9lbquj0zFbeB07RAL66TH-lgf4K5uH_Bw4RcB4fQBhuIMPciJ0vKobsrj7VM="
    try:
        decrypted_data = decrypt_token(token, generate_key()).replace("'","\"")#.replace("b'", "").replace("'", ""))
        print("Decrypted Data:", decrypted_data)  # Check what the decrypted data looks like
        data = json.loads(decrypted_data)
        print(data)
        print(data.get("email"))
    except json.JSONDecodeError as e:
        print("Failed to decode JSON:", str(e))
    except Exception as e:
        print("An error occurred:", str(e))
