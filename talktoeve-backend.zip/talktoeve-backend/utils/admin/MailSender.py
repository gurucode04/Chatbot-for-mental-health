import os
import smtplib
from email.message import EmailMessage
from config.settings import settings
from config.constants.mail_costants import HTML_MAIL_TEMPLATE

class MailSender:
    def __init__(self):
        self.email_address = settings.EMAIL_ADDRESS
        self.email_password = settings.EMAIL_PASSWORD
        self.html_mail_template = HTML_MAIL_TEMPLATE

    def create_message(self, recipient: str, subject: str, html_content: str) -> EmailMessage:
        msg = EmailMessage()
        msg['Subject'] = subject
        msg['From'] = self.email_address
        msg['To'] = recipient
        msg.set_content('Invitation mail for Talk To Eve.')
        msg.add_alternative(html_content, subtype='html')
        return msg

    def send_mail(self, recipient: str, subject: str, html_content: str):
        print(self.email_address)
        print(self.email_password)
        msg = self.create_message(recipient, subject, html_content)
        try:
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
                smtp.login(self.email_address, self.email_password)
                smtp.send_message(msg)
            print(f"Mail sent to: {recipient}")
        except Exception as e:
            print(f"Failed to send email to {recipient}. Error: {e}")

# Usage example (Make sure to set your EMAIL_ADDRESS and EMAIL_PASSWORD in environment variables)
if __name__ == "__main__":
    try:
        mail_sender = MailSender()
        html_content = mail_sender.html_mail_template.replace('<paragraph_text>', 'You can Onboard via sign up.') \
                                        .replace('<token_url>', 'https://google.com') \
                                        .replace('<button_text>', 'Signup Now')
        recipient = 'piyushbvaghela641@gmail.com'
        subject = 'Verification Email'
        mail_sender.send_mail(recipient, subject, html_content)
    except Exception as e:
        print(f"Failed to send email. Error: {e}")