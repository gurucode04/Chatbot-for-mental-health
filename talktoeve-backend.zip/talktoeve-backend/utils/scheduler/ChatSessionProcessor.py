from typing import Annotated
from fastapi import Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from db.GenericAccessProvider import GenericAccessProvider
from db.session import get_db
from db.services.ChatMessageServiceProvider import ChatMessageServiceProvider
from db.services.ChatSessionSummariesServiceProvider import ChatSessionSummariesServiceProvider
from db.schema.ChatMessages import ChatMessages  # Assuming this is your ORM model
import asyncio
from db.session import get_db, AsyncSessionLocal


class ChatSessionProcessor:
    def __init__(self,  db: Annotated[AsyncSessionLocal, Depends(get_db)]):
        # Initialize Access Providers and Service Providers
        self.chat_messages_access_provider = GenericAccessProvider(
            ChatMessages, db)
        self.chat_message_service = ChatMessageServiceProvider(
            self.chat_messages_access_provider)

    async def get_session_ids(self) -> list:
        query = """
        WITH LatestSessionPerUser AS (
            SELECT
                user_id,
                session_id,
                created_on
            FROM
                public.chatmessages cm
            WHERE
                created_on = (
                    SELECT MAX(created_on)
                    FROM public.chatmessages
                    WHERE user_id = cm.user_id
                )
        )
        SELECT
            DISTINCT cm.session_id
        FROM
            public.chatmessages cm
        LEFT JOIN
            LatestSessionPerUser lspu ON cm.session_id = lspu.session_id
        LEFT JOIN
            public.chatsessionsummaries css ON cm.session_id = css.session_id
        WHERE
            lspu.session_id IS NULL  -- Exclude the latest session for each user
            AND css.session_id IS NULL;  -- Exclude session IDs already in the summary table
        """
        session_ids = await self.chat_message_service.fetch_all_rows()
        return [row['session_id'] for row in session_ids]

    async def fetch_chats_for_session(self, session_id: str) -> str:
        query = f"""
        SELECT role, message
        FROM public.chatmessages
        WHERE session_id = '{session_id}'
        ORDER BY created_on DESC
        """
        chats = await self.chat_message_service.custom_query(query)
        chat_string = "\n".join(
            [f"{chat['role']}: {chat['message']}" for chat in chats])
        return chat_string

    async def process_sessions(self):
        session_ids = await self.get_session_ids()
        for session_id in session_ids:
            chats = await self.fetch_chats_for_session(session_id)
            print(f"Session ID: {session_id}\n{chats}\n")

    async def start_processing(self):
        while True:
            await self.process_sessions()
            await asyncio.sleep(40)


async def test_chat_session_processor():
    # Initialize the ChatSessionProcessor
    processor = ChatSessionProcessor(get_db())

    # Manually invoke the processing method
    await processor.process_sessions()

if __name__ == "__main__":
    # Run the test function within the event loop
    asyncio.run(test_chat_session_processor())
