# Eve Overview

Eve represents an intelligent chatbot system meticulously crafted to address the primary objective of mitigating stress and anxiety levels while proactively combatting burnout. As a sophisticated conversational agent, Eve harnesses advanced natural language processing (NLP) algorithms to facilitate meaningful engagements with users.

This modular system is adept at tracking user sentiments in an aggregated manner, aligning them with the overarching goals and objectives of the organization. By amalgamating individual user sentiments, Eve provides valuable insights into the collective mood and well-being of the workforce, enabling companies to gauge and respond to prevalent trends effectively.

Through its modular architecture, Eve offers versatility and adaptability, allowing seamless integration with existing company frameworks and workflows. By leveraging aggregated user sentiments, companies can identify potential areas of concern, implement targeted interventions, and foster a supportive environment conducive to employee well-being and productivity.

In the subsequent sections, we will delve deeper into the structural components of Eve, its functionality, and the mechanisms through which it facilitates sentiment analysis and supports organizational objectives.
# Entities and their relationships

In this diagram, we can see the relationships between the different classes and databases. The **Eve** class is the central point that interacts with the other classes and databases to perform its main functionality. The **UserManager** handles everything related to users and their data, while the **UserDatabase**, **CompanyDatabase**, and **SurveyDatabase** store the corresponding information. The **ConversationManager** and **ConversationAnalysis** handle conversations and their analysis, respectively, using information from the databases and the **VectorDatabase** to perform searches on the document corpus.

The **Eve** class is the central component that orchestrates the interaction with other classes and databases to fulfill its primary purpose. The **UserManager** is responsible for managing everything related to users and their associated data. At the same time, the **UserDatabase**, **CompanyDatabase**, and **SurveyDatabase** store the relevant information for users, companies, and surveys, respectively.

The **ConversationManager** and **ConversationAnalysis** classes work together to handle conversations and their analysis. They utilize data from the databases and leverage the **VectorDatabase** to perform searches on the document corpus, enabling features like context-aware responses and analysis.

This design allows for a modular and organized approach, where each component has a dedicated responsibility, and the interactions between them enable the system's overall functionality. The **Eve** class acts as the central coordinator, while the **UserManager** ensures proper management of user data, and the various databases store and provide access to the necessary information for the system to operate effectively.

### DER

[![](https://mermaid.ink/img/pako:eNqNlMGOmzAQhl_F8pmNSAiBcFttVuqqWqlquj1UXCYwXawNNrJNWgJ595oQSBZQCicz_j__4_HYJY1EjDSgKDcM3iWkISfme1MoSVU9PFTVebwBDTtQSALywjVKiLQif5hOhvInkWbAi6mEKMk2lwe8Bd6yvYBYEYkqE1yhGro8H5qVmWawZ0dUBHhMWOvUALWoy4ofUCrQTPBX4PBulgpIM7qvfuSwLxRTRv4N5W8h09qriQ3AnxhpcVutLYKMkjGLBPRO6Hq3amS63us1z0ZyrUJn0FYQlTKp1mGjNtlrYFz9V_-FKZNtMRn7ikWWSBNQkxFTMiVMtV54XblzQT9xDdnvmQtcL6h-wG6PA68xoirbcO02YtNrtEH7DVzuAd_b5hwxuj298Vv0qfNG5MNb1BFtAYYN3RXhOtW3Gu3si-f4WZ1Vxyn8Nk9TkEXPfjp_5_I0cE9wwTYiylPk-knILFc9LOTUoima7bDYPHNlvVBIdYIphjQwwxjkR0hDfjI6yLXYFjyigZY5WjTPYtB4eRjbIMbMJPHaPJvn19Oi5qh-CdFJzC8NSvqXBnNvPlstPGfu-u56sXYcixYmuvBnrm8v5p5r22tnvTxZ9Hjm7ZnneyvXXjrLpWuvfN89_QOiCfCb?type=png)](https://mermaid.live/edit#pako:eNqNlMGOmzAQhl_F8pmNSAiBcFttVuqqWqlquj1UXCYwXawNNrJNWgJ595oQSBZQCicz_j__4_HYJY1EjDSgKDcM3iWkISfme1MoSVU9PFTVebwBDTtQSALywjVKiLQif5hOhvInkWbAi6mEKMk2lwe8Bd6yvYBYEYkqE1yhGro8H5qVmWawZ0dUBHhMWOvUALWoy4ofUCrQTPBX4PBulgpIM7qvfuSwLxRTRv4N5W8h09qriQ3AnxhpcVutLYKMkjGLBPRO6Hq3amS63us1z0ZyrUJn0FYQlTKp1mGjNtlrYFz9V_-FKZNtMRn7ikWWSBNQkxFTMiVMtV54XblzQT9xDdnvmQtcL6h-wG6PA68xoirbcO02YtNrtEH7DVzuAd_b5hwxuj298Vv0qfNG5MNb1BFtAYYN3RXhOtW3Gu3si-f4WZ1Vxyn8Nk9TkEXPfjp_5_I0cE9wwTYiylPk-knILFc9LOTUoima7bDYPHNlvVBIdYIphjQwwxjkR0hDfjI6yLXYFjyigZY5WjTPYtB4eRjbIMbMJPHaPJvn19Oi5qh-CdFJzC8NSvqXBnNvPlstPGfu-u56sXYcixYmuvBnrm8v5p5r22tnvTxZ9Hjm7ZnneyvXXjrLpWuvfN89_QOiCfCb)


# Main files

This system consists of three main files: `eve.py`, `user_manager.py`, and `api.py`. Let's take a look at each file and its purpose.

## eve.py

The `eve.py` file is the heart of the Eve system. It contains the `Eve` class, which handles the core logic and functionality of Eve. This class is responsible for:

- Initialization and setup
- Processing user messages and generating responses
- Managing conversations and their analysis
- Interacting with various components such as the chatbot, vector database, and user manager
- Finalizing conversations and performing cleanup tasks

The `Eve` class acts as the central point of interaction for the entire system, orchestrating the flow of data and communication between different modules. The principal methods of the class are:

1. **Initialization**: The `__init__` method initializes various components such as the prompt manager, conversation manager, conversation analysis, chatbot, and vector database.

2. **Initialize**: The `initialize` method sets up the user's environment, including loading prompts, personal information, summary conversation, and database description. It also checks for any backup conversations and initializes the user database.

3. **Load Temporary Files**: The `load_tmp_file` method creates a temporary directory for storing audio files and other temporary data.

4. **Load Personal Information**: The `load_personal_information` method loads the user's personal information from the user manager and sets it up for conversation analysis.

5. **Load Summary Conversation**: The `load_summary_conversation` method retrieves the summary of the previous conversation from the user manager and loads it for conversation analysis.

6. **Load Description Database**: The `load_description_database` method loads a description of the vector database for conversation analysis.

7. **Response Survey Question**: The `response_survey_question` method handles the user's response to a survey question and saves it in the user database.

8. **Response Text**: The `response_text` method processes the user's text message, checks if it requires a database search, and generates Eve's response using the chatbot or vector database search.

9. **Response**: The `response` method is the main entry point for handling user input. It determines if the input is text or audio, processes it accordingly, and returns Eve's response. It also handles survey questions and audio output.

10. **Finalize**: The `finalize` method is called when the conversation ends. It updates the personal information, summary conversation, saves conversation history, and performs cleanup tasks.

11. **Helper Methods**: The class also includes helper methods like `_process_personal_information` and `_process_summary_conversation` to update the personal information and summary conversation based on the current conversation.

## user_manager.py

The `user_manager.py` file contains the `UserManager` class, which manages everything related to users within the system. This class is responsible for:

- Creating, editing, and deleting user accounts
- Handling user authentication and login processes
- Managing user personal information
- Interacting with user and company databases
- Retrieving and storing conversation histories, indicators, and keyphrases
- Providing data for the `Eve` class and other system components

The `UserManager` class acts as an intermediary between the core system and the user data stored in various databases, ensuring proper management and access to user-related information. The principal methods of the class are:

1. **Initialization**: The `__init__` method initializes the user manager and sets up the user database.

2. **Create/Edit User**: The `create_edit_user` method creates a new user or edits an existing user's information.

3. **Initialize User Database**: The `initialize_user_database` method loads the user's database and initializes the session.

4. **Save User Database**: The `save_user_database` method saves the session data, conversation history, indicators, and keyphrases to the user's database.

5. **Save Company Database**: The `save_company_database` method saves relevant user data to the company database.

6. **Load User Database**: The `load_user_database` method loads the user's database.

7. **Get Last Session ID**: The `get_last_session_id` method retrieves the ID of the last session for the user.

8. **Update Last Personal Information**: The `update_last_personal_information` method updates the user's personal information in the database.

9. **Give Personal Information**: The `give_personal_information` method retrieves the user's personal information from the database.

10. **Give Last Summary Conversation**: The `give_last_summary_conversation` method retrieves the summary of the previous conversation from the database.

11. **Get Session Data**: The `get_session_data_as_dataframe` method retrieves session data from the database.

12. **Get Session History Data**: The `get_session_history_data_as_dataframe` method retrieves session history data from the database.

13. **Get Session Summary Data**: The `get_session_summary_data_as_dataframe` method retrieves session summary data from the database.

14. **Insert Session Data**: The `insert_session_data` method inserts session data into the database.

15. **Insert Session History Data**: The `insert_session_history_data` method inserts session history data into the database.

16. **Insert Keyphrases Data**: The `insert_keyphrases_data` method inserts keyphrases data into the database.

17. **Get Indicators**: The `get_indicators` method retrieves the user's indicators (e.g., stress, depression scores) from the database.

18. **Get Keyphrases**: The `get_keyphrases` method retrieves the user's keyphrases from the database.

19. **Check for Conversation Manager Backup**: The `check_for_conv_manager_backup` method checks if a backup of the conversation manager exists for the user.

20. **User Login**: The `user_login` method handles the user login process.

21. **Delete User**: The `delete_user` method deletes a user from the system.

## api.py

The `api.py` file defines the application programming interface (API) for the Eve system. It does not contain any classes but rather defines the API routes and their corresponding handlers. These handlers interact with the `Eve` and `UserManager` classes to process incoming HTTP requests.

The API endpoints defined in this file allow clients (e.g., web applications, mobile apps) to interact with the Eve system, enabling features such as:

- User authentication and account management
- Sending and receiving messages
- Retrieving user data (e.g., indicators, keyphrases)
- Managing surveys and survey responses
- Accessing dashboard data
- Performing administrative tasks (e.g., inserting company information)

The `api.py` file acts as the gateway for external clients to communicate with the Eve system, providing a well-defined interface for interacting with its functionalities.

These three files work together to provide the core functionality of the Eve system, with `eve.py` handling the main logic, `user_manager.py` managing user-related data, and `api.py` defining the API for external communication and interaction.The principal methods of the class are:

1. `/initialize_eve`: Initializes an Eve instance for a user.
2. `/is_eve_initialized`: Checks if an Eve instance is initialized for a user.
3. `/is_user`: Checks if a user exists in the system.
4. `/sign_up`: Creates a new user account.
5. `/edit_user`: Edits an existing user's information.
6. `/response`: Processes a user's message and returns Eve's response.
7. `/message_feedback`: Adds feedback to a specific message in the conversation.
8. `/indicators`: Retrieves a user's indicators (e.g., stress, depression scores).
9. `/keyphrases`: Retrieves a user's keyphrases.
10. `/todo_survey`: Retrieves a list of pending surveys for a user.
11. `/survey_next_questions`: Retrieves the next set of questions for a specific survey.
12. `/response_survey`: Saves a user's responses to a survey.
13. `/user_dashboard`: Retrieves a user's dashboard data (e.g., indicators, emotions).
14. `/company_dashboard`: Retrieves the company's dashboard data.
15. `/finalize_eve`: Finalizes the Eve instance for a user.
16. `/insertNewSurvey`: Inserts a new survey into the system.
17. `/delete_user`: Deletes a user from the system.
18. `/getsurveysresponses`: Retrieves the responses for a specific survey.
19. `/insert_company_info`: Inserts company information into the system.
20. `/get_company_info`: Retrieves company information.

The API file also includes various data models (e.g., `sign_in`, `sign_up`, `edit_user`, `PatientMessage`, `message_feedback`, `indicators`, `keyphrases`, `todo_survey_`, `NextQuestion`, `Response`, `UserDashboard`, `CompanyDashboard`, `finalize_eve_`, `insertNewSurvey`, `delete_user`, `getsurveysresponses`, `InsertCompanyInfo`, `GetCompanyInfo`) for handling request payloads and responses.

### Dataflow
The next flowchart illustrates how the various components of the Eve system interact to handle user requests, process messages, manage user data, and provide insights through dashboards and surveys. It serves as a visual guide to understanding the overall structure and functionality of the API endpoints within the system.
The arrows represent the flow of data or control between different components or operations. 

[![](https://mermaid.ink/img/pako:eNqNVlFv0zAQ_iuWeRhIZUo3tqV9AAGDqUJDwLYXKIq85Npabe1gu9vKtP-OL44TO8kk-lLf-b7vfGf7ix9pLgugU7rYyPt8xZQh1-dzQfTudqlYucLBBQ6SX3P6_tuMfBJFKbkwek5_27j69-kOfr2cU_s3p68C_0xww9mG_4WXdpo3VgZV5KuI4YOUm8c5nWk0SBtcvJvTp4BTt6xFRauRLgsAMfWNBlVz45DAA9dGd0lxqmbb2WGf4pIJtgSFdQZmXO8VX4qbEmm0HWW7slNkwY3PA3Y8kOkH6FIKXfVL1eM44qMUd6A0M1yKYE0D7nhtl6C19X4GKG5ZvsYEW-fKFrUvTjQTBc-ZkUq7zfNWHPUF9uVKMQ1V1Lqx-g08Z4bd2infQW_Hy7yWhbzaqTvYI5-xVqYrMyZ0IV_hwXzfgcaiq_wuNBPWn_3xE8MdbpP4Pg8mcivVq1vJVHXccM-ywnu6e7MtmdiHlXZccbHNZMCfO99zKT5zUR1ye0cwelGb_Rvl6guXEnu6N9WWZb7CfdsWHrti9nPYgAF_mIvKGjjOF2Ac2ne92qUlGNdq7Vuvu0cPU9fdmYmFbNeT-f5w6-4l60BsosF4EIWDtVJCXr8OLK9B2jCRA1lIRRjB8mzYW5yr4aEWIcPHFeRrTfjC4XUoYwMsKEue6cb5A4o61ulVBfFS5jBObSqMAmbsohkRcN9mCHVKhAKEGBxrF4utUdtKOoZxfvcQ903J3OoG1NhaQwgTBcF9xbIONFEtIuhXR4OQ7n1RaOIFiBhpa9Al5HzB84YbOYb0TcQyhXQXUBd1gL0PZgaqaqWri1yHMwPIVqS6yNIeLS6WpD7fDby5deIZ9WqIULtIo131odE-2RBbrGhIdMXuoFlSjW2u2jMskdB1y2rEyI4Me4ahq2YNSX0Fh3m6Aik6Kocs3vzfaxkrl7va6PI3JGhnRxRFLG4IdZYOM_UORF_nmuLbvve2cih3T_rC1deN7F3YwR7GctjdjP_j0Ga_gfYRaG0l1zAVUsBowTeb6Yuk-tGRfUxYNl7Yt-QjYu23ewVb-5WZ2mHBlH1czMWTjWM7I6_2IqdTo3YworvSHgU458w-OLfeia8jqS7d27R6oo6oXd1PKZsQa9LpI32g0_HR-PDNeHyUjMcnJ2-S0-PJiO6tO00Pz9LjSXp2lpykSTp5GtG_FUFymKanR5Pjk0mSnKbp-Gz89A-dH59y?type=png)](https://mermaid.live/edit#pako:eNqNVlFv0zAQ_iuWeRhIZUo3tqV9AAGDqUJDwLYXKIq85Npabe1gu9vKtP-OL44TO8kk-lLf-b7vfGf7ix9pLgugU7rYyPt8xZQh1-dzQfTudqlYucLBBQ6SX3P6_tuMfBJFKbkwek5_27j69-kOfr2cU_s3p68C_0xww9mG_4WXdpo3VgZV5KuI4YOUm8c5nWk0SBtcvJvTp4BTt6xFRauRLgsAMfWNBlVz45DAA9dGd0lxqmbb2WGf4pIJtgSFdQZmXO8VX4qbEmm0HWW7slNkwY3PA3Y8kOkH6FIKXfVL1eM44qMUd6A0M1yKYE0D7nhtl6C19X4GKG5ZvsYEW-fKFrUvTjQTBc-ZkUq7zfNWHPUF9uVKMQ1V1Lqx-g08Z4bd2infQW_Hy7yWhbzaqTvYI5-xVqYrMyZ0IV_hwXzfgcaiq_wuNBPWn_3xE8MdbpP4Pg8mcivVq1vJVHXccM-ywnu6e7MtmdiHlXZccbHNZMCfO99zKT5zUR1ye0cwelGb_Rvl6guXEnu6N9WWZb7CfdsWHrti9nPYgAF_mIvKGjjOF2Ac2ne92qUlGNdq7Vuvu0cPU9fdmYmFbNeT-f5w6-4l60BsosF4EIWDtVJCXr8OLK9B2jCRA1lIRRjB8mzYW5yr4aEWIcPHFeRrTfjC4XUoYwMsKEue6cb5A4o61ulVBfFS5jBObSqMAmbsohkRcN9mCHVKhAKEGBxrF4utUdtKOoZxfvcQ903J3OoG1NhaQwgTBcF9xbIONFEtIuhXR4OQ7n1RaOIFiBhpa9Al5HzB84YbOYb0TcQyhXQXUBd1gL0PZgaqaqWri1yHMwPIVqS6yNIeLS6WpD7fDby5deIZ9WqIULtIo131odE-2RBbrGhIdMXuoFlSjW2u2jMskdB1y2rEyI4Me4ahq2YNSX0Fh3m6Aik6Kocs3vzfaxkrl7va6PI3JGhnRxRFLG4IdZYOM_UORF_nmuLbvve2cih3T_rC1deN7F3YwR7GctjdjP_j0Ga_gfYRaG0l1zAVUsBowTeb6Yuk-tGRfUxYNl7Yt-QjYu23ewVb-5WZ2mHBlH1czMWTjWM7I6_2IqdTo3YworvSHgU458w-OLfeia8jqS7d27R6oo6oXd1PKZsQa9LpI32g0_HR-PDNeHyUjMcnJ2-S0-PJiO6tO00Pz9LjSXp2lpykSTp5GtG_FUFymKanR5Pjk0mSnKbp-Gz89A-dH59y)


### API functionality
The next diagram illustrates the various API endpoints categorized into different functionalities such as User Actions, Messaging, Data Retrieval, Survey Management, Eve Lifecycle, and Company Management. Each endpoint interacts with either the Eve class, UserManager class, or CompanyDatabase as necessary to fulfill its functionality.

This visual representation helps in understanding the structure of the API and how different components interact with each other to provide the desired functionality within the Eve system.

[![](https://mermaid.ink/img/pako:eNqNlt9v2jAQx_8V5KdWolUIv3mYVBVaoa3VtrYvW6bIJAdYBSeLHVpa9X_fxY4THEI6ns7nz-HzXe6bvJMgCoFMyHITvQRrmsjW49TjLZEuVgmN15lxmxnOb488CUhaV4FkERce-YNY_ntgK_4Un515RKDlp7FHzs_L7bnIIrNtJvwUTXt7FjJpAEC7BpnCBiQYKFQrCwMeHmZ9B0LQFeMrzLqwrZR_gojxGpD9X5Lb9pk6Dm4AwgUNnjNwq13-MvedON3UzMXTp1RSPEwmDHZ0Y6Uw5yELqIwSoUpTrOw0vsI-XidUgKKei5VNPUZh9JAmO9hnlMSVL9TSxjRyD6_yRwpCNVJ1Tbl9jn7_r9mwI7PaT6lYLyKahFlMVn0_NB4bvo62MeV7iw-07zjkRPG6WDydbuuOcqz6Fris1A9TkPfwUl6c2S47K9PyEjeNr63VLUhNmjhVqhVIDQsTLD65SA8vMttB6xtbQrAPNlC5BJOMbtgb6PzNyocdVKeoZMN8mBDyy5hKF24YV248PMOX-fLwn0-k3MeU8x42Fz-H5nwZleX3TasZuo9qWgnBetbyJzIbYGZX3-etGQ_jiHFp61AhVtUpzqb_iHKPXd1jV-_Y1S8TLMSvdXHxRQ2JrldyvaFCnGnNzF14NR2h9bA2QgNGERuQUhEbIPPkKgQfA5PUTD0BmqnInIXm6RbK1HBUKVMNUKlSDVCNRjXQli41cFVJakAruvIf9f0UPNaSxvPNQNc141AFavYPhr62lZWpVUxRG0kX2MFy-I2nGDJ7fuuCPe5x0sY3ZbKlLMQPi_csEl9Ja9QQj0zQDGmCb06PfyBHUxk97HlAJjJJoU3SOKQSpozi2G_JZEk3Ar3ZV0GU3OkvFfXB0iZ46K8o2ppAXJLJO3klk86wczlwh91Of9Qfu-Nut0326HVHl_2R43aGfccZd8e9jzZ5U_HO5XA0HPSdnjPoDpyBO3A__gFkNPmA?type=png)](https://mermaid.live/edit#pako:eNqNlt9v2jAQx_8V5KdWolUIv3mYVBVaoa3VtrYvW6bIJAdYBSeLHVpa9X_fxY4THEI6ns7nz-HzXe6bvJMgCoFMyHITvQRrmsjW49TjLZEuVgmN15lxmxnOb488CUhaV4FkERce-YNY_ntgK_4Un515RKDlp7FHzs_L7bnIIrNtJvwUTXt7FjJpAEC7BpnCBiQYKFQrCwMeHmZ9B0LQFeMrzLqwrZR_gojxGpD9X5Lb9pk6Dm4AwgUNnjNwq13-MvedON3UzMXTp1RSPEwmDHZ0Y6Uw5yELqIwSoUpTrOw0vsI-XidUgKKei5VNPUZh9JAmO9hnlMSVL9TSxjRyD6_yRwpCNVJ1Tbl9jn7_r9mwI7PaT6lYLyKahFlMVn0_NB4bvo62MeV7iw-07zjkRPG6WDydbuuOcqz6Fris1A9TkPfwUl6c2S47K9PyEjeNr63VLUhNmjhVqhVIDQsTLD65SA8vMttB6xtbQrAPNlC5BJOMbtgb6PzNyocdVKeoZMN8mBDyy5hKF24YV248PMOX-fLwn0-k3MeU8x42Fz-H5nwZleX3TasZuo9qWgnBetbyJzIbYGZX3-etGQ_jiHFp61AhVtUpzqb_iHKPXd1jV-_Y1S8TLMSvdXHxRQ2JrldyvaFCnGnNzF14NR2h9bA2QgNGERuQUhEbIPPkKgQfA5PUTD0BmqnInIXm6RbK1HBUKVMNUKlSDVCNRjXQli41cFVJakAruvIf9f0UPNaSxvPNQNc141AFavYPhr62lZWpVUxRG0kX2MFy-I2nGDJ7fuuCPe5x0sY3ZbKlLMQPi_csEl9Ja9QQj0zQDGmCb06PfyBHUxk97HlAJjJJoU3SOKQSpozi2G_JZEk3Ar3ZV0GU3OkvFfXB0iZ46K8o2ppAXJLJO3klk86wczlwh91Of9Qfu-Nut0326HVHl_2R43aGfccZd8e9jzZ5U_HO5XA0HPSdnjPoDpyBO3A__gFkNPmA)

