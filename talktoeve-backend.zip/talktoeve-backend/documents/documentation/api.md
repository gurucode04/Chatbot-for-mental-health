# Talk to Eve API endpoints usage

This FastAPI application provides a chatbot service. It supports User Management, Text and Audio interaction with the bot, User Feedback, Analytics Dashboard and Surveys.

The responses are standardized as JSON with keys `message` and `data`.

Here's how to use different endpoints:

1. `/initialize_eve`: `POST` method. It creates a new instance of EVE (chatbot) for a user. 
   
   Example of the payload:
   ```json
   {
    "username": "JohnDoe"
   }
   ```

2. `/is_eve_initialized`: `GET` method. It checks if EVE is already initialized for a user.
   
   Example of the payload:
   ```json
   {
    "username": "JohnDoe"
   }
   ```

3. `/is_user`: `GET` method. It checks if a user is already existing in the system.
   
   Example of the payload:
   ```json
   {
    "username": "JohnDoe"
   }
   ```

4. `/users_list`: `GET` method. It provides a list of all existing users in the system.
   
   Example of the payload:
   ```json
   {
    "username": "JohnDoe"
   }
   ```
   
5. `/sign_up`: `POST` method. It creates a new user in the system.

   Example of the payload:
   ```json
   {
   "username": "JohnDoe",
   "user_id" : "123456",
   "name": "John Doe",
   "birthday": "1990-06-03",
   "nationality": "American",
   "location": "Chicago",
   "position": "Manager",
   "area": "Marketing",
   "shift": "Morning",
   "vessel": "A1001",
   "experience": "5 years",
   "studies": "MBA(University)",
   "user_type": "user"
   }
   ```
   
6. `/edit_user`: `POST` method. It edits an existing user's details in the system.

   Example of the payload:
   ```json
   {
   "username": "Admin",
   "username_to_edit": "JohnDoe",
   "user_id" : "123456",
   "name": "John Doe",
   "birthday": "1990-06-03",
   "nationality": "American",
   "location": "Chicago",
   "position": "Manager",
   "area": "Marketing",
   "shift": "Morning",
   "vessel": "A1001",
   "experience": "5 years",
   "studies": "MBA",
   "user_type": "user"
   }
   ```

7. `/response`: `POST` method. It responds to user's text and audio input. The user's input can be either a text message or an audio file. If the `audio_response_flag` is set to true, it will return a text response and audio response, otherwise, it will return only text response.

   Example of the payload:
   ```json
   {
   "username": "JohnDoe",
   "message": "Hello, EVE!",
   "audio_response_flag": true
   }
   ```

   If the user input is an audio file, the payload will also include the `audio` key with the value being the audio file.

8. `/message_feedback`: `POST` method. It saves user's feedback on EVE's response.

   Example of the payload:
   ```json
   {
   "username": "JohnDoe",
   "message_id": "m_123456",
   "feedback": "Good"
   }
   ```

9. `/user_conversations`: `GET` method. It returns the conversation history of a user.
   
   Example of the payload:
   ```json
   {
    "username": "JohnDoe"
   }
   ```

10. `/indicators`: `POST` method. It provides indicators of user’s mental health based on the past conversations.

    Example of the payload:
    ```json
    {
    "username": "JohnDoe",
    "session_id": 123456,
    "from_date": "2021-05-01",
    "to_date": "2021-05-31",
    "aggregate": false
    }
    ```

    - `/mindmap`: `POST` method.
    - This endpoint accepts POST requests with the following parameters:
        - `username`: a string 
        - `session_id`: can be of type `str` or `None` 
        - `from_date` : can be of type `str` or `None`
        - `to_date` : can be of type `str` or `None`
    - Example of what you could POST is:
        ```json
        {
            "username": "John",
            "session_id": "af53h22",
            "from_date": "06/05/2021",
            "to_date": "06/06/2021"
        }
        ```

    - The endpoint will return a message indicating the availability of data and the data itself.

11. `/todo_survey`: `POST` method.
    - This endpoint accepts POST requests with the following parameters:
        - `username`: a string 
    - Example of what you could POST is:
        ```json
        {
            "username": "John",
        }
        ```
    - The endpoint will return a message indicating the availability of data and the data.

12. `/survey_next_questions`: `POST` method.
    - This endpoint accepts POST requests with the following parameters:
        - `username`: a string 
        - `survey_id`: an integer
        - `number_of_questions`: an integer
    - Example of what you could POST is:
        ```json
        {
            "username": "John",
            "survey_id": 100,
            "number_of_questions": 5
        }
        ```

    - The endpoint will return a message indicating the availability of data and the data.

13. `/response_survey`: `POST` method.
    - This endpoint accepts POST requests with the following parameters:
        - `username`: a string 
        - `survey_id`: an integer
        - `responses`: a dictionary where the keys are integers and the values are integers
    - Example of what you could POST is:
        ```json
        {
            "username": "John",
            "survey_id": 100,
            "responses": {
                "1": 5,
                "2": 3,
                "3": 4,
                "4": 4,
                "5": 5
            }
        }
        ```
    - This endpoint will save the survey response and return the message saying `Survey response saved`.


14. `/user_dashboard`: `POST` method.
    - This endpoint accepts POST requests with the following parameters:
        - `username`: a string 
        - `start_filter_date`: can be of type `str` or `None`
        - `end_filter_date`: can be of type `str` or `None`
        - `aggregate`: a boolean. Default is `False`
        - `weighted`: a boolean. Default is `True`
    - Example of what you could POST is:
        ```json
        {
            "username": "John",
            "start_filter_date": "06/05/2021",
            "end_filter_date": "06/06/2021",
            "aggregate": true,
            "weighted": false
        }
        ```
    - The endpoint will return the dashboards available in the selected time period.

15. `POST /company_dashboard`: This endpoint requires a `CompanyDashboard` object which consists of `username`, `filters`, `start_filter_date`, `end_filter_date`, `aggregate`, `wheited`, `last_session`, `period`.

Example inputs:

```python
{
  "username": "test_user",
  "filters": {"Gender": ["Male", "Female"]},
  "start_filter_date": "2021-01-01",
  "end_filter_date": "2022-01-01",
  "aggregate": True,
  "wheited": False,
  "last_session": True,
  "period": "weekly"
}
```

The function `company_dashboard()` is then invoked which checks if the user exists or is authorized to get company dashboard data based on their username and send the data if available. 

16. `/finalize_eve`: `POST` method. This expects a `finalize_eve_` object with `username`.

Example inputs:

```python
{
  "username": "test_user"
}
```

The `finalize_eve()` function checks if the Eve instance is initialized for this user or not, and if yes it removes Eve from the user instances and returns a message about Eve being finalized.

17. `/insert_new_survey`: `POST` method. This endpoint requires an object of `insertNewSurvey` with `username`, `name`, `date`, `due_date`, `questions_dict`.

Example inputs:

```python
{
  "username": "test_user",
  "survey": {
            "name": "anonymous health and wellbeing survey y2 2023",
            "date": "05-12-2023",
            "due_date": "05-02-2024",
            "questions": [
                {
                    "question": "What is your position?",
                    "options": ["Officer / Chief / SL", "Operator / Rating", "Other"],
                    "option_type": "single"
                },
                {
                    "question": "What is your age?",
                    "options": ["Under 24", "25 - 34", "35 - 44", "45 - 54", "Over 55"],
                    "option_type": "single"
                }
            ]
        }
}
```
Once the data is validated and if the user is authorized then survey data is inserted.

18. `/get_survey_json`: `GET` method

This endpoint retrieves survey data based on the provided `survey_id` and `username`.

Example inputs:
```python
{
  "username": "test_user",
  "survey_id": "0"
}
```
Example response
```python
{"message": "Survey retrieved", 
 "data": {
            "name": "anonymous health and wellbeing survey y2 2023",
            "date": "05-12-2023",
            "due_date": "05-02-2024",
            "questions": [
                {
                    "question": "What is your position?",
                    "options": ["Officer / Chief / SL", "Operator / Rating", "Other"],
                    "option_type": "single"
                },
                {
                    "question": "What is your age?",
                    "options": ["Under 24", "25 - 34", "35 - 44", "45 - 54", "Over 55"],
                    "option_type": "single"
                }
            ]
        }}
```

19. `/modify_survey`: `PUT` method

This endpoint allows authorized users to modify an existing survey identified by `survey_id`.

Example inputs:
```python
{
  "username": "admin_user",
  "survey_id": "0",
  "survey": {
    "name": "Updated survey name",
    "date": "06-01-2024",
    "due_date": "06-30-2024",
    "questions": [
      {
        "question": "Updated question 1?",
        "options": ["Option A", "Option B", "Option C"],
        "option_type": "multiple"
      },
      {
        "question": "Updated question 2?",
        "options": null,
        "option_type": "text"
      }
    ]
  }
}
```
20. `/delete_survey`: `DELETE` method

This endpoint allows authorized users to delete a survey based on `survey_id`.

Example inputs:
```python
{
  "username": "admin_user",
  "survey_id": "0"
}
```

21. `/getsurveysresponses`: `POST` method. This endpoint expects a `getsurveysresponses` object with `username` and `survey_id`.

Example inputs:
```python
{
  "username": "test_user",
  "survey_id": 1
}
```

22. `/delete_user`: `POST` method. This endpoint expects a `delete_user` object with `username` and `username_to_delete`.

Example inputs:
```python
{
  "username": "test_user",
  "username_to_delete": "user1"
}
```
The `delete_user()` function then deletes the provided user if the current user is authorized.

23. `/insert_company_info`: `POST` method. This endpoint expects an `InsertCompanyInfo` object with a set of company information.

Example inputs:
```python
{
  "username": "test_user",
  "company_name": "XYZ Ltd.",
  "industry": "Information Technology",
  "address": "123, Abc St., PQR City, Country",
  "company_email": "info@xyz.com",
  "company_number": "+1-234-567-8901",
  "company_logo": "logo.png",
  "business_hours": {"monday": "9am-5pm", "tuesday": "9am-5pm"},
  "services_offered": "Development, Marketing",
  "company_description": "XYZ Ltd is a leading software development company."
}
```

Once the data is validated and if the user is authorized then company information is inserted.

24. `/get_company_info`: `POST` method. This endpoint requires a `GetCompanyInfo` object with `username`.

Example inputs:

```python
{
  "username": "test_user"
}
```