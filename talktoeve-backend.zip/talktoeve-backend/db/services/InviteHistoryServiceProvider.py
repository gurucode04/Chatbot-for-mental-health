from typing import Dict, Any, Optional
from datetime import datetime
from db.GenericAccessProvider import GenericAccessProvider
from db.session import get_db


class InviteHistoryServiceProvider:
    def __init__(self, access_provider: GenericAccessProvider):
        self.access_provider = access_provider

    async def add_row(self, data: Dict[str, Any], res: Optional[Dict[str, Any]] = None) -> Any:
        if res:
            data.update({'created_by': res.get('user_id'),
                        'created_on': datetime.utcnow()})
        return await self.access_provider.create(data)

    async def fetch_row_by_id(self, row_id: int) -> Any:
        return await self.access_provider.get_by_id(row_id)

    async def fetch_all_rows(self) -> Any:
        return await self.access_provider.get_all()

    async def update_row(self, row_id: int, data: Dict[str, Any], res: Optional[Dict[str, Any]] = None) -> Any:
        instance = await self.access_provider.get_by_id(row_id)
        if not instance:
            raise Exception("Row not found")

        if res:
            data.update({"updated_by": res.get('user_id'),
                        "updated_on": datetime.utcnow()})

        return await self.access_provider.update(instance, data)

    async def delete_row(self, row_id: int) -> None:
        instance = await self.access_provider.get_by_id(row_id)
        if not instance:
            raise Exception("Row not found")
        await self.access_provider.delete(instance)

    async def filter_rows(self, filters: Dict[str, Any], deleted: bool = False) -> Any:
        if not deleted:
            filters.update({'is_deleted': deleted})
        return await self.access_provider.filter_by(filters)

    async def custom_query(self, query: str) -> Any:
        return await self.access_provider.execute_custom_query(query)
