import asyncio
from db.schema.User import User
from db.session import get_db
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlmodel import Session, select
from typing import Type, TypeVar, Generic, Optional, List, Dict, Any
from sqlalchemy import text
T = TypeVar('T', bound='SQLModel')


class GenericAccessProvider(Generic[T]):
    def __init__(self, model: Type[T], db: Session):
        self.model = model
        self.db = db

    async def get_by_id(self, id: int) -> Optional[T]:
        return await self.db.get(self.model, id)

    async def get_all(self) -> List[T]:
        statement = select(self.model)
        results = await self.db.execute(statement)
        return results.scalars().all()

    async def create(self, data: Dict[str, Any]) -> T:
        instance = self.model(**data)
        self.db.add(instance)
        await self.db.commit()
        await self.db.refresh(instance)
        return instance

    async def update(self, instance: T, data: Dict[str, Any]) -> T:
        for key, value in data.items():
            setattr(instance, key, value)
        self.db.add(instance)
        await self.db.commit()
        await self.db.refresh(instance)
        return instance

    async def delete(self, instance: T) -> None:
        await self.db.delete(instance)
        await self.db.commit()

    async def filter_by(self, filters: Dict[str, Any]) -> List[T]:
        statement = select(self.model).filter_by(**filters)
        results = await self.db.execute(statement)
        return results.scalars().all()

    async def execute_custom_query(self, query: str) -> Any:
        result = await self.db.execute(text(query))
        return result.fetchall()


if __name__ == "__main__":
    async def test_execute_custom_query(db: AsyncSession = Depends(get_db)):

        # Create a GenericAccessProvider for the User model
        provider = GenericAccessProvider(User, db)

        # Add some sample data
        await provider.create({
            "user_name": "testuser",
            "email": "test@example.com",
            "password": "password",
            "role": "admin"
        })

        # Test the custom query method
        query = "SELECT user_name, email FROM user WHERE role='admin'"
        result = await provider.execute_custom_query(query)

        # Check if the query returned the correct results
        assert len(result) == 1
        assert result[0]["user_name"] == "testuser"
        assert result[0]["email"] == "test@example.com"

        print("Test passed successfully!")

    # Run the test
    asyncio.run(test_execute_custom_query())
