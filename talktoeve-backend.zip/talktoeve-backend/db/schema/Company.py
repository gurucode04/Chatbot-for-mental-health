from datetime import datetime, timezone
from typing import Optional
from sqlmodel import Field, SQLModel, Relationship
from db.schema.BaseModel import BaseModel


class Company(BaseModel, table=True):
    company_name: str
    email: str
    phone: str
    street: str
    city: str
    postal_code: str
    country: str
    registration_number: Optional[str] = None
    tax_identification_number: Optional[str] = None
    vat_number: Optional[str] = None
    industry_type: Optional[str] = None
    legal_form: Optional[str] = None
    incorporation_date: Optional[datetime] = None
    number_of_employees: int
    annual_revenue: Optional[float] = None
    website_url: Optional[str] = None
    # pending, approved, rejected
    status: Optional[str] = Field(default="pending")
    # credit : Credit = Relationship(back_populates="company")
    # employees: list[Employee] = Relationship(back_populates="company")
    # invitations: list[Invitation] = Relationship(back_populates="company")
