from datetime import datetime, timezone
from typing import Optional
from sqlmodel import Field, SQLModel, Relationship

class BaseModel(SQLModel):
    id: Optional[int] = Field(default=None, primary_key=True)
    is_active: Optional[bool] = Field(default=True)
    is_deleted: Optional[bool] = Field(default=False)
    created_on: Optional[datetime] =  Field(default_factory=lambda: datetime.utcnow())
    created_by: Optional[int] = None
    updated_on: Optional[datetime] = None
    updated_by: Optional[int] = None