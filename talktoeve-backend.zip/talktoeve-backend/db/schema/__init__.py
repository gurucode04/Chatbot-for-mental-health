from db.schema.BaseModel import BaseModel
from db.schema.Company import Company
from db.schema.Credit import Credit
from db.schema.Employee import Employee
from db.schema.InviteHistory import InviteHistory
from db.schema.User import User
from db.schema.ChatMessages import ChatMessages
from db.schema.ChatSessionSummaries import ChatSessionSummaries
from sqlmodel import SQLModel


__all__ = ["Company", "Credit", "Employee",
           "Invitation", "User", "ChatMessages", "ChatSessionSummaries"]


def create_db_and_tables(engine):
    SQLModel.metadata.create_all(engine)
