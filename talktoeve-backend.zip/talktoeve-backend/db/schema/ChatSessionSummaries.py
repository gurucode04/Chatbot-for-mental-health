from datetime import datetime, timezone
from typing import Optional
from sqlmodel import Field, SQLModel, Relationship
from db.schema.BaseModel import BaseModel


class ChatSessionSummaries(BaseModel, table=True):
    user_id: int = Field(foreign_key="user.id")
    company_id: int = Field(foreign_key="company.id")
    session_id: Optional[str] = Field(max_length=50, default=None)
    summary: str
