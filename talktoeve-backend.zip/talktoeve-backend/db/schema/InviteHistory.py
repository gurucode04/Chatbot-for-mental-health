from datetime import datetime
from typing import Optional
from enum import Enum
from sqlmodel import Field, SQLModel, Relationship
from db.schema.BaseModel import BaseModel

class RoleEnum(str, Enum):
    EMPLOYEE = "employee"
    COMPANY_ADMIN = "company_admin"

class StatusEnum(str, Enum):
    UNACCEPTED = "unaccepted"
    ACCEPTED = "accepted"

class InviteHistory(BaseModel, table=True):
    email: str
    role: RoleEnum
    invite_date: Optional[datetime] = Field(default_factory=datetime.utcnow)
    resend: Optional[bool] = Field(default=False)
    invited_by: int = Field(foreign_key="user.id")
    user_id: Optional[int] = Field(foreign_key="user.id", default=None)
    company_id: Optional[int] = Field(foreign_key="company.id", default=None)
    status: StatusEnum = Field(default=StatusEnum.UNACCEPTED)