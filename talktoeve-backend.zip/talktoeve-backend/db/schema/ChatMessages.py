from datetime import datetime, timezone
from typing import Optional
from sqlmodel import Field, SQLModel, Relationship
from db.schema.BaseModel import BaseModel


class ChatMessages(BaseModel, table=True):
    user_id: int = Field(foreign_key="user.id")
    company_id: int = Field(foreign_key="company.id")
    session_id: str = Field(max_length=50)
    role: str = Field(max_length=20)
    message: str
