from datetime import datetime, timezone
from typing import Optional
from sqlmodel import Field, SQLModel, Relationship
from db.schema.BaseModel import BaseModel

class Credit(BaseModel, table=True):
    company_id: int = Field(foreign_key="company.id")
    allocated_credits: int
    used_credits: int = Field(default=0)
    assigned_date: Optional[datetime] = Field(default_factory=lambda: datetime.utcnow())
    # company: Company = Relationship(back_populates="credit")
