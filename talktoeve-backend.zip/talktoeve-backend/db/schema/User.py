from sqlmodel import Field, SQLModel, Relationship
from typing import List, Optional
from db.schema.BaseModel import BaseModel
class User(BaseModel, table=True):
    user_name: str = Field(nullable=False, unique=True)
    email: str
    password: str
    role: str
    company_id: Optional[int] = Field(default=None, foreign_key="company.id")
    # employee:Employee = Relationship(back_populates="user")

