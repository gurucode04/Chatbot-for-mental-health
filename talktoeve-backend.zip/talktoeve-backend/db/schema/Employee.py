from datetime import datetime
from typing import Optional
from sqlmodel import Field as TableField
from db.schema.BaseModel import BaseModel as Table
from pydantic import BaseModel, EmailStr, Field as PydanticField

class Employee(Table, table=True):
    first_name: str
    last_name: str
    user_id: int = TableField(foreign_key="user.id")
    company_id: int = TableField(foreign_key="company.id")
    birthday: Optional[datetime]
    nationality: Optional[str]
    location: Optional[str]
    date_of_joining: Optional[datetime] = TableField(default_factory=lambda: datetime.utcnow())
    employee_id_number: Optional[str]
    email : Optional[str] = None
    phone: Optional[str] = None
    department: Optional[str] = None  
    designation: Optional[str] = None
    experience: Optional[str] = None
    brief: Optional[str] = None
    # user: User = Relationship(back_populates="employee")
    # company: Company = Relationship(back_populates="employees")

class UpdateEmployeeInfo(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    birthday: Optional[datetime] = None
    nationality: Optional[str] = None
    location: Optional[str] = None
    date_of_joining: Optional[datetime] = None
    employee_id_number: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    updated_on: Optional[datetime] = PydanticField(default_factory=lambda: datetime.utcnow())
    department: Optional[str] = None  
    designation: Optional[str] = None
    experience: Optional[str] = None
    brief: Optional[str] = None
