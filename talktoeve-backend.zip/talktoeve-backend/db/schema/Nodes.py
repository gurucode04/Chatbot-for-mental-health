from datetime import datetime, timezone
from typing import Optional, List, Set
from sqlmodel import Field, SQLModel, Relationship, Column, Integer, String
from db.schema.BaseModel import BaseModel
from sqlalchemy.dialects import postgresql    ###  ARRAY contains requires dialect specific type


class Nodes(BaseModel, table=True):
    user_id: int = Field(foreign_key="user.id")
    company_id: int = Field(foreign_key="company.id")
    session_id: str = Field(max_length=50)
    node_name: str
    parent_node_id: Optional[int] = Field(default=None)
    sibling_node_ids: Optional[Set[int]] = Field(default=None, sa_column=Column(postgresql.ARRAY(Integer())))
    child_node_ids: Optional[Set[int]] = Field(default=None, sa_column=Column(postgresql.ARRAY(Integer())))
    description: Optional[str]
    conversation_sample: Optional[str]
    tags: Optional[List[str]] = Field(default=None, sa_column=Column(postgresql.ARRAY(String())))
    ai_insights: Optional[str]

    # For filtering based on Array datatype
    # res = session.query(Nodes).filter(Nodes.child_node_ids.contains([some_data]))

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "company_id": self.company_id,
            "session_id": self.session_id,
            "node_name": self.node_name,
            "parent_node_id": self.parent_node_id,
            "sibling_node_ids": list(self.sibling_node_ids) if self.sibling_node_ids else None,
            "child_node_ids": list(self.child_node_ids) if self.child_node_ids else None,
            "description": self.description,
            "conversation_sample": self.conversation_sample,
            "tags": self.tags,
            "ai_insights": self.ai_insights,
            "created_on": self.created_on.isoformat() if self.created_on else None,
            "updated_on": self.updated_on.isoformat() if self.updated_on else None
        }