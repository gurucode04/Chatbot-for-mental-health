from pytz import utc
import asyncio
from api.routes.scheduler_service import call_scheduler, call_survey
from apscheduler.triggers.cron import CronTrigger
import datetime
from traceback import print_exc
from openai_service.response_generator import ResponseGenerator, user_conversations
from modules.EveInitializer import user_eve_instances, EveInitializer
from utils.security.RateLimitMiddleware import RateLimitMiddleware
from utils.logger import setup_logger
from db.schema import create_db_and_tables
from db.session import engine, AsyncSessionLocal, get_db
from api.routes.company.employee.employee_routes import router as employee_router
from api.routes.company.admin.company_routes import router as company_router
from api.routes.handler.LoginSignupHandler import router as signup_router
from api.routes.admin.admin_routes import router as admin_router
from api.routes.scheduler import router as scheduler_routes
from db.GenericAccessProvider import GenericAccessProvider
from db.services.NodesServiceProvider import NodesServiceProvider
from db.schema.Nodes import Nodes

from fastapi.openapi.models import OAuthFlows as OAuthFlowsModel, OAuthFlowPassword
from fastapi.security import OAuth2
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Response
from typing import Annotated, Optional
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from utils.security.TokenVerifier import TokenVerifier
from modules.auxiliar_functions import ritik_format
from modules.databases_sql.databases import CompanyDatabase
from modules.eve import Eve
import time
from modules.users_manager.config import PATH_USERS_FOLDERS
import ssl
from modules.databases_sql.databases import SurveyDatabase
from modules.users_manager.user_manager import UserManager
from fastapi import FastAPI, HTTPException, Response, Depends, UploadFile, File, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
import base64
from pydantic import BaseModel
import sys
import os
from typing import Union, List, Dict
import shutil
import pandas as pd
from fastapi.middleware.cors import CORSMiddleware
# add root directory to the sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
current_dir = os.path.dirname(os.path.abspath(__file__))
# Obtain the parent directory
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)


# Setup logger
logger = setup_logger()


class OAuth2PasswordBearerWithCookie(OAuth2):
    def __init__(self, tokenUrl: str):
        flows = OAuthFlowsModel(password=OAuthFlowPassword(tokenUrl=tokenUrl))
        super().__init__(flows=flows)


oauth2_scheme = OAuth2PasswordBearerWithCookie(tokenUrl="token")


# def printit():
#     print(datetime.datetime.now())

# Capture the event loop during FastAPI startup
# event_loop = None  # Will hold reference to FastAPI's event loop


# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     global event_loop
#     event_loop = asyncio.get_event_loop()  # Capture the main event loop

#     scheduler = BackgroundScheduler()

#     # This will trigger the job every day at a specific time
#     trigger = CronTrigger(hour=20, minute=0)

#     # Function to run the scheduler task in the main FastAPI event loop
#     def run_scheduler_task():
#         if event_loop.is_running():
#             # Run the task in the main FastAPI event loop
#             asyncio.run_coroutine_threadsafe(call_scheduler(), event_loop)
#         else:
#             print("Main event loop is not running, task cannot be scheduled.")

#     # Schedule the task using APScheduler
#     scheduler.add_job(run_scheduler_task, trigger)

#     scheduler.start()

#     async with engine.begin() as conn:
#         await conn.run_sync(create_db_and_tables)

#     yield

scheduler = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global scheduler
    scheduler = AsyncIOScheduler(timezone=utc)

    # This will trigger the job every day at a specific time (UTC)
    trigger = CronTrigger(hour=10, minute=14, timezone=utc)

    # Schedule the task using APScheduler
    scheduler.add_job(call_scheduler, trigger, id='daily_scheduler')

    # This is to set the interval for analyzing survey questions.
    interval_hrs = 3
    for i in range(0,24,interval_hrs):
        trigger = CronTrigger(hour=i, minute=5, timezone=utc)
        s='survey_scheduler'+str(i)
        scheduler.add_job(call_survey, trigger, id=s)

    scheduler.start()
    print("Scheduler started successfully")

    async with engine.begin() as conn:
        await conn.run_sync(create_db_and_tables)

    yield

app = FastAPI(lifespan=lifespan, title="Talk To Eve", version="0.1")

@app.get("/scheduler_status")
async def scheduler_status():
    global scheduler
    if scheduler and scheduler.running:
        jobs = scheduler.get_jobs()
        job_info = [{"id": job.id, "next_run": job.next_run_time} for job in jobs]
        return {"status": "running", "jobs": job_info}
    else:
        return {"status": "not running"}

@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info(f"Request {request.method} {request.url}")
    try:
        response = await call_next(request)
        logger.info(f"Response status code: {response.status_code}")
        return response
    except Exception as e:
        logger.error(f"Unhandled error: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.error(f"General Exception: {exc}", exc_info=True)
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


@app.exception_handler(500)
async def internal_exception_handler(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})

# Add the advanced middleware to the app
app.add_middleware(RateLimitMiddleware)

# Include your API routers here
# app.include_router(item_router)

app.include_router(signup_router)
app.include_router(admin_router)
app.include_router(company_router)
app.include_router(employee_router)
app.include_router(scheduler_routes)

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain('app/cert.pem', keyfile='app/key.pem')


class sign_in(BaseModel):
    username: str
    model_name: Union[str, None] = None


@app.post("/initialize_eve")
def initialize_eve(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: sign_in):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is already initialized for this user")

    # Create a new instance of Eve for the user
    user_eve_instances[payload.username] = Eve()
    user_eve_instances[payload.username].initialize(payload.username)

    if payload.model_name:
        user_eve_instances[payload.username].models_manager.change_prop(info_key='eve_response',
                                                                        prop_name='model_name', prop=payload.model_name)
        user_eve_instances[payload.username].models_manager.change_prop(info_key='eve_response',
                                                                        prop_name='max_tokens', prop=300)

    return {"message": "User initialized",
            "data": None}


@app.get("/is_eve_initialized")
def is_eve_initialized(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: sign_in):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if payload.username in user_eve_instances:
        return {"message": True,
                "data": None}
    else:
        return {"message": False,
                "data": None}


@app.get("/is_user")
def is_user(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: sign_in):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if payload.username in os.listdir(PATH_USERS_FOLDERS):
        return {"message": True,
                "data": None}
    else:
        return {"message": False,
                "data": None}

# class sign_up(BaseModel):
#     username: str
#     user_id : str
#     name: str
#     birthday: str
#     nationality: str
#     location: str
#     position: str
#     area: str
#     shift: str
#     vessel: str
#     experience: str
#     studies: str
#     user_type: str = "user"

# @app.post("/sign_up")
# def sign_up(payload: sign_up = Depends()):
#     user_manager = UserManager(sign_up=True)
#     payload = payload.model_dump()
#     #add the user
#     payload['edit'] = False
#     user_manager.create_edit_user(payload)
#     del user_manager
#     return {"message": "User created",
#         "data": None}

# class edit_user(BaseModel):
#     username: str
#     username_to_edit: str
#     user_id : str
#     name: str
#     birthday: str
#     nationality: str
#     location: str
#     position: str
#     area: str
#     shift: str
#     vessel: str
#     experience: str
#     studies: str
#     user_type: str = "user"

# @app.post("/edit_user")
# def edit_user(payload: edit_user = Depends()):

#     if not payload.username in user_eve_instances:
#         raise HTTPException(status_code=400, detail="Eve is not initialized for this user")

#     eve : Eve = user_eve_instances[payload.username]

#     if eve.user_type == "user":
#         raise HTTPException(status_code=401, detail="User is not authorized to delete a user")

#     payload = payload.model_dump()
#     payload['username'] = payload['username_to_edit']
#     payload.pop('username_to_edit')
#     payload['edit'] = True

#     eve.user_manager.create_edit_user(payload)

#     return {"message": "User edited",
#         "data": None}


class PatientMessage(BaseModel):
    username: str
    message: Union[str, None] = None
    audio: Union[UploadFile, None] = None
    audio_response_flag: bool = True
    model_name: Union[str, None] = None


@app.post("/response")
async def response(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: PatientMessage):
    start = time.time()

    success = EveInitializer.initialize_eve_instance(
        payload.username, model_name=payload.model_name)

    # if result[0].user_name != payload.username:
    #     raise HTTPException(status_code=401, detail="User name in authentication token and username sent in payload is different.")

    audio_response_path = None

    if payload.message is None and payload.audio is None:
        raise HTTPException(status_code=400, detail="Message is empty")
    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if payload.audio:
        audio_path = os.path.join(
            current_dir, "TEMP", eve.username, "audio", payload.audio.filename)
        os.makedirs(os.path.dirname(audio_path), exist_ok=True)
        with open(audio_path, "wb") as f:
            f.write(payload.audio.file.read())
        user_input = eve.speech_to_text.transcribe(audio_path)
    else:
        user_input = payload.message
    eve_response_start = time.time()
    # response_dict = eve.response(user_input, audio_response_flag=payload.audio_response_flag)
    response_dict = eve.response_with_survey(
        user_input, audio_response_flag=payload.audio_response_flag)
    eve_response_end = time.time()
    print(
        f"Time taken to get response from eve: {eve_response_end-eve_response_start}")
    eve_message, audio_response_path, survey = response_dict[
        "eve_message"], response_dict["audio_path_file"], response_dict["survey"]

    if payload.audio_response_flag:
        with open(audio_response_path, "rb") as f:
            audio_bytes = f.read()
        # audio_response = FileResponse(audio_response_path, media_type="audio/mpeg")
        audio_base64 = base64.b64encode(audio_bytes).decode("utf-8")
        return {"message": "Correctly processed",
                "data": {"message_id": response_dict['message_id'], "response": eve_message, "audio_b64": audio_base64, "survey": survey, "sessoion_id": eve.session_id}}
    end = time.time()
    return {"message": "Correctly processed",
            "data": {"message_id": response_dict['message_id'], "response": eve_message, "audio_b64": None, "survey": survey, "sessoion_id": eve.session_id, "response_time": end-start}}


class PatientMessage(BaseModel):
    username: str
    message: Union[str, None] = None
    audio: Union[UploadFile, None] = None
    audio_response_flag: bool = True
    model_name: Union[str, None] = None
    qid: Union[int, None] = None


@app.post("/response2")
async def response(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: PatientMessage):
    start = time.time()

    success = EveInitializer.initialize_eve_instance(
        payload.username, model_name=payload.model_name)

    # if result[0].user_name != payload.username:
    #     raise HTTPException(status_code=401, detail="User name in authentication token and username sent in payload is different.")

    audio_response_path = None

    if payload.message is None and payload.audio is None:
        raise HTTPException(status_code=400, detail="Message is empty")
    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if payload.audio:
        audio_path = os.path.join(
            current_dir, "TEMP", eve.username, "audio", payload.audio.filename)
        os.makedirs(os.path.dirname(audio_path), exist_ok=True)
        with open(audio_path, "wb") as f:
            f.write(payload.audio.file.read())
        user_input = eve.speech_to_text.transcribe(audio_path)
    else:
        user_input = payload.message
    eve_response_start = time.time()
    # response_dict = eve.response(user_input, audio_response_flag=payload.audio_response_flag)
    response_dict = eve.response_with_survey(
        user_input, audio_response_flag=payload.audio_response_flag, qid=payload.qid)
    eve_response_end = time.time()
    print(
        f"Time taken to get response from eve: {eve_response_end-eve_response_start}")
    eve_message, audio_response_path, survey = response_dict[
        "eve_message"], response_dict["audio_path_file"], response_dict["survey"]

    if payload.audio_response_flag:
        with open(audio_response_path, "rb") as f:
            audio_bytes = f.read()
        # audio_response = FileResponse(audio_response_path, media_type="audio/mpeg")
        audio_base64 = base64.b64encode(audio_bytes).decode("utf-8")
        return {"message": "Correctly processed",
                "data": {"message_id": response_dict['message_id'], "response": eve_message, "audio_b64": audio_base64, "survey": survey, "sessoion_id": eve.session_id}}
    end = time.time()
    return {"message": "Correctly processed",
            "data": {"message_id": response_dict['message_id'], "response": eve_message, "audio_b64": None, "survey": survey, "sessoion_id": eve.session_id, "response_time": end-start}}


class message_feedback(BaseModel):
    username: str
    message_id: str
    feedback: str


@app.post("/message_feedback")
def message_feedback(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: message_feedback):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]
    eve.conversation_manager.add_feedback(
        message_id=payload.message_id, feedback=payload.feedback)

    return {"message": "Feedback saved",
            "data": None}


class indicators(BaseModel):
    username: str
    session_id: Union[str, None] = None
    from_date: Union[str, None] = None
    to_date: Union[str, None] = None
    aggregate: bool = False


@app.post("/indicators")
def indicators(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: indicators):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    indicators = eve.user_manager.get_indicators(
        session_id=payload.session_id, from_date=payload.from_date, to_date=payload.to_date, aggregate=payload.aggregate)

    return indicators.to_dict('records')

class mindmap_node(BaseModel):
    node_id: Union[int, None] = None

class NodeResponse(BaseModel):
    id: int
    user_id: int
    company_id: int
    session_id: str
    parent_node_id: Optional[int]
    node_name: str
    description: Optional[str]
    child_node_ids: Optional[list[int]]
    sibling_node_ids: Optional[list[int]]
    conversation_sample: Optional[str]
    tags: Optional[List[str]]
    ai_insights: Optional[str]
    created_on: Optional[str]
    updated_on: Optional[str]

@app.post("/get_node")
async def get_node(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: mindmap_node, db: Annotated[AsyncSessionLocal, Depends(get_db)]):
    try:
        user_detail, result = result
        
        nodes_access_provider = GenericAccessProvider(Nodes, db)
        nodes_service = NodesServiceProvider(nodes_access_provider)
        
        node = await nodes_service.fetch_row_by_id(payload.node_id)
        
        if not node:
            raise HTTPException(status_code=404, detail="Node not found")
        
        if node.user_id != user_detail.id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        return NodeResponse(
            id = node.id,
            user_id = node.user_id,
            company_id = node.company_id,
            session_id = node.session_id,
            parent_node_id = node.parent_node_id,
            node_name = node.node_name,
            description = node.description,
            child_node_ids = list(node.child_node_ids) if node.child_node_ids else None,
            sibling_node_ids = list(node.sibling_node_ids) if node.sibling_node_ids else None,
            conversation_sample = node.conversation_sample,
            tags = node.tags,
            ai_insights = node.ai_insights,
            created_on = node.created_on.isoformat() if node.created_on else None,
            updated_on = node.updated_on.isoformat() if node.updated_on else None
        )
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        print(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


class NodeResponseWithNames(BaseModel):
    id: int
    user_id: int
    company_id: int
    session_id: str
    parent_node: Optional[dict]
    node_name: str
    description: Optional[str]
    child_nodes: Optional[List[dict]]
    sibling_nodes: Optional[List[dict]]
    conversation_sample: Optional[str]
    tags: Optional[List[str]]
    ai_insights: Optional[str]
    created_on: Optional[str]
    updated_on: Optional[str]

class node_with_names(BaseModel):
    node_id: Union[int, None] = None

@app.post("/node_with_names")
async def node_with_names(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: node_with_names, db: Annotated[AsyncSessionLocal, Depends(get_db)]):
    try:
        user_detail, result = result
        
        nodes_access_provider = GenericAccessProvider(Nodes, db)
        nodes_service = NodesServiceProvider(nodes_access_provider)
        
        node = await nodes_service.fetch_row_by_id(payload.node_id)
        
        if not node:
            raise HTTPException(status_code=404, detail="Node not found")
        
        if node.user_id != user_detail.id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Fetch parent node
        parent_node = await nodes_service.fetch_row_by_id(node.parent_node_id) if node.parent_node_id else None
        
        # Fetch child nodes
        child_nodes = []
        if node.child_node_ids:
            for child_id in node.child_node_ids:
                child_node = await nodes_service.fetch_row_by_id(child_id)
                if child_node:
                    child_nodes.append({"id": child_node.id, "name": child_node.node_name})
        
        # Fetch sibling nodes
        sibling_nodes = []
        if node.sibling_node_ids:
            for sibling_id in node.sibling_node_ids:
                sibling_node = await nodes_service.fetch_row_by_id(sibling_id)
                if sibling_node:
                    sibling_nodes.append({"id": sibling_node.id, "name": sibling_node.node_name})
        
        return NodeResponseWithNames(
            id = node.id,
            user_id = node.user_id,
            company_id = node.company_id,
            session_id = node.session_id,
            parent_node = {"id": parent_node.id, "name": parent_node.node_name} if parent_node else None,
            node_name = node.node_name,
            description = node.description,
            child_nodes = child_nodes if child_nodes else None,
            sibling_nodes = sibling_nodes if sibling_nodes else None,
            conversation_sample = node.conversation_sample,
            tags = node.tags,
            ai_insights = node.ai_insights,
            created_on = node.created_on.isoformat() if node.created_on else None,
            updated_on = node.updated_on.isoformat() if node.updated_on else None
        )
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        print(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


class NodeListResponse(BaseModel):
    id: int
    node_name: str
    description: str
    parent_node_id: Optional[int]

@app.post("/get_user_nodes")
async def get_user_nodes(
    result: Annotated[dict, Depends(TokenVerifier().verify_employee)],
    db: Annotated[AsyncSessionLocal, Depends(get_db)]
):
    try:
        user_detail, _ = result
        
        nodes_access_provider = GenericAccessProvider(Nodes, db)
        nodes_service = NodesServiceProvider(nodes_access_provider)
        
        # Fetch all nodes for the user
        user_nodes = await nodes_service.filter_rows( filters= {
                    "user_id": user_detail.id,
                    "company_id": user_detail.company_id,
                })
        
        if not user_nodes:
            return {"message": "No nodes found for this user", "data": []}
        
        node_list = [
            NodeListResponse(
                id = node.id,
                user_id = node.user_id,
                company_id = node.company_id,
                session_id = node.session_id,
                parent_node_id = node.parent_node_id,
                node_name = node.node_name,
                description = node.description,
                child_node_ids = list(node.child_node_ids) if node.child_node_ids else None,
                sibling_node_ids = list(node.sibling_node_ids) if node.sibling_node_ids else None,
                conversation_sample = node.conversation_sample,
                tags = node.tags,
                ai_insights = node.ai_insights,
                created_on = node.created_on.isoformat() if node.created_on else None,
                updated_on = node.updated_on.isoformat() if node.updated_on else None
            )
            for node in user_nodes
        ]
        
        return node_list
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        print(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


class DeleteNode(BaseModel):
    node_id: int

@app.delete("/delete_node")
async def delete_node(
    result: Annotated[dict, Depends(TokenVerifier().verify_employee)],
    payload: DeleteNode,
    db: Annotated[AsyncSessionLocal, Depends(get_db)]
):
    try:
        user_detail, _ = result
        
        nodes_access_provider = GenericAccessProvider(Nodes, db)
        nodes_service = NodesServiceProvider(nodes_access_provider)
        
        # Fetch the node to be deleted
        node = await nodes_service.fetch_row_by_id(payload.node_id)
        
        if not node:
            raise HTTPException(status_code=404, detail="Node not found")
        
        if node.user_id != user_detail.id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        if node.child_node_ids:
            if len(node.child_node_ids)>0:
                return {"message": "Only the end points can be deleted."}
        
        if node.node_name == "YOU":
            return {"message": "Root node cannot be deleted."}
        
        # Update parent node
        if node.parent_node_id:
            parent_node = await nodes_service.fetch_row_by_id(node.parent_node_id)
            if parent_node:
                await nodes_service.update_row(parent_node.id, {
                    "child_node_ids" : set([id for id in parent_node.child_node_ids if id != node.id])
                })
        
        # Update sibling nodes
        if node.sibling_node_ids:
            for sibling_id in node.sibling_node_ids:
                sibling_node = await nodes_service.fetch_row_by_id(sibling_id)
                if sibling_node:
                    await nodes_service.update_row(sibling_node.id, {
                        "sibling_node_ids" : set([id for id in sibling_node.sibling_node_ids if id != node.id])
                    })
        
        # Delete the node
        await nodes_service.delete_row(node.id)
        
        return {"message": "Node deleted successfully"}
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        print(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# class node_notes(BaseModel):
#     username: str
#     node_id: int
#     notes: str


# @app.post("/uptade_node_notes")
# def node_note(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: node_notes):
#     if result[0].user_name != payload.username:
#         raise HTTPException(
#             status_code=401, detail="User name in authentication token and username sent in payload is different.")

#     if not payload.username in user_eve_instances:
#         raise HTTPException(
#             status_code=400, detail="Eve is not initialized for this user")

#     eve = user_eve_instances[payload.username]
#     eve.user_manager.database.update_node_notes(
#         node_id=payload.node_id, note=payload.notes)

#     return {"message": "Node notes saved",
#             "data": None}


class todo_survey_(BaseModel):
    username: str

# get list of survey for given user.


@app.post("/todo_survey")
def todo_survey(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: todo_survey_):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    survey_df = eve.user_manager.database.get_survey_df()
    return {"message": "Data available",
            "data": survey_df.to_dict('records')}


class NextQuestion(BaseModel):
    username: str
    survey_id: int
    number_of_questions: int = 1
# get next question from the servey


@app.post("/survey_next_questions")
def survey_next_questions(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: NextQuestion):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    survey_formatted = eve.user_manager.database.get_survey_next_questions(
        survey_id=payload.survey_id, number_of_questions=payload.number_of_questions)
    # question_dicts = eve.obtain_question(question_id = None, return_dict = True, n_questions = payload.number_of_questions)

    return {"message": "Data available",
            "data": survey_formatted}


class Response(BaseModel):
    username: str
    survey_id: int
    responses: Dict[int, int]


@app.post("/response_survey")
def response_survey(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: Response):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]
    survey_response = {'survey_id': payload.survey_id,
                       'username': payload.username, 'responses': payload.responses}
    eve.user_manager.database.insert_survey_response(survey_response)

    return {"message": "Survey response saved",
            "data": None}


class user_conv(BaseModel):
    username: str


@app.post("/user_conversations")
def get_user_conversations(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], message: user_conv):
    if result[0].user_name != message.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not message.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[message.username]
    conversations_list = eve.user_manager.database.get_session_history_data_as_dataframe(
        session_id=None)
    if len(conversations_list) > 0:
        conversations_list = conversations_list[[
            'message_id', 'message', 'role']].copy()
        # change role to a boolean column isEve (True if the role is eve)
        conversations_list['isEve'] = conversations_list['role'].apply(
            lambda x: True if x == 'Eve' else False)
        conversations_list.drop(columns=['role'], inplace=True)
        conversations_list = conversations_list.to_dict('records')
    else:
        conversations_list = []

    actual_conversation = eve.conversation_manager.get_conversation()
    if len(actual_conversation) > 0:
        actual_conversation = actual_conversation.split("\n")
        # add message_id to the conversation
        biggest_message_id = conversations_list[-1]['message_id'] if len(
            conversations_list) > 0 else 0
        actual_list = [{'message_id': biggest_message_id + i + 1, 'message': message[len("User:" if message.startswith("User:") else "EVE:"):].strip(
        ), 'isEve': message.startswith("EVE:")} for i, message in enumerate(actual_conversation) if message.startswith("User:") or message.startswith("EVE:")]
        conversations_list = conversations_list + actual_list

    if len(conversations_list) == 0:
        return {"message": "No data available",
                "data": None}
    else:
        return {
            "message": 'Data available',
            "data": conversations_list
        }


class UserDashboard(BaseModel):
    username: str
    start_filter_date: Union[str, None] = None
    end_filter_date: Union[str, None] = None
    aggregate: bool = False
    wheited: bool = True
    last_session: bool = False
    period: str = 'weekly'


@app.post("/user_dashboard")
def user_dashboard(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: UserDashboard):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    """Example of a user dashboard output: 
        dashboard: is a dict with the following keys:
        - main_indicators: dict with the keys:
                * 'stress_score': float,
                * 'delta_stress_score': float,
                * 'depression_score': float,
                * 'delta_depression_score':float,
                * 'positive_score': float,
                * 'delta_positive_score':float,
                * 'neutral_score': float,
                * 'delta_neutral_score':float,
                * 'negative_score': float,
                * 'delta_negative_score': float
        - positive_emotions: dict with the keys:
                * '1_emotion_name': float,
                * '1_emotion_score':float,
                * '2_emotion_name': float,
                * '2_emotion_score':float,  
                * '3_emotion_name': float,
                * '3_emotion_score': float,
        - neutral_emotions: dict with the keys:
                * '1_emotion_name': float,
                * '1_emotion_score':float,
                * '2_emotion_name': float,
                * '2_emotion_score':float,  
                * '3_emotion_name': float,
                * '3_emotion_score': float,
        - negative_emotions: dict with the keys:
                * '1_emotion_name': float,
                * '1_emotion_score':float,
                * '2_emotion_name': float,
                * '2_emotion_score':float,  
                * '3_emotion_name': float,
                * '3_emotion_score': float,
        - mental_health: dict with the keys of each period of time:
                * '1' : dict with the keys:
                        + period: str : 'dd/mm/yyyy - dd/mm/yyyy'
                        + positive_score: float
                        + neutral_score: float
                        + negative_score: float
                * '2' : ....
        - evolution_metrics: dict with the keys of each period of time:
                * '1' : dict with the keys:
                        + period: str : 'dd/mm/yyyy - dd/mm/yyyy'
                        + stress_score: float
                        + depression_score: float
                        + positive_score: float
                * '2' : ....
    
    
    """

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]
    dashboard = eve.user_manager.database.get_user_dashboard(start_filter_date=payload.start_filter_date,
                                                             end_filter_date=payload.end_filter_date,
                                                             aggregate=payload.aggregate,
                                                             wheited=payload.wheited,
                                                             last_session=payload.last_session)

    if dashboard:
        # Change the format
        dashboard = ritik_format(dashboard)
        return {"message": "Data available",
                "data": dashboard}
    else:
        return {"message": "No data available in the selected period",
                "data": None}


class CompanyDashboard(BaseModel):
    username: str
    filters: Union[dict[str, List[str]], None] = None
    start_filter_date: Union[str, None] = None
    end_filter_date: Union[str, None] = None
    aggregate: bool = False
    wheited: bool = True
    last_session: bool = False
    period: str = 'weekly'


@app.post("/company_dashboard")
def company_dashboard(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: CompanyDashboard):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(
            status_code=401, detail="User is not authorized to get company dashboard data")

    companyDB = CompanyDatabase(eve.user_type)
    dashboard = companyDB.get_company_dashboard(period=payload.period,
                                                start_filter_date=payload.start_filter_date,
                                                end_filter_date=payload.end_filter_date,
                                                aggregate=payload.aggregate,
                                                wheited=payload.wheited,
                                                last_session=payload.last_session,
                                                filters=payload.filters)
    del companyDB
    if dashboard:
        # dashboard = ritik_format(dashboard) # Here we need to change the functions
        return {"message": "Data available",
                "data": dashboard}
    else:
        return {"message": "No data available in the selected period/with the selected filters",
                "data": None}


class finalize_eve_(BaseModel):
    username: str


@app.post("/finalize_eve")
def finalize_eve(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: finalize_eve_):
    try:
        if result[0].user_name != payload.username:
            raise HTTPException(
                status_code=401, detail="User name in authentication token and username sent in payload is different.")

        if not payload.username in user_eve_instances:
            raise HTTPException(
                status_code=400, detail="Eve is not initialized for this user")

        eve = user_eve_instances.pop(payload.username)

        # delete temporary files
        eve.finalize()
        tmp_folder_path = os.path.join(current_dir, "TEMP", eve.username)

        # Check if the folder exists
        if os.path.exists(tmp_folder_path):
            # Remove the folder and its contents
            shutil.rmtree(tmp_folder_path)
            print(f"Removed folder and its contents: {tmp_folder_path}")
        else:
            print(f"Folder does not exist: {tmp_folder_path}")

        # delete eve object
        del eve
        # create new eve object
        return {"message": "Eve finalized",
                "data": None}
    except Exception as e:
        print_exc()
        logger.error(
            f"Unhandled error: {e}\nDetailed traceback is {print_exc()}", exc_info=True)
        return {"message": f"{e}\nDetailed traceback is {print_exc()}",
                "data": None}


class Question(BaseModel):
    question: str
    options: List[str] | None = None
    option_type: str  # 'single', 'multiple' or 'text'


class Survey(BaseModel):
    name: str
    date: str
    due_date: str
    questions: List[Question]


class InsertSurvey(BaseModel):
    username: str
    survey: Survey


@app.post("/insert_new_survey")
def insert_new_survey(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: InsertSurvey):
    try:
        if result[0].user_name != payload.username:
            raise HTTPException(
                status_code=401, detail="User name in authentication token and username sent in payload is different.")

        if not payload.username in user_eve_instances:
            raise HTTPException(
                status_code=400, detail="Eve is not initialized for this user")

        eve = user_eve_instances[payload.username]

        if result[0].role not in ['company_admin', 'super_admin']:
            raise HTTPException(
                status_code=401, detail="User is not authorized to insert a new survey")

        survey_db = SurveyDatabase("company")
        survey_db.insert_new_survey(survey_json=payload.survey.model_dump())
        return {"message": "Survey inserted",
                "data": None}

    except Exception as e:
        print_exc()
        logger.error(f"Not able to insert survey for {payload.username}")
        raise Exception(f"Not able to insert survey for {payload.username}")


class SurveyID(BaseModel):
    username: str
    survey_id: int


@app.post("/get_survey_json")
def get_survey_json(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: SurveyID):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if payload.username not in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if result[0].role not in ['company_admin', 'super_admin']:
        raise HTTPException(
            status_code=401, detail="User is not authorized to access surveys")

    survey_db = SurveyDatabase("company")
    try:
        survey_json = survey_db.get_survey_json(survey_id=payload.survey_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    return {"message": "Survey retrieved", "data": survey_json}


class ModifySurvey(InsertSurvey):
    survey_id: int
    survey: Survey


@app.put("/modify_survey")
def modify_survey(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: ModifySurvey):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if payload.username not in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if result[0].role not in ['company_admin', 'super_admin']:
        raise HTTPException(
            status_code=401, detail="User is not authorized to modify surveys")

    survey_db = SurveyDatabase("company")
    try:
        survey_db.edit_survey(survey_id=payload.survey_id,
                              survey_json=payload.survey.model_dump())
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    return {"message": "Survey modified", "data": None}


@app.delete("/delete_survey")
def delete_survey(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: SurveyID):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if payload.username not in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if result[0].role not in ['company_admin', 'super_admin']:
        raise HTTPException(
            status_code=401, detail="User is not authorized to delete surveys")

    survey_db = SurveyDatabase("company")
    try:
        survey_db.delete_survey(survey_id=payload.survey_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    return {"message": "Survey deleted", "data": None}


class delete_user(BaseModel):
    username: str
    username_to_delete: str


@app.post("/delete_user")
def delete_user(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: delete_user):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if result[0].role not in ['company_admin', 'super_admin']:
        raise HTTPException(
            status_code=401, detail="User is not authorized to delete a user")

    eve.user_manager.delete_user(payload.username_to_delete)

    return {"message": "User deleted",
            "data": None}


class getsurveysresponses(BaseModel):
    username: str
    survey_id: int


@app.post("/getsurveysresponses")
def getsurveysresponses(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: getsurveysresponses):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if result[0].role not in ['employee', 'company_admin', 'super_admin']:
        raise HTTPException(
            status_code=401, detail="Not authorized to get survey responses")

    survey_db = SurveyDatabase(eve.user_type)
    get_survey_responses = survey_db.get_survey_responses(
        survey_id=payload.survey_id)
    if get_survey_responses:
        return {"message": "Data available",
                "data": get_survey_responses}
    else:
        return {"message": "No data available",
                "data": None}


class InsertCompanyInfo(BaseModel):
    username: str
    company_name: str
    industry: str
    address: str
    company_email: str
    company_number: str
    company_logo: str
    business_hours: Dict[str, str]
    services_offered: str
    company_description: str


@app.post("/insert_company_info")
def insert_company_info(result: Annotated[dict, Depends(TokenVerifier().verify_employee)], payload: InsertCompanyInfo):
    if result[0].user_name != payload.username:
        raise HTTPException(
            status_code=401, detail="User name in authentication token and username sent in payload is different.")

    if not payload.username in user_eve_instances:
        raise HTTPException(
            status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(
            status_code=401, detail="User is not authorized to get company dashboard data")
    # Create a list of service offered by the company
    services_offered = [service.strip()
                        for service in payload.services_offered.split(",")]
    companyDB = CompanyDatabase(eve.user_type)
    company_info = {
        "company_name": payload.company_name,
        "industry": payload.industry,
        "address": payload.address,
        "company_email": payload.company_email,
        "company_number": payload.company_number,
        "company_logo": payload.company_logo,
        "business_hours": payload.business_hours,
        "services_offered": services_offered,
        "company_description": payload.company_description
    }
    companyDB.insert_company_info(company_info)
    return {"message": "Company info inserted",
            "data": None}

# class GetCompanyInfo(BaseModel):
#     username: str
# @app.post("/get_company_info")
# def get_company_info(result: Annotated[dict, Depends(TokenVerifier().verify_employee)],payload: GetCompanyInfo):
#     if result[0].user_name != payload.username:
#         raise HTTPException(status_code=401, detail="User name in authentication token and username sent in payload is different.")

#     if not payload.username in user_eve_instances:
#         raise HTTPException(status_code=400, detail="Eve is not initialized for this user")

#     eve = user_eve_instances[payload.username]

#     if eve.user_type == "user":
#         raise HTTPException(status_code=401, detail="User is not authorized to get company dashboard data")

#     companyDB = CompanyDatabase(eve.user_type)
#     company_info = companyDB.get_company_info()
#     return {"message": "Company info available",
#             "data": company_info}


@app.get("/")
def read_root():
    return "Talk to Eve API is running"


# Run the application directly using Uvicorn
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)


# no bullet point
# survey question
# voice api (working in local)
