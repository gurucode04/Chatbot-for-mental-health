from keybert import KeyBERT
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import sys
import os
import pandas as pd
import re

current_dir = os.path.dirname(os.path.abspath(__file__))  
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.global_configs import OPENAI_API_KEY
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

from openai import OpenAI

def response_to_df(response):
    lines = response.split('\n')
    nodes = []
    parent_nodes = []
    
    for line in lines:
        parts = line.split(', ')
        for part in parts:
            if part.startswith('node:'):
                nodes.append(part.split(': ')[1])
            elif part.startswith('parent node:'):
                parent_nodes.append(part.split(': ')[1])
    
    df = pd.DataFrame({
        'nodes': nodes,
        'parent_nodes': parent_nodes
    })
    
    return df

def keyphrases_df(chat):
    prompt = """
        you are a prestigious psychologist, I need you to carefully analyse the following conversation and construct a graph of the most important key phrases you identify. Eve is a therapist ia and User is the client.
    The format should be exactly like this, because I will use it in an algorithm to generate a graph:
    node: key phrase, parent node: category of the phrase. Avoid creating keyphrases about what Eve says, only what the user says.
    this is the conversation:
    """
    prompt += chat
    try:
        cliente = OpenAI()
        respuesta = cliente.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}]
        )
        return response_to_df(respuesta.choices[0].message.content)
    except Exception as e:
        return f"Error al obtener respuesta: {str(e)}"

def get_nodes_from_category(kw_model, messages_list, node_list, threshold=None, normalize=True, n_max=None):
    nodes_embeddings, _ = kw_model.extract_embeddings(node_list)
    messages_embeddings, _ = kw_model.extract_embeddings(messages_list)
    
    similarity_matrix = cosine_similarity(messages_embeddings, nodes_embeddings)
    
    if normalize:
        similarity_matrix = (similarity_matrix - similarity_matrix.min(axis=1, keepdims=True)) / \
                            (similarity_matrix.max(axis=1, keepdims=True) - similarity_matrix.min(axis=1, keepdims=True))

    if threshold is None:
        threshold = 0.2  
    
    
    relevant_nodes_indices = np.where(similarity_matrix.max(axis=0) >= threshold)[0]
    filtered_nodes = [node_list[i] for i in relevant_nodes_indices]

    if n_max is None:
        n_max = len(filtered_nodes)
        
    
    filtered_nodes = filtered_nodes[:n_max]
    
    message_ids = []
    nodes_list = []
    
    for i, node in enumerate(filtered_nodes):
        message_ids.append(i)  
        nodes_list.append(node)
    
    result_df = pd.DataFrame({'message_id': message_ids, 'node': nodes_list})
    
    return result_df, similarity_matrix

def keywords_from_embeddings_similarities(user_messages):
    kw_model = KeyBERT('all-MiniLM-L6-v2')
    
    path = os.path.join(grandparent_dir, "documents", "Keywords", "TTE_Graph dataset_corrected.csv")
    keywords_df = pd.read_csv(path) 
    nodes = keywords_df["Category"].unique().tolist()
    
    
    result_df, _ = get_nodes_from_category(kw_model, user_messages, nodes, threshold=0.2, normalize=True, n_max=10)
    
    parent_nodes = []
    for node in result_df['node']:
        parent_node = keywords_df[keywords_df['Category'] == node]['Parent Node'].values[0]
        parent_nodes.append(parent_node)
    result_df['parent_node'] = parent_nodes
    
    return result_df