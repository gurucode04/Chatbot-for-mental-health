import os
import sys
import threading

current_dir = os.path.dirname(os.path.abspath(__file__))
# Obtain the parent directory
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)
 
from modules.conversation_manager.conversation_manager import ConversationManager 
from modules.models_manager.models_manager import ModelsManager
from modules.speech_to_text.speech_to_text import S2T_with_openai
from modules.text_to_speech.text_to_speech import T2S_with_openai
from modules.users_manager.user_manager import UserManager
from modules.databases_sql.databases import SurveyDatabase
# Load configs 
from modules.global_configs import MODELS, OPENAI_API_KEY, VECTOR_DB_PATH
from modules.auxiliar_functions import intercalar_con_nan, intercalar_con_nan_df
# Import the vector database searcher
from vector_database.vector_database import VectorDatabase
from vector_database.survey_chroma import ChromaSurvey
# Import the functions to calculate the stress
from analysis.analysis import *
from keywords.keywords import  keywords_from_embeddings_similarities
from traceback import print_exc
from utils.logger import setup_logger
from openai_service.response_generator import ResponseGenerator, user_conversations

class Eve():
    def __init__(self,):
        # Configure the API key
        os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
        
        # Initialie the conversation manager
        self.conversation_manager = ConversationManager()
        # Initialize the conversation analysis
        self.models_manager = ModelsManager()
        self.models_manager.load_prompts(MODELS)
        
        # TODO add this 3 to the models manager
        self.speech_to_text = S2T_with_openai()
        self.audio_generator = T2S_with_openai()
        self.vectordabase_serch = VectorDatabase(db_path=VECTOR_DB_PATH)
        
        # Initialize eve flag
        self.use_vector_database = False
        self.initialized_flag = False
        self.temp_path = None
        self.username = None
        
        
    def initialize(self, username = None, password = None, survey_on_conv_flow=True):
        self.username = username
        # User manager
        self.user_manager = UserManager(self.username)
        # user_type
        self.user_type = self.user_manager.database.get_user_type()
        # session id
        self.session_id = self.user_manager.database.get_session_id()
        # Check for backups in the user folder
        check_backup = self.user_manager.check_for_conv_manager_backup()
        if check_backup[0]:
            self.conversation_manager.load_conversation(check_backup[1])
        # Login process
        self.user_manager.initialize_user_database(username=username)
        self.user_manager.database.check_and_load_surveys_into_user_db()
        # Survey database
        self.survey_db = SurveyDatabase(self.user_type)

        # survey chroma
        self.chroma_survey = ChromaSurvey(os.path.join('documents','surveys'), self.user_manager, survey_on_conv_flow=survey_on_conv_flow)
        
        # Load temp path
        self.load_tmp_file()
        
        # Load the information requiered for the conversation
        self.models_manager.load_information(info_key = 'personal_information', information=self.user_manager.give_personal_information(return_dict=False))
        self.models_manager.predict(info_key = 'context', 
            input_variables={'conversations_summaries' : self.user_manager.database.conversation_summaries(), 
                            'emotions' : self.user_manager.database.get_user_dashboard()})

        self.initialized_flag = True
        
    def load_tmp_file(self,):
        self.temp_path = os.path.join('app','TEMP',self.username)
        # Check if path exists and if not create it
        if not os.path.exists(self.temp_path):
            os.makedirs(self.temp_path)    
        # Folders to create
        folders_create = ['audio_responses']
        
        for folder in folders_create:
            # Check if path exists and if not create the folder
            if not os.path.exists(os.path.join(self.temp_path, folder)):
                os.mkdir(os.path.join(self.temp_path, folder))
         
   
    def response_survey_question(self, survey_id, question_id, answer_id):
        response = {'username': self.username,'survey_id': survey_id, 'response': {question_id, answer_id}}
        self.user_manager.database.insert_survey_response(response)
        
    def response_text(self, message):
        
        if self.use_vector_database:
            # Add patient message to memory
            self.conversation_manager.add_message(message, is_ai_message = False)
            
            # Search in database
            eve_message = self.vectordabase_serch.predict(message)
            
            # Add AI assistant message to memory
            self.conversation_manager.add_message(eve_message, is_ai_message = True)
        else:
            # Add patient message to memory
            self.conversation_manager.add_message(message, is_ai_message = False)
            # Obtain the response of the chatbot
            eve_message = self.models_manager.predict(info_key = 'eve_response', input_variables =
                {'patient_message' : message,
                'personal_information' : self.models_manager.information['personal_information'],
                'previous_conversations_summary' : self.models_manager.information['context'],
                'last_messages' : self.conversation_manager.get_n_last_messages(n_last_messages = 20)})
            
            # Add AI assistant message to memory
            self.conversation_manager.add_message(eve_message, is_ai_message = True)
                
        return eve_message
    
    def response(self, user_input, audio_response_flag = False):
        try:
            survey = None
            audio_path_file = None
            # Check for survey in conv flow
            if self.chroma_survey.survey_on_conv_flow:
                survey = self.chroma_survey.search_message(user_input)
                if survey:
                    # Add patient message to memory
                    self.conversation_manager.add_message(user_input, is_ai_message = False)
                    # Obtain the survey message
                    eve_message = survey['title']
                    # Add AI assistant message to memory
                    self.conversation_manager.add_message(eve_message, is_ai_message = True)
                else:
                    # Obtain the response of Eve
                    eve_message = self.response_text(user_input)
            else:
                # Obtain the response of Eve
                eve_message = self.response_text(user_input)
            
            if audio_response_flag:
                # If the response is a audio, we process the audio
                audio_path = os.path.join(self.temp_path, 'audio_responses')
                audio_path_file = self.audio_generator.create(eve_message, path_to_save = audio_path)

            # save a backup of the conversation
            self.conversation_manager.save_conversation(self.user_manager.conversation_manager_backup_path)
        except Exception as e:
            print_exc()
            setup_logger().error(f"Unhandled error: {e}\nDetailed traceback is {print_exc()}", exc_info=True)
            return {'message_id': self.conversation_manager.message_id-1 ,'eve_message': 'I am sorry, I am having trouble understanding you. Can you please repeat that?', 'audio_path_file': None, 'survey': None}            
        return {'message_id': self.conversation_manager.message_id-1 ,'eve_message': eve_message,'audio_path_file': audio_path_file, 'survey': survey}

    def response_with_survey(self, user_input, audio_response_flag = False,qid=None):
        try:
            survey = None
            audio_path_file = None
            # Check for survey in conv flow
            if self.chroma_survey.survey_on_conv_flow:
                
                # check if Q_id present. get answer if available | update answer in the table.
                    # if present then process respnse and get Question answer from the response
                        # if answer is present the update the database.
                if qid:
                    pass


                # for given query get the question from the chromadb
                survey = self.chroma_survey.search_message_survey(user_input)
                if survey:
                    # Obtain the survey message
                    eve_message = survey['title']
                    # create response using Question and user history.
                else:
                    # generate eve response from the user history.                
                    pass
            else:
                # Obtain the response of Eve
                eve_message = self.response_text(user_input)
            
            if audio_response_flag:
                # If the response is a audio, we process the audio
                audio_path = os.path.join(self.temp_path, 'audio_responses')
                audio_path_file = self.audio_generator.create(eve_message, path_to_save = audio_path)

            # save a backup of the conversation
            self.conversation_manager.save_conversation(self.user_manager.conversation_manager_backup_path)
        except Exception as e:
            print_exc()
            setup_logger().error(f"Unhandled error: {e}\nDetailed traceback is {print_exc()}", exc_info=True)
            return {'message_id': self.conversation_manager.message_id-1 ,'eve_message': 'I am sorry, I am having trouble understanding you. Can you please repeat that?', 'audio_path_file': None, 'survey': None}            
        return {'message_id': self.conversation_manager.message_id-1 ,'eve_message': eve_message,'audio_path_file': audio_path_file, 'survey': survey}


    
    def finalize(self,):
        try:
            # Upload survey responses to survey db
            if not 'test' in self.user_type:
                self.user_manager.database.upload_survey_responses_to_surveydb()
            # Update the personal Information
            current_conversation = self.conversation_manager.get_conversation()
            self.models_manager.predict(info_key = 'personal_information', input_variables = {'conversation': current_conversation, 'previous_information': self.models_manager.information['personal_information']})
            personal_info = self.models_manager.information['personal_information']
            self.user_manager.update_last_personal_information(personal_info)
            
            # Update the summary conversation
            last_messages = self.conversation_manager.get_n_last_messages()
            self.models_manager.predict(info_key = 'summary_conversation', input_variables = {'conversation': current_conversation})
            summary_conversation = self.models_manager.information['summary_conversation']
            
            # Obtain the conversation History as dictionary
            conversation_history = self.conversation_manager.get_conversation(return_dict = True)
            
            # Obtain only the messages from user
            user_messages = self.conversation_manager.get_user_messages(return_list = True)
            
            if len(user_messages) > 0:
                stress_score = stress_probas(user_messages)
                depression_score = depression_probas(user_messages)
                
                keyphrases_df_ = keywords_from_embeddings_similarities(user_messages)
                
                # Here we need to add to conversation_history a key that will be 'stress_score' and 'deṕression_score' only when role is User
                # Check and update conversation_history for user messages
                average_stress_score = stress_score.mean()
                average_depression_score = depression_score.mean()
                stress_score = intercalar_con_nan(stress_score, conversation_history['role'][-1])
                depression_score = intercalar_con_nan(depression_score, conversation_history['role'][-1])
                conversation_history['stress_score'] = stress_score
                conversation_history['depression_score'] = stress_score
                # go emotions 
                go_emotions_df = go_emotions(user_messages)
                # intercalar con nan
                go_emotions_df = intercalar_con_nan_df(go_emotions_df, conversation_history['role'][-1])
                # add to conversation history
                conversation_history = pd.DataFrame(conversation_history)
                conversation_history = pd.concat([conversation_history, go_emotions_df], axis=1)
                
                # convierto average_stress_score y average_depression_score en un dataframe
                average_sd = pd.DataFrame({'stress_score': [average_stress_score], 'depression_score':[average_depression_score]})
                average_go_emotions = pd.DataFrame(go_emotions_df.mean()).T
                average_indicators = pd.concat([average_sd, average_go_emotions], axis=1)
            

                # Now we need to save all the information in the database
                self.user_manager.save_user_database(session_history_data=conversation_history, 
                                                    summary=summary_conversation,
                                                    average_indicators=average_indicators, 
                                                    keyphrases_df=keyphrases_df_)
                
                self.user_manager.save_company_database()

            # delete conversation manager backup
            # check if the file exists
            if os.path.exists(self.user_manager.conversation_manager_backup_path):
                # delete the file
                os.remove(self.user_manager.conversation_manager_backup_path)
        except Exception as e:
            print_exc()
            setup_logger().error(f"Unhandled error: {e}\nDetailed traceback is {print_exc()}", exc_info=True)

            