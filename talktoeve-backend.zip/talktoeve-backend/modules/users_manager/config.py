import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Define the path odf list users
USERS_LIST_PATH = os.path.join(os.getcwd() , "users" , "users.csv")
# Define path root of user information
PATH_TO_SAVE = os.path.join(os.getcwd() , "users" )
# Users folders
PATH_USERS_FOLDERS = os.path.join(PROJECT_ROOT, "users")

PERSONAL_INFO_REQUIERED = ['name', 'age', 'nationality', 'location', 'position', 'area', 'vessel']
