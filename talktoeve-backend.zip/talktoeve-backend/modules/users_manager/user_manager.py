import pandas as pd
import os
import sys
import datetime
from fastapi import HTTPException
import shutil

# Obtain the current, parent and grandparent path and add to the sys path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(current_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from databases_sql.databases import UserDatabase, CompanyDatabase
from databases_sql.config_database import * 
from modules.users_manager.config import PATH_USERS_FOLDERS
from modules.auxiliar_functions import filter_columns
from traceback import print_exc
from utils.logger import setup_logger

class UserManager():
    """ This class is used to manage the users of the system. It used to manage the write and read the sql database of the users"""
    def __init__(self,username = None, sign_up = False):
        
        self.user_list = os.listdir(PATH_USERS_FOLDERS)
        if not sign_up:
            self.user_login(username = username)
        if username :
            path = os.path.join(PATH_USERS_FOLDERS, username, f"{username}.db")
        else:
            path = None
            
        self.database = UserDatabase(path=path)
        self.last_session_id = None
        self.actual_session_id = None
        self.date = None
        self.time_init = None
        self.time_finish = None
        self.username = username
        if not 'PATH_TO_SAVE' in globals():
            global PATH_TO_SAVE
            PATH_TO_SAVE = PATH_USERS_FOLDERS
        
        if username:
            self.conversation_manager_backup_path = os.path.join(PATH_USERS_FOLDERS, self.username, 'backup', 'conversation_manager_backup.pickle')

    def create_edit_user(self, personal_info):
        """
        personal_info: dict 
        """
        # add random number to the username
        personal_info['username'] = personal_info['username']

        if (not personal_info['edit']) and personal_info['username'] in self.user_list:
            raise HTTPException(status_code=400, detail="The user already exists")
        
        # Check if edit is True and the user does not exist
        if personal_info['edit'] and personal_info['username'] not in self.user_list:
            raise HTTPException(status_code=400, detail="The user does not exist")
            
        path = os.path.join(PATH_USERS_FOLDERS, personal_info['username'], f"{personal_info['username']}.db")

        self.database.set_database_path(path = path)
        personal_info.pop('username')
        personal_info.pop('edit')
        
        self.database.update_last_personal_information(personal_info)
        
    def initialize_user_database(self, username):
        path = os.path.join(PATH_USERS_FOLDERS, username, f"{username}.db")
        if not os.path.exists(path):
            # Give an error message
            raise ValueError(f"The user {username} does not exist")
        self.load_user_database(username)
        # Obtain the current date and time
        self.date = datetime.datetime.now().strftime("%Y_%m_%d")
        self.time_init = datetime.datetime.now()
        # Obtain the last session id
        _ = self.get_last_session_id()
        
    def save_user_database(self, session_history_data, summary, average_indicators, keyphrases_df):
        try:
            # Check that session_data, session_history_data and session_summary_data are dictionaries
            if not isinstance(session_history_data, pd.DataFrame):
                raise ValueError('Data must be a pd.DataFrame')    
            
            # Now we need to insert the data in the database
            # Insert session data
            session_data = {}
            session_data['session_id'] = self.actual_session_id
            session_data['date'] = self.date
            
            # Calculate the duration of the session
            duration = datetime.datetime.now() - self.time_init
            session_data['duration'] = str(duration.total_seconds())
            session_data['summary'] = str(summary)
            session_data = pd.DataFrame(session_data, index=[0])
            # concat the average indicators
            session_data = pd.concat([session_data, average_indicators], axis=1)
            
            self.insert_session_data(session_data)
            # Insert keyword data
            self.insert_keywords_data(keywords_data=keyphrases_df)
            
            # Now we need to add to session_history_data , the keys session_id, and the key tags
            n = len(session_history_data['message_id'])
            session_history_data['session_id'] = [self.actual_session_id] * n
            # Insert session history data
            self.insert_session_history_data(session_history_data)
        except Exception as e:
            print_exc()
            setup_logger().error(f"Unhandled error: {e}\nDetailed traceback is {print_exc()}", exc_info=True)
            raise HTTPException(status_code=500, detail="Failed to save the user database")
        
    def save_company_database(self,):
        # Here we need to obtain information from user database 
        personal_information = self.database.get_personal_information_as_dataframe()
        session_table = self.database.get_session_data_as_dataframe(session_id = self.actual_session_id)
        
        # Here we need to obtain the next information from the user database
        company_input = {'user_id': self.username,
                 'session_id': self.actual_session_id,}
        
        columns_to_save = set(DEFAULT_USERS_TABLE_DATABASE_v1.get('columns', []) + DEFAULT_USERS_TABLE_DATABASE_v1.get('encrypted_columns', []))
        columns_personal_information = filter_columns(DEFAULT_PERSONAL_INFO_v1, columns_to_save)
        columns_session_table = filter_columns(DEFAULT_SESSION_TABLE_v1, columns_to_save)

        for cc in columns_personal_information:
            company_input[cc] = personal_information[cc].values[0]

        for cc in columns_session_table:
            company_input[cc] = session_table[cc].values[0]

        company_db = CompanyDatabase(self.database.get_user_type())             
        company_db.insert_input(table_name = 'users_table', input_dict = company_input)
        
    def load_user_database(self, username):
        path = os.path.join(PATH_USERS_FOLDERS, username, f"{username}.db")
        self.database.set_database_path(path = path)
    
    def get_last_session_id(self):
        if self.last_session_id is None:
            sessions_id = self.database.get_all_session_ids()
            if len(sessions_id) == 0:
                self.last_session_id = '0'
            else:
                self.last_session_id = sessions_id[-1]
            self.actual_session_id = str(int(self.last_session_id) + 1) 
        return self.last_session_id
       
    def update_last_personal_information(self, personal_info):
        # Check if the personal_info is str
        if isinstance(personal_info, str):
            # Here we need to eliminate '>' or '<' from the string
            personal_info = personal_info.replace('<','').replace('>','')
            data_dict = {}
            lines = personal_info.split("\n")
            for line in lines:
                if line:
                    key, value = line.split(":")
                    data_dict[key] = value
            personal_info = data_dict
            
        # Check that personal_info is a dictionary
        if not isinstance(personal_info, dict):
            raise ValueError('Data must be a dictionary')
        self.database.update_last_personal_information(personal_info)

    def give_personal_information(self, return_dict = False):
        personal_info_df = self.database.get_personal_information_as_dataframe()
        if return_dict:
            return personal_info_df.to_dict()
        else:
            # Here convert the personal information df to dictionary and posteriori to strs
            personal_info = personal_info_df.to_dict()
            # Here we neeed to eliminate the ID key
            if 'personal_info_id' in personal_info.keys():
                personal_info.pop('personal_info_id')
            formatted_data = ""
            for key, value in personal_info.items():
                formatted_data += f"{key}:{value[0]}\n"
            return formatted_data

    def give_last_summary_conversation(self, return_dict = False):
        session_summary_df = self.database.get_session_summary_data_as_dataframe(self.last_session_id)
        if return_dict:
            return session_summary_df.to_dict()
        else:
            # Check if the session_summary_df is empty
            if session_summary_df.empty:
                summary = ""
            else:
                summary = session_summary_df['summary'].values[0]
            return summary
        
    def get_session_data_as_dataframe(self, session_id, return_dict = False):
        if return_dict:
            return self.database.get_session_data_as_dataframe(session_id).to_dict()
        else:
            return self.database.get_session_data_as_dataframe(session_id)
    
    def get_session_history_data_as_dataframe(self, session_id, return_dict = False):
        if return_dict:
            return self.database.get_session_history_data_as_dataframe(session_id).to_dict()
        else:
            return self.database.get_session_history_data_as_dataframe(session_id)
    
    def get_session_summary_data_as_dataframe(self, session_id,return_dict = False):
        if return_dict:
            return self.database.get_session_summary_data_as_dataframe(session_id).to_dict()
        else:
            return self.database.get_session_summary_data_as_dataframe(session_id)
        
    def insert_session_data(self, session_data):
        # Check that session_data is a dictionary
        if not isinstance(session_data, pd.DataFrame):
            raise ValueError('Data must be a pd.DataFrame')
        self.database.insert_session_data(session_data)
        
    def insert_session_history_data(self, session_history_data):
        # Check that session_history_data is a dictionary
        if not isinstance(session_history_data, pd.DataFrame):
            raise ValueError('Data must be a pd.DataFrame')
        self.database.insert_session_history_data(session_history_data)
    
    def insert_keywords_data(self, keywords_data):
        # Check that keywords_data is a pd.DataFrame
        if not isinstance(keywords_data, pd.DataFrame):
            raise ValueError('Data must be a pd.DataFrame')
        self.database.insert_keyphrases_data(keywords_data, session_id=self.actual_session_id)

    def get_indicators(self, session_id = None, from_date = None, to_date = None, aggregate = False):        
        # Obtain the indicators
        indicators = self.database.get_indicators(session_id=session_id, from_date=from_date, to_date=to_date, aggregate=aggregate)
        return indicators
    
    def get_keyphrases(self, session_id = None, from_date = None, to_date = None):        
        # Obtain the indicators
        keyphrases = self.database.get_keyphrases(session_id=session_id, from_date=from_date, to_date=to_date)
        return keyphrases
    
    def check_for_conv_manager_backup(self):
        # Check if the user has backups
        if 'backup' in os.path.join(PATH_USERS_FOLDERS, self.username):
            if 'conversation_manager_backup.pickle' in os.listdir(os.path.join(PATH_USERS_FOLDERS, self.username, 'backup')):
                return (True, self.conversation_manager_backup_path)
        else:
            return (False, None)

    def user_login(self, username = None, password = None, ):
        # Check if username and password are None
        if username in self.user_list:
            self.permission = True
            self.username = username
        else:
            raise HTTPException(status_code=401, detail="The user is not registered.")
        
    def delete_user(self, username):
        # Check if the user exists
        if username in self.user_list:
            # Here we need to delete the user from the list
            self.user_list.remove(username)
            # Here we need to delete the user folder
            shutil.rmtree(os.path.join(PATH_USERS_FOLDERS, username))
        else:
            raise HTTPException(status_code=400, detail="The user does not exist")
               
    