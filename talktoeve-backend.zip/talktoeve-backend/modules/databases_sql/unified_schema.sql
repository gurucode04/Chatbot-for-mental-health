-- Create the tables
CREATE TABLE PersonalInfo (
    personal_info_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    name TEXT,
    birthday TEXT,
    nationality TEXT,
    location TEXT,
    position TEXT,
    area TEXT,
    shift TEXT,
    vessel TEXT,
    experience TEXT,
    studies TEXT,
    occupation TEXT,
    family TEXT,
    friends TEXT,
    partner TEXT,
    persons_with_whom_he_she_lives TEXT,
    user_type TEXT,
    FOREIGN KEY (user_id) REFERENCES User(user_id)
);

CREATE TABLE Session (
    session_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    date TEXT,
    duration INTEGER,
    depression_score INTEGER,
    stress_score INTEGER,
    admiration INTEGER,
    amusement INTEGER,
    anger INTEGER,
    annoyance INTEGER,
    approval INTEGER,
    caring INTEGER,
    confusion INTEGER,
    curiosity INTEGER,
    desire INTEGER,
    disappointment INTEGER,
    disapproval INTEGER,
    disgust INTEGER,
    embarrassment INTEGER,
    excitement INTEGER,
    fear INTEGER,
    gratitude INTEGER,
    grief INTEGER,
    joy INTEGER,
    love INTEGER,
    nervousness INTEGER,
    neutral INTEGER,
    optimism INTEGER,
    pride INTEGER,
    realization INTEGER,
    relief INTEGER,
    remorse INTEGER,
    sadness INTEGER,
    surprise INTEGER,
    summary TEXT,
    FOREIGN KEY (user_id) REFERENCES User(user_id)
);

CREATE TABLE SessionHistory (
    message_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    session_id INTEGER NOT NULL,
    feedback TEXT,
    role TEXT,
    depression_score INTEGER,
    stress_score INTEGER,
    admiration INTEGER,
    amusement INTEGER,
    anger INTEGER,
    annoyance INTEGER,
    approval INTEGER,
    caring INTEGER,
    confusion INTEGER,
    curiosity INTEGER,
    desire INTEGER,
    disappointment INTEGER,
    disapproval INTEGER,
    disgust INTEGER,
    embarrassment INTEGER,
    excitement INTEGER,
    fear INTEGER,
    gratitude INTEGER,
    grief INTEGER,
    joy INTEGER,
    love INTEGER,
    nervousness INTEGER,
    neutral INTEGER,
    optimism INTEGER,
    pride INTEGER,
    realization INTEGER,
    relief INTEGER,
    remorse INTEGER,
    sadness INTEGER,
    surprise INTEGER,
    message TEXT,
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (session_id) REFERENCES Session(session_id)
);

CREATE TABLE Keyphrases (
    node_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    session_id INTEGER NOT NULL,
    message_id INTEGER NOT NULL,
    node TEXT,
    parent_node TEXT,
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (session_id) REFERENCES Session(session_id),
    FOREIGN KEY (message_id) REFERENCES SessionHistory(message_id)
);

CREATE TABLE VersionInfo (
    update_id INTEGER PRIMARY KEY,
    version TEXT,
    date_of_update TEXT,
    update_description TEXT
);

CREATE TABLE Survey (
    survey_id INTEGER PRIMARY KEY,
    survey_name TEXT,
    survey_date TEXT,
    due_date TEXT,
    n_questions INTEGER
);

CREATE TABLE SurveyQuestion (
    question_id INTEGER PRIMARY KEY,
    survey_id INTEGER NOT NULL,
    question TEXT,
    question_type TEXT,
    FOREIGN KEY (survey_id) REFERENCES Survey(survey_id)
);

CREATE TABLE SurveyAnswer (
    answer_id_question_id INTEGER PRIMARY KEY,
    answer_id INTEGER,
    question_id INTEGER NOT NULL,
    survey_id INTEGER NOT NULL,
    answer TEXT,
    FOREIGN KEY (question_id) REFERENCES SurveyQuestion(question_id),
    FOREIGN KEY (survey_id) REFERENCES Survey(survey_id)
);

CREATE TABLE SurveyResponse (
    response_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    survey_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    answer_id INTEGER,
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (survey_id) REFERENCES Survey(survey_id),
    FOREIGN KEY (question_id) REFERENCES SurveyQuestion(question_id),
    FOREIGN KEY (answer_id) REFERENCES SurveyAnswer(answer_id_question_id)
);

CREATE TABLE UserSurvey (
    survey_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    survey_name TEXT,
    finish_date TEXT,
    n_questions INTEGER,
    FOREIGN KEY (user_id) REFERENCES User(user_id)
);

CREATE TABLE UserSurveyResponse (
    user_survey_response_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    survey_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    answer_id INTEGER,
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (survey_id) REFERENCES UserSurvey(survey_id),
    FOREIGN KEY (question_id) REFERENCES SurveyQuestion(question_id),
    FOREIGN KEY (answer_id) REFERENCES SurveyAnswer(answer_id_question_id)
);

CREATE TABLE CompanyInfo (
    company_id INTEGER PRIMARY KEY,
    company_name TEXT,
    industry TEXT,
    address TEXT,
    company_email TEXT,
    company_number TEXT,
    company_logo TEXT,
    business_hours TEXT,
    services_offered TEXT,
    company_description TEXT
);

CREATE TABLE User (
    user_id INTEGER PRIMARY KEY,
    company_id INTEGER NOT NULL,
    FOREIGN KEY (company_id) REFERENCES CompanyInfo(company_id)
);