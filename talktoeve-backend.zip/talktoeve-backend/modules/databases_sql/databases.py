import sqlite3
import pandas as pd
import os
import sys
import time
import json

# Obtain the grandparent directory and add it to the path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(current_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)
from traceback import print_exc
from config_database import *
from modules.auxiliar_functions import encrypt_dataframe, decrypt_dataframe, get_key, emotions_evol_ind_company_dashboard, create_main_indicators_structure, calcular_fechas, datatime_df, main_indicators_user_dashboard, emotions_evol_ind_user_dashboard, main_indicators_company_dashboard
from traceback import print_exc
from utils.logger import setup_logger

class UserDatabase():
    def __init__(self, path = None):
        self.extist = False
        self.survey_db_path = SURVEY_DB_PATH
        self.tables_names = {'personal_information': 'personal_information', 'sessions': 'sessions', 
                                'sessions_history': 'sessions_history', 'keyphrases': 'keyphrases',
                                'survey': 'survey', 'survey_responses': 'survey_responses',
                                'info_db': 'info_db', 'nodes': 'nodes'}
        # Personal Information Table Template
        self.personal_information_template = DEFAULT_PERSONAL_INFO_v1
        self.session_table_template = DEFAULT_SESSION_TABLE_v1
        self.session_history_table_template = DEFAULT_SESSION_HISTORY_TABLE_v1
        self.keyphrases_table_template = DEFAULT_KEYPHRASES_TABLE_v1
        self.nodes_table_template = DEFAULT_NODE_TABLE
        self.surveys_table_template = DEFAULT_USER_SURVEY_TABLE
        self.survey_responses_table_template = DEFAULT_USER_SURVEY_RESPONSE_TABLE
        self.info_db_table_template = DEFAULT_INFO_VERSION_TABLE_V1

        if path is not None:    
            self.path = path
            # Check if the database exists
            if not os.path.exists(self.path):
                # create the directory
                # only the directory, withouth de file
                os.makedirs(os.path.dirname(self.path),exist_ok=True)
                # create the database
                conn = sqlite3.connect(self.path)
                conn.close()

                # Create tables
                self.create_personal_information_table()
                self.create_session_table()
                self.create_session_history_table()
                self.create_keyphrase_table()
                self.create_surveys_tables()
                self.create_info_db_table()
                
                self.update_surveys()
                self.extist = True
            else:
                self.update_surveys()
                self.extist = True
 
    def set_database_path(self, path):
        self.path = path
        
        # Check if the database exists
        if not os.path.exists(self.path):
            # Create path
            os.makedirs(os.path.dirname(self.path))
            # Create tables
            self.create_personal_information_table()
            self.create_session_table()
            self.create_session_history_table()
            self.create_keyphrase_table()
            self.create_nodes_table()
            self.create_surveys_tables()
            self.create_info_db_table()
            
            self.extist = True
        else:
            self.extist = True
   
    def create_info_db_table(self):
        # Check if flag self.exists is True
        if not self.extist:
            self.create_table(self.info_db_table_template, 'info_db') 
            
            conn = sqlite3.connect(self.path)
            cur = conn.cursor()
            # Insert default values
            placeholders = ', '.join(['?'] * len(self.info_db_table_template['values']))
            default_values_query = f"INSERT INTO info_db ({', '.join(self.info_db_table_template['columns'])}) VALUES ({placeholders})"
            cur.execute(default_values_query, self.info_db_table_template['values'])
            conn.commit()
            conn.close()
     
    def create_personal_information_table(self):
        # Check if flag self.exists is True
        if not self.extist:
            self.create_table(self.personal_information_template, 'personal_information') 
            
            conn = sqlite3.connect(self.path)
            cur = conn.cursor()
            # Insert default values
            df = pd.DataFrame(self.personal_information_template['values'], index=self.personal_information_template['encrypted_columns']).T
            df = encrypt_dataframe(df, get_key(''), self.personal_information_template['encrypted_columns'])
            df.to_sql(self.tables_names['personal_information'], conn, if_exists='append', index=False)
            # placeholders = ', '.join(['?'] * len(self.personal_information_template['values']))
            # default_values_query = f"INSERT INTO personal_information ({', '.join(self.personal_information_template['encrypted_columns'])}) VALUES ({placeholders})"
            # cur.execute(default_values_query, self.personal_information_template['values'])
            # conn.commit()
            conn.close()

    def update_last_personal_information(self, data_dict):
        try:
            # Here we need to keep only the keys that are in the template
            data_dict = {key: data_dict[key] for key in data_dict if key in self.personal_information_template['encrypted_columns']+self.personal_information_template['columns']}
            data_df = pd.DataFrame(data_dict, index=[0])

            # actual data
            conn = sqlite3.connect(self.path)
            actual_df = pd.read_sql_query(f"SELECT * FROM {self.tables_names['personal_information']}", conn)
            conn.close()
            actual_df = decrypt_dataframe(actual_df, get_key(''), self.personal_information_template['encrypted_columns'])
            print("actual Df :")
            actual_df
            # delete personal_info_id column
            if 'personal_info_id' in actual_df.columns:
                actual_df.drop('personal_info_id', axis=1, inplace=True)
            # update data
            actual_df.update(data_df)
            
            actual_df = encrypt_dataframe(actual_df, get_key(''), self.personal_information_template['encrypted_columns'])

            # open connection
            conn = sqlite3.connect(self.path)
            actual_df.to_sql(self.tables_names['personal_information'], conn, if_exists='replace', index=False)
            conn.close()
        except Exception as e:
            print_exc()

    def create_session_table(self):
        # Check if flag self.exists is True
        if not self.extist:
            self.create_table(self.session_table_template, 'sessions')

    def create_session_history_table(self):
        # Check if flag self.exists is True
        if not self.extist:
            self.create_table(self.session_history_table_template, 'sessions_history')

    def create_keyphrase_table(self):
        # Check if flag self.exists is True
        if not self.extist:
            self.create_table(self.keyphrases_table_template, 'keyphrases')
    
    def create_nodes_table(self):
        # Check if flag self.exists is True
        if not self.extist:
            self.create_table(self.nodes_table_template, 'nodes')

    def insert_keyphrases_data(self, keyphrases_data_df, session_id):
        try:
            with sqlite3.connect(self.path) as conn:
                # get nodes table
                nodes_df = pd.read_sql_query(f"SELECT * FROM {self.tables_names['nodes']}", conn)
                nodes_df = decrypt_dataframe(nodes_df, get_key(''), self.nodes_table_template['encrypted_columns'])
                conn.commit()

            # Insert keyphrases data into Keyphrases table
            keyphrases_data_df['session_id'] = session_id
            keyphrases_data_df.columns = ['message_id','node', 'parent_node', 'session_id']
            # delete duplicate edges (message_id, 'node', 'parent_node')
            keyphrases_data_df.drop_duplicates(subset=['message_id', 'node', 'parent_node'], inplace=True)
            # reset index
            keyphrases_data_df.reset_index(drop=True, inplace=True)

            nodes = keyphrases_data_df['node'].tolist()
            parent_nodes = keyphrases_data_df['parent_node'].tolist()

            unique_nodes = set(nodes+parent_nodes)
            nodes_db = set(nodes_df['node_name'].values)
            new_nodes_names = list(unique_nodes - nodes_db)

            # insert the new nodes
            if new_nodes_names:
                new_nodes_df = pd.DataFrame(new_nodes_names, columns=['node_name'])
                new_nodes_df['node_notes'] = ''  # Add an empty 'node_notes' column
                new_nodes_df = encrypt_dataframe(new_nodes_df, get_key(''), self.nodes_table_template['encrypted_columns'])
                with sqlite3.connect(self.path) as conn:
                    new_nodes_df.to_sql(self.tables_names['nodes'], conn, if_exists='append', index=False)
            
            # get the node_id of the nodes
            with sqlite3.connect(self.path) as conn:
                nodes_df = pd.read_sql_query(f"SELECT * FROM {self.tables_names['nodes']}", conn)
                nodes_df = decrypt_dataframe(nodes_df, get_key(''), self.nodes_table_template['encrypted_columns'])
            
            node_ids = []
            parent_node_ids = []
            for node, parent_node in zip(nodes, parent_nodes):
                node_ids.append(nodes_df[nodes_df['node_name'] == node]['node_id'].values[0])
                parent_node_ids.append(nodes_df[nodes_df['node_name'] == parent_node]['node_id'].values[0])

            keyphrases_data_df['node_id0'] = node_ids
            keyphrases_data_df['node_id1'] = parent_node_ids

            keyphrases_data_df = keyphrases_data_df.drop(['node', 'parent_node'], axis=1)

            with sqlite3.connect(self.path) as conn:
                keyphrases_data_df.to_sql(self.tables_names['keyphrases'], conn, if_exists='append', index=False)
                conn.commit()
        except Exception as e:
            print_exc()
            setup_logger().error(f"Unhandled error: {e}\nDetailed traceback is {print_exc()}", exc_info=True)
            raise ValueError(f"Error inserting keyphrases data: {e}")


    # def insert_session_data(self, session_data):
    #     # Insert session data into Session table
    #     self._insert_data('sessions', session_data)

    def insert_session_history_data(self, session_history_data):
        conn = sqlite3.connect(self.path)
        if 'message_id' in session_history_data.columns:
            session_history_data = session_history_data.drop('message_id', axis=1)
        session_history_data = encrypt_dataframe(session_history_data, get_key(''), self.session_history_table_template['encrypted_columns'])
        # Insertar el DataFrame en la tabla SessionHistory
        session_history_data.to_sql(self.tables_names['sessions_history'], conn, if_exists='append', index=False)
        conn.close()

    def insert_session_data(self, session_data):
        session_data = encrypt_dataframe(session_data, get_key(''), self.session_table_template['encrypted_columns'])
        #delete the session_id column
        if 'session_id' in session_data.columns:
            session_data.drop('session_id', axis=1, inplace=True)
        # Insert session data into Session table
        conn = sqlite3.connect(self.path)
        session_data.to_sql(self.tables_names['sessions'], conn, if_exists='append', index=False)
        conn.close()

    def _insert_data(self, table_name, data_dict):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        # Validate data and table name
        if not isinstance(data_dict, dict):
            raise ValueError('Data must be a dictionary')
        
        # Check that data has the correct keys
        columns_query = f"PRAGMA table_info({table_name})"
        cur.execute(columns_query)
        table_columns = [col[1] for col in cur.fetchall()]
        data_columns = list(data_dict.keys())

        if set(data_columns) != set(table_columns):
            raise ValueError('Data must have the correct keys')

        # Insert data into the table
        columns = ', '.join(data_dict.keys())
        placeholders = ', '.join(['?'] * len(data_dict))
        values = tuple(data_dict.values())
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        
        cur.execute(query, values)
        conn.commit()
        conn.close()

    def get_all_session_ids(self):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        query = "SELECT session_id FROM sessions"
        cur.execute(query)
        session_ids = [row[0] for row in cur.fetchall()]
        conn.close()
        return session_ids
    
    def conversation_summaries(self, format='str', session_id=None):
        """
        format = 'str' or 'list'
        """
        sessions = self.get_session_summary_data_as_dataframe(session_id=session_id)

        if len(sessions) == 0:
            return ''
        
        if format == 'str':
            str_ = ''
            for i in range(len(sessions)):
                str_ += f"Conversation {i+1}:[{sessions['summary'][i]}]\n"
            return str_
        elif format == 'list':
            return sessions['summary'].to_list()
    
    def get_session_data_as_dataframe(self, session_id=None):
        return self._get_session_data_as_dataframe(self.tables_names['sessions'], session_id, self.session_table_template)

    def get_session_history_data_as_dataframe(self, session_id):
        return self._get_session_data_as_dataframe(self.tables_names['sessions_history'], session_id, self.session_history_table_template)

    def get_session_summary_data_as_dataframe(self, session_id):
        return self._get_session_data_as_dataframe(self.tables_names['sessions'], session_id, self.session_table_template)
    
    def _get_session_data_as_dataframe(self, table_name, session_id, table_template):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        if isinstance(session_id, list):
            df_list = []
            columns_query = f"PRAGMA table_info({table_name})"
            cur.execute(columns_query)
            table_columns = [col[1] for col in cur.fetchall()]

            for sid in session_id:
                query = f"SELECT * FROM {table_name} WHERE session_id = ?"
                cur.execute(query, (sid,))
                rows = cur.fetchall()
                df = pd.DataFrame(rows, columns=table_columns)
                df_list.append(df)
            conn.close()
            return pd.concat(df_list, ignore_index=True)
        else:
            if session_id is None:
                query = f"SELECT * FROM {table_name}"
                cur.execute(query)
            else:
                query = f"SELECT * FROM {table_name} WHERE session_id = ?"
                cur.execute(query, (session_id,))
                
            rows = cur.fetchall()
            columns_query = f"PRAGMA table_info({table_name})"
            cur.execute(columns_query)
            table_columns = [col[1] for col in cur.fetchall()]
            df = pd.DataFrame(rows, columns=table_columns)
            conn.close()
            df = decrypt_dataframe(df, get_key(''), table_template['encrypted_columns'])
            return df

    def get_personal_information_as_dataframe(self):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        query = f"SELECT * FROM {self.tables_names['personal_information']}"
        cur.execute(query)
        rows = cur.fetchall()
        columns_query = f"PRAGMA table_info({self.tables_names['personal_information']})"
        cur.execute(columns_query)
        table_columns = [col[1] for col in cur.fetchall()]
        df = pd.DataFrame(rows, columns=table_columns)
        conn.close()
        df = decrypt_dataframe(df, get_key(''), self.personal_information_template['encrypted_columns'])

        return df

    def get_mindmap(self, session_id=None, from_date=None, to_date=None, parent_node_id=None):
        if session_id is None and from_date is None and to_date is None:
            # i need to return all the keyphrases and the dates of the sessions
            query = f"SELECT edge_id, {self.tables_names['keyphrases']}.session_id, node_id0, node_id1 FROM {self.tables_names['keyphrases']} INNER JOIN {self.tables_names['sessions']} ON {self.tables_names['keyphrases']}.session_id = {self.tables_names['sessions']}.session_id"
        elif session_id is not None and from_date is None and to_date is None:
            # i need to return all the keyphrases of the session_id and the date of the session
            query = f"SELECT edge_id, {self.tables_names['keyphrases']}.session_id, node_id0, node_id1 FROM {self.tables_names['keyphrases']} INNER JOIN {self.tables_names['sessions']} ON {self.tables_names['keyphrases']}.session_id = {self.tables_names['sessions']}.session_id WHERE {self.tables_names['keyphrases']}.session_id = {session_id}"
        elif session_id is None and from_date is not None and to_date is not None:
            # i need to return all the keyphrases and the dates of the sessions between from_date and to_date
            query = f"SELECT edge_id, {self.tables_names['keyphrases']}.session_id, node_id0, node_id1, date FROM {self.tables_names['keyphrases']} INNER JOIN {self.tables_names['sessions']} ON {self.tables_names['keyphrases']}.session_id = {self.tables_names['sessions']}.session_id WHERE date BETWEEN '{from_date}' AND '{to_date}'"
        else:
            raise ValueError('You can only pass session_id or from_date and to_date')
        
        with sqlite3.connect(self.path) as conn:
            df = pd.read_sql_query(query , conn)
            nodes_df = pd.read_sql_query(f"SELECT * FROM {self.tables_names['nodes']}", conn)
            nodes_df = decrypt_dataframe(nodes_df, get_key(''), self.nodes_table_template['encrypted_columns'])

        # filter by parent_node_id
        if parent_node_id is not None:
            df = df.query(f"node_id0 == {parent_node_id} or node_id1 == {parent_node_id}")
            # filter nodes_df
            filter_ids = df['node_id0'].tolist() + df['node_id1'].tolist()
            nodes_df = nodes_df[nodes_df['node_id'].isin(filter_ids)]
        
        return df, nodes_df
    
    def update_node_notes(self, node_id, note):
        df = pd.DataFrame({'node_id': [node_id], 'node_notes': [note]})
        df = encrypt_dataframe(df, get_key(''), self.nodes_table_template['encrypted_columns'])

        with sqlite3.connect(self.path) as conn:
            df.to_sql(self.tables_names['nodes'], conn, if_exists='replace', index=False)
            conn.commit()

    def get_indicators(self, session_id=None, from_date=None, to_date=None, aggregate=False):
        indicators_str = ', '.join(INDICATORS)
        if session_id is None and from_date is None and to_date is None:
            # i need to return all the keyphrases and the dates of the sessions
            query = 'SELECT * FROM sessions'
        elif session_id is not None and from_date is None and to_date is None:
            # i need to return all the keyphrases of the session_id and the date of the session
            query = f'SELECT * FROM sessions WHERE session_id = {session_id}'
        elif session_id is None and from_date is not None and to_date is not None:
            # i need to return all the keyphrases and the dates of the sessions between from_date and to_date
            query = f'SELECT * FROM sessions WHERE date BETWEEN "{from_date}" AND "{to_date}"'
        else:
            raise ValueError('You can only pass session_id or from_date and to_date')
        conn = sqlite3.connect(self.path)
        df = pd.read_sql_query(query , conn)
        df.drop(columns=['summary', 'duration'], inplace=True)
        if aggregate:
            df.drop(columns=['date'], inplace=True)
            df = df.mean()
        conn.close()
        return df
    
    def create_surveys_tables(self):
        # Check if flag self.exists is True
        if not self.extist:
            self.create_table(self.surveys_table_template, 'survey')
            self.create_table(self.survey_responses_table_template, 'survey_responses')
    
    def check_and_load_surveys_into_user_db(self):
        survey_db = SurveyDatabase(self.get_user_type())
        df_survey = survey_db.get_survey_df()
        df_survey = df_survey[['survey_id', 'survey_name', 'n_questions']]  
        # Now we need to add the column finish_date
        df_survey['finish_date'] = None
        # First we need to check and obtain the surveys in survey table from user database
        conn = sqlite3.connect(self.path)
        df_user_survey = pd.read_sql_query("SELECT * FROM survey", conn)
        conn.close()
        # Here we need to add the surveys that are not in the user database
        df_survey = df_survey[~df_survey['survey_id'].isin(df_user_survey['survey_id'])]
        if df_survey.empty:
            return None 
        # concatenate the dataframes
        df = pd.concat([df_user_survey, df_survey], ignore_index=True)
        # Insert the new surveys to the user database
        df.to_sql('survey', conn, if_exists='replace', index=False)
        return "Survey_update"
        

    def update_surveys(self):
        survey_db = SurveyDatabase(self.get_user_type())
        survey_df_general = survey_db.get_survey_df()
        
        conn = sqlite3.connect(self.path)
        survey_df_user = pd.read_sql_query("SELECT * FROM survey", conn)

        # Get the surveys that are not in the user database
        survey_df_general = survey_df_general[~survey_df_general['survey_id'].isin(survey_df_user['survey_id'])]
        survey_df_general.drop(columns=['survey_date', 'due_date'], inplace=True)
        survey_df_general['finish_date'] = None
        # Insert the new surveys
        survey_df_general.to_sql('survey', conn, if_exists='append', index=False)
        conn.close()
       
    def insert_survey_response(self, survey_response):
        """
        survey_response  = {"username":0,
                            "survey_id": 0,
                            "responses": {1: 5, 2: 3, 3: 4}
                            }
        """
        # Check if the question has already been answered
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        query = f"SELECT * FROM survey_responses WHERE survey_id = ? AND question_id = ?"
        for question_id, answer_id in survey_response['responses'].items():
            cur.execute(query, (survey_response['survey_id'], question_id))
            if cur.fetchone() is not None:
                conn.close()
                raise ValueError(f"Question {question_id} has already been answered.")

        # Insert survey response data into Response table
        survey_response_df = pd.DataFrame(survey_response['responses'].items(), columns=['question_id', 'answer_id'])
        survey_response_df['survey_id'] = survey_response['survey_id']

        survey_response_df.to_sql('survey_responses', conn, if_exists='append', index=False)

        # check if the survey is finished
        df_survey_responses = pd.read_sql_query(f"SELECT * FROM survey_responses WHERE survey_id = {survey_response['survey_id']}", conn)
        df_survey = pd.read_sql_query(f"SELECT * FROM survey WHERE survey_id = {survey_response['survey_id']}", conn)
        if len(df_survey_responses) == int(df_survey['n_questions'][0]):
            # the survey is finished
            query = f"UPDATE survey SET finish_date = ? WHERE survey_id = ?"
            cur.execute(query, (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), survey_response['survey_id']))
        conn.commit()
        conn.close()
        
    def validate_survey_response(self, survey_id, questions_id, answers_id):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()

        # Verificar si la survey existe
        query = "SELECT COUNT(*) FROM survey WHERE survey_id = ?"
        cur.execute(query, (survey_id,))
        survey_exists = cur.fetchone()[0]
        if survey_exists == 0:
            conn.close()
            raise ValueError(f"La survey con ID {survey_id} no existe.")
        
        for question_id, answer_id in zip(questions_id, answers_id):
            # Verificar si la pregunta existe en la survey
            query = "SELECT COUNT(*) FROM survey_questions WHERE survey_id = ? AND question_id = ?"
            cur.execute(query, (survey_id, question_id))
            question_exists = cur.fetchone()[0]
            if question_exists == 0:
                conn.close()
                raise ValueError(f"La pregunta con ID {question_id} no existe en la survey con ID {survey_id}.")

            # Verificar si la respuesta existe en la tabla de respuestas
            query = "SELECT COUNT(*) FROM survey_responses WHERE survey_id = ? AND question_id = ? AND answer_id = ?"
            cur.execute(query, (survey_id, question_id, answer_id))
            response_exists = cur.fetchone()[0]
            if response_exists == 0:
                conn.close()
                raise ValueError(f"La respuesta con ID {answer_id} no existe para la pregunta con ID {question_id} en la survey con ID {survey_id}.")
            conn.close()
        return True
        
    def get_survey_next_questions(self, survey_id, number_of_questions):
        """ 
        This function returns the next questions of the survey in a list of dictionaries
        """
        # get the max question_id of the survey in the user database
        conn = sqlite3.connect('/home/piyush/work/rahil/talk_to_eveIA/users/piyush/piyush.db')#sqlite3.connect(self.path)
        cur = conn.cursor()
        query = f"SELECT MAX(question_id) FROM {self.tables_names['survey_responses']} WHERE survey_id = ?"
        cur.execute(query, (survey_id,))
        max_question_id = cur.fetchone()[0]

        # check if the survey is finished
        if max_question_id is not None:
            df_survey = pd.read_sql_query(f"SELECT * FROM survey WHERE survey_id = {survey_id}", conn)
            conn.close()
            if max_question_id+1 == int(df_survey['n_questions'][0]):
                # the survey is finished
                return {'finished': True}
        else:
            conn.close()

        # get the questions of the survey
        survey_db = SurveyDatabase("user")#SurveyDatabase(self.get_user_type())
        survey_df = survey_db.get_survey_questions_answers_df(survey_id, max_question_id, number_of_questions)

        result = (
            survey_df.groupby(['question_id', 'question', 'question_type'])
            .agg(options=('answer', list))
            .reset_index()
            .rename(columns={'question_id': 'id', 'question': 'title'})
            .to_dict(orient='records')
        )

        # Formatear los datos en la estructura deseada
        formatted_result = [{'id': item['id'], 'title': item['title'], 'options': item['options'], 'type':item['question_type']} for item in result]

        return formatted_result
    
    def get_survey_df(self):
        conn = sqlite3.connect(self.path)
        df = pd.read_sql_query("SELECT * FROM survey", conn)
        conn.close()
        return df
    
    def get_survey_responses_df(self, survey_id=None):
        conn = sqlite3.connect(self.path)
        if survey_id is None:
            df = pd.read_sql_query("SELECT * FROM survey_responses", conn)
        else:
            df = pd.read_sql_query(f"SELECT * FROM survey_responses WHERE survey_id = {survey_id}", conn)
        conn.close()
        return df
    
    def check_if_survey_finished(self, survey_id):
        # To do that we need to obtain if a survey has been finished analizing if table surveys column finish_date has a value
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        query = f"SELECT finish_date FROM survey WHERE survey_id = {survey_id}"
        cur.execute(query)
        finish_date = cur.fetchone()[0]
        conn.close()
        if finish_date is not None:
            return True
        else:
            return False
        
    def upload_survey_responses_to_surveydb(self):
        survey_db_path = SURVEY_DB_PATH
        
        # Check if there are completed survey_ids
        completed_survey_ids = []
        for survey_id in self.get_survey_df()['survey_id']:
            if self.check_if_survey_finished(survey_id):
                completed_survey_ids.append(survey_id)
            else:
                # Get out of the function
                print('The survey is not finished yet.')
                return None
        # Insert survey responses into company database
        survey_db = SurveyDatabase(self.get_user_type()) # Replace CompanyDB with the actual class name
        for survey_id in completed_survey_ids:
            survey_responses_df = self.get_survey_responses_df(survey_id)
            survey_responses_df= survey_responses_df.drop(columns=['user_survey_response_id'])
            survey_db.insert_survey_response(survey_responses_df)  # Replace insert_input with the actual method name
        print('The survey responses have been uploaded to the company database.')
        
    def create_table(self, template, table_name):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        
        primary_key = f"{template['primary_key']} INTEGER PRIMARY KEY, "
        if 'encrypted_columns' in template.keys():
            encrypted_columns = ', '.join(f"{col} BLOB" for col in template['encrypted_columns'])
        else:
            encrypted_columns = ''
        if 'columns' in template.keys():
            normal_columns = ', '.join(f"{col} REAL" if col in INDICATORS else f"{col} TEXT" if not 'id' in col else f"{col} INTEGER" for col in template['columns'])
            if encrypted_columns:
                columns = primary_key + encrypted_columns + ', ' + normal_columns
            else:
                columns = primary_key + normal_columns
        else:
            columns = primary_key + encrypted_columns
        
        query = f'''CREATE TABLE IF NOT EXISTS {table_name} (
                {columns}
                )'''
        
        cur.execute(query)
        conn.commit()
        conn.close()    

    def get_user_dashboard(self, period = 'weekly', start_filter_date=None, end_filter_date=None, aggregate=False, wheited=True, last_session=False):
        """
        period: str, yearly, monthly, weekly
        start_date: str, format: 'YYYY-MM-DD'
        end_date: str, format: 'YYYY-MM-DD'
        aggregate: bool, if True, the function returns the mean of the indicators
        wheited: bool, if True, the function returns the indicators wheited giving more importance to the lastest sessions
        last_session: bool, if True, the function returns the indicators of the last session
        """
        conn = sqlite3.connect(self.path)
        # We need to sleect the table sessions 
        sessions_table = pd.read_sql_query("SELECT * FROM sessions", conn)
        conn.close()

        if len(sessions_table) == 0:
            return None
        
        sessions_table['date'] = pd.to_datetime(sessions_table['date'], format='%Y_%m_%d')
        
        # Obtener las fechas por las cuales se filtraron los df
        sessions_table, start_filter_date, end_filter_date = datatime_df(sessions_table, start_filter_date, end_filter_date)


        emotions_list = EMOTIONS_CLASSIFICATIONS['positive'] + EMOTIONS_CLASSIFICATIONS['neutral'] + EMOTIONS_CLASSIFICATIONS['negative']
        # Normalize
        sessions_table[emotions_list] = sessions_table[emotions_list].div(sessions_table[emotions_list].sum(axis=1), axis=0) * 100
        
        # Calculate the mean of the emotions 
        sessions_table['mean_positive_emotions'] = sessions_table[EMOTIONS_CLASSIFICATIONS['positive']].mean(axis=1)
        sessions_table['mean_neutral_emotions'] = sessions_table[EMOTIONS_CLASSIFICATIONS['neutral']].mean(axis=1)
        sessions_table['mean_negative_emotions'] = sessions_table[EMOTIONS_CLASSIFICATIONS['negative']].mean(axis=1)  

        sessions_table['positive_score'] = sessions_table['mean_positive_emotions'] / (sessions_table['mean_positive_emotions'] + sessions_table['mean_neutral_emotions'] + sessions_table['mean_negative_emotions'])
        sessions_table['neutral_score'] = sessions_table['mean_neutral_emotions'] / (sessions_table['mean_positive_emotions'] + sessions_table['mean_neutral_emotions'] + sessions_table['mean_negative_emotions'])
        sessions_table['negative_score'] = sessions_table['mean_negative_emotions'] / (sessions_table['mean_positive_emotions'] + sessions_table['mean_neutral_emotions'] + sessions_table['mean_negative_emotions'])

        numeric_columns = list(set(sessions_table.select_dtypes(include='number').columns) - set(['id','session_id'])) 

        # Obtener las metricas principales que pueden ser agregadas en diferentes maneras
        sessions_table_filtered = sessions_table[(sessions_table['date'] >= start_filter_date) & (sessions_table['date'] <= end_filter_date)]
        
        results_main_indicators = main_indicators_user_dashboard(sessions_table_filtered = sessions_table_filtered, numeric_columns = numeric_columns, 
                                                                emotions_class = EMOTIONS_CLASSIFICATIONS, 
                                                                aggregate = aggregate, wheited = wheited, last_session = last_session, )
        
        results_evolutions = emotions_evol_ind_user_dashboard(sessions_table = sessions_table_filtered, 
                                                              emotions_class = EMOTIONS_CLASSIFICATIONS, 
                                                              start_period = start_filter_date, end_period = end_filter_date, period = period)
        
        # Adjuntar todos los dict
        results = {**results_main_indicators, **results_evolutions}
        return results 
    
    def get_user_type(self,):
        with sqlite3.connect(self.path) as conn:
            cur = conn.cursor()
            query = "SELECT user_type FROM personal_information"
            cur.execute(query)
            user_type = cur.fetchone()[0]
            # ask for the columns of the table personal_information
            columns_query = f"PRAGMA table_info(personal_information)"
            columns = cur.execute(columns_query).fetchall()
        return user_type
    
    def get_session_id(self,):
        # get last session_id and + 1
        with sqlite3.connect(self.path) as conn:
            cur = conn.cursor()
            query = "SELECT MAX(session_id) FROM sessions"
            cur.execute(query)
            session_id = cur.fetchone()[0]
            if session_id is None:
                session_id = 1
            else:
                session_id += 1
        return session_id
        
class SurveyDatabase():
    def __init__(self, user_type = 'company'):
        self.extist = False
        # Check if the database exists
        if 'company' in user_type or 'user' in user_type:  
            self.path = SURVEY_DB_PATH
        elif 'test' in user_type:
            self.path = SURVEY_DB_PATH_test
        if not os.path.exists(self.path):  
            self.tables_names = ['survey', 'question', 'answer', 'response']
            # Personal Information Table Template
            self.table_templates = [DEFAULT_SURVEY_TABLE, DEFAULT_SURVEY_QUESTION_TABLE, DEFAULT_SURVEY_ANSWER_TABLE, DEFAULT_SURVEY_RESPONSE_TABLE]

            # os.makedirs(os.path.dirname(self.path))
            conn = sqlite3.connect(self.path)
            conn.close()

            # Create tables
            for template, table_name in zip(self.table_templates, self.tables_names):
                self.create_table(template, table_name)
            
            self.extist = True
                

    def create_table(self, template, table_name):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()

        primary_key = f"{template['primary_key']} INTEGER PRIMARY KEY, "
        columns = primary_key + ', '.join(f"{col} TEXT" if not 'id' in col else f"{col} INTEGER" for col in template['columns'])
        query = f'''CREATE TABLE IF NOT EXISTS {table_name} (
                    {columns}
                    )'''
        
        cur.execute(query)
        conn.commit()
        conn.close()

    def insert_new_survey(self, survey_json):
        """
        survey_json = 
        {
            "name": "anonymous health and wellbeing survey y2 2023",
            "date": "05-12-2023",
            "due_date": "05-02-2024",
            "questions": [
                {"question": "What is your position?", "options": ["Officer / Chief / SL", "Operator / Rating", "Other"], "option_type": "single", "question_category": "Work Environment and Demographics"},
                {"question": "What is your age?", "options": ["Under 24", "25 - 34", "35 - 44", "45 - 54", "Over 55"], "option_type": "single", "question_category": "Work Environment and Demographics"},
            ]
        }
        """
        with sqlite3.connect(self.path) as conn:
            cur = conn.cursor()

            # Get the next survey_id
            cur.execute("SELECT MAX(survey_id) FROM survey")
            survey_id = cur.fetchone()[0]
            if survey_id is None:
                survey_id = 0 
            else:
                survey_id += 1

            # Get the next questino_id
            cur.execute("SELECT MAX(question_id) FROM question")
            existing_question_id = cur.fetchone()[0]
            if existing_question_id is None:
                existing_question_id = 0 
            else:
                existing_question_id += 1


            # Get the next answer_id
            cur.execute("SELECT MAX(answer_id) FROM answer")
            existing_answer_id = cur.fetchone()[0]
            if existing_answer_id is None:
                existing_answer_id = 0 
            else:
                existing_answer_id += 1


            # Insert survey data into Survey table
            cur.execute("INSERT INTO survey (survey_id, survey_name, survey_date, due_date, n_questions) VALUES (?, ?, ?, ?, ?)",
                        (survey_id, survey_json['name'], survey_json['date'], survey_json['due_date'], len(survey_json['questions'])))

            # Insert questions data into Question table
            questions_list = []
            answers_list = []

            for question_id, question in enumerate(survey_json['questions']):
                questions_list.append({
                    'question_id': question_id+existing_question_id,
                    'survey_id': survey_id,
                    'question': question['question'],
                    'question_type': question['option_type']  # Use the option_type provided in the JSON
                    # 'question_category': question['question_category']
                })

                for answer_id, answer in enumerate(question['options']):
                    answers_list.append({
                        'answer_id': answer_id,
                        'question_id': question_id+existing_question_id,
                        'survey_id': survey_id,
                        'answer': answer
                    })

            questions_df = pd.DataFrame(questions_list)
            answers_df = pd.DataFrame(answers_list)

            questions_df.to_sql('question', conn, if_exists='append', index=False)
            answers_df.to_sql('answer', conn, if_exists='append', index=False)

            conn.commit()

    def edit_survey(self, survey_id, survey_json):
        """
        Edita una encuesta existente en la base de datos.
        survey_id: int
        survey_json: dict
        """
        with sqlite3.connect(self.path) as conn:
            cur = conn.cursor()

            # Update survey data in Survey table
            cur.execute("""
                UPDATE survey 
                SET survey_name = ?, survey_date = ?, due_date = ?, n_questions = ? 
                WHERE survey_id = ?
            """, (survey_json['name'], survey_json['date'], survey_json['due_date'], len(survey_json['questions']), survey_id))

            # Delete existing questions and answers
            cur.execute("DELETE FROM question WHERE survey_id = ?", (survey_id,))
            cur.execute("DELETE FROM answer WHERE survey_id = ?", (survey_id,))

            # Insert updated questions data into Question table
            questions_list = []
            answers_list = []

            for question_id, question in enumerate(survey_json['questions']):
                questions_list.append({
                    'question_id': question_id,
                    'survey_id': survey_id,
                    'question': question['question'],
                    'question_type': question['option_type'],
                    'question_category': question['question_category']
                })

                for answer_id, answer in enumerate(question['options']):
                    answers_list.append({
                        'answer_id': answer_id,
                        'question_id': question_id,
                        'survey_id': survey_id,
                        'answer': answer
                    })

            questions_df = pd.DataFrame(questions_list)
            answers_df = pd.DataFrame(answers_list)

            questions_df.to_sql('question', conn, if_exists='replace', index=False)
            answers_df.to_sql('answer', conn, if_exists='replace', index=False)

            conn.commit()
    
    def get_survey_json(self, survey_id: int):
        """
        Obtiene el JSON de una encuesta a partir del survey_id.
        survey_id: int
        return: dict
        """
        with sqlite3.connect(self.path) as conn:
            cur = conn.cursor()

            # Get survey data
            cur.execute("SELECT survey_name, survey_date, due_date FROM survey WHERE survey_id = ?", (survey_id,))
            survey_row = cur.fetchone()
            if not survey_row:
                raise ValueError(f"Survey with id {survey_id} does not exist")

            survey_json = {
                "name": survey_row[0],
                "date": survey_row[1],
                "due_date": survey_row[2],
                "questions": []
            }

            # Get questions data
            cur.execute("""
                SELECT question_id, question, question_type 
                FROM question 
                WHERE survey_id = ?
            """, (survey_id,))
            questions_rows = cur.fetchall()

            for question_row in questions_rows:
                question_id, question, question_type = question_row
                # Get answers for this question
                cur.execute("""
                    SELECT answer 
                    FROM answer 
                    WHERE survey_id = ? AND question_id = ?
                """, (survey_id, question_id))
                answers_rows = cur.fetchall()
                options = [answer_row[0] for answer_row in answers_rows]

                survey_json["questions"].append({
                    "question": question,
                    "options": options,
                    "option_type": question_type
                })

        return survey_json
    
    def delete_survey(self, survey_id: int):
        """
        Deletes a survey from the database.
        
        Args:
        survey_id (int): The ID of the survey to delete.
        """
        with sqlite3.connect(self.path) as conn:
            cur = conn.cursor()

            # Delete answers associated with the survey
            cur.execute("DELETE FROM answer WHERE survey_id = ?", (survey_id,))

            # Delete questions associated with the survey
            cur.execute("DELETE FROM question WHERE survey_id = ?", (survey_id,))

            # Delete the survey
            cur.execute("DELETE FROM survey WHERE survey_id = ?", (survey_id,))

            conn.commit()

    def insert_survey_response(self, survey_response):
        """survey_response: is a dataframe that has the columns 'survey_id', 'question_id', 'answer_id'}"""
        
        conn = sqlite3.connect(self.path)
        
        # Get response table as DataFrame
        df_response = pd.read_sql_query("SELECT * FROM response", conn)
        survey_response['response_id'] = [i for i in range(len(survey_response))]
        # Append new survey responses to existing DataFram
        df_updated = pd.concat([df_response, survey_response], ignore_index=True)
        
        # Send updated DataFrame to SQL
        df_updated.to_sql('response', conn, if_exists='replace', index=False)
        
        conn.close()

    
    def get_survey_df(self):
        conn = sqlite3.connect(self.path)
        df = pd.read_sql_query("SELECT * FROM survey", conn)
        conn.close()
        return df
    
    def get_survey_questions_answers_df(self, survey_id, question_id_max, n_questions):
        conn = sqlite3.connect(self.path)
        if question_id_max is None:
            question_id_max = -1
        query = f"SELECT * FROM question WHERE survey_id = ? AND question_id > ? LIMIT ?"
        df = pd.read_sql_query(query, conn, params=(survey_id, question_id_max, n_questions))
        
        query_A = f"SELECT * FROM answer WHERE survey_id = ? AND question_id BETWEEN ? AND ?"
        df_A = pd.read_sql_query(query_A, conn, params=(survey_id, question_id_max+1, question_id_max+n_questions))
        df = df.merge(df_A, on=['question_id', 'survey_id'])
        conn.close()
        return df
    
    def get_survey_responses(self, survey_id=None):
        conn = sqlite3.connect(self.path)
        df = pd.read_sql_query("SELECT * FROM response", conn)
        
        if survey_id is None:
            df = pd.read_sql_query("SELECT * FROM response", conn)
        else:
            df = pd.read_sql_query(f"SELECT * FROM response WHERE survey_id = {survey_id}", conn)
        conn.close()
        
        results = self.convert_df_survey_response_to_dict(df)
        
        return results
    
    def convert_df_survey_response_to_dict(self, df):
        # Agrupar por survey_id, question_id, y answer_id, y contar las ocurrencias
        grouped = df.groupby(['survey_id', 'question_id', 'answer_id']).size().reset_index(name='count')

        # Convertir los datos agrupados en un diccionario anidado
        result = {}
        for row in grouped.itertuples():
            survey_id = row.survey_id
            question_id = row.question_id
            answer_id = row.answer_id
            count = row.count
            
            if survey_id not in result:
                result[survey_id] = {}
            if question_id not in result[survey_id]:
                result[survey_id][question_id] = {}
            
            result[survey_id][question_id][answer_id] = count
        return result
    
class CompanyDatabase():
    def __init__(self, usertype = 'user'):
        if usertype == 'test':
            self.path = COMPANY_DB_PATH_test
        else:
            self.path = COMPANY_DB_PATH
        
        self.tables_names = {'users_table': 'users_table', 
                             'info_db': 'info_db',
                             'company_info': 'company_info',}
        
        self.users_table_template = DEFAULT_USERS_TABLE_DATABASE_v1
        self.info_db_table_template = DEFAULT_INFO_VERSION_TABLE_V1
        self.company_info_table_template = DEFAULT_COMPANY_INFORMATION_TABLE_v1
        
        self.check_tables_database()

    def update_info_db(self, version, update_date, update_description):
        # Check if the version in the table is the same as the version in the argument
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        
        cur.execute("SELECT version FROM info_db")
        current_version = cur.fetchone()
        
        if current_version is not None and current_version[0] != version:
            # Update the version in the info_db table
            cur.execute("UPDATE info_db SET version = ?, update_date = ?, update_description = ?",
                        (version, update_date, update_description))
            conn.commit()
            print("Version updated successfully!")
        else:
            print("Version is already up to date.")
        
        conn.close()

               
    def check_tables_database(self):
        # Check if the database exists
        if not os.path.exists(self.path):
            self.create_database()
        else:
            conn = sqlite3.connect(self.path)
            cur = conn.cursor()
            # Check if the tables exist
            for table_name in self.tables_names.values():
                cur.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
                table_exists = cur.fetchone()
                if table_exists is None:
                    # Create table
                    if table_name == 'users_table':
                        self.create_users_tables()
                    elif table_name == 'info_db':
                        self.create_info_db_table()
                    elif table_name == 'company_info':
                        self.create_company_info_table()
                else:
                    # Check columns
                    columns_query = f"PRAGMA table_info({table_name})"
                    cur.execute(columns_query)
                    table_columns = [col[1] for col in cur.fetchall()]
                    if table_name == 'users_table':
                        template_columns = self.users_table_template['columns']
                    elif table_name == 'info_db':
                        template_columns = self.info_db_table_template['columns']
                    elif table_name == 'company_info':
                        template_columns = self.company_info_table_template['columns']
                    for column in template_columns:
                        if column not in table_columns:
                            # Add column
                            query = f"ALTER TABLE {table_name} ADD COLUMN {column} TEXT"
                            cur.execute(query)
            conn.close()    
                    

    def create_database(self, path = None):

        """
        the path needs to be with the name of the database
        example path = '../Database/company_database.db'
        """

        if path is not None:
            self.path = path
        # Check if the database exists
        if not os.path.exists(self.path):
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            # create the database
            conn = sqlite3.connect(path)
            conn.close()
            # Create tables
            self.create_users_tables()
            # self.create_surveys_tables()
            self.create_info_db_table()
            self.create_company_info_table()
            # self.update_surveys()
        
        self.extist = True
           
    def create_table(self, template, table_name):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        primary_key = f"{template['primary_key']} INTEGER PRIMARY KEY, "
        if 'encrypted_columns' in template.keys():
            encrypted_columns = ', '.join(f"{col} BLOB" for col in template['encrypted_columns']) + ', '
        else:
            encrypted_columns = ''
        normal_columns = ', '.join(f"{col} REAL" if col in INDICATORS else f"{col} TEXT" if not 'id' in col else f"{col} INTEGER" for col in template['columns'])
        columns = primary_key + encrypted_columns + normal_columns
        
        query = f'''CREATE TABLE IF NOT EXISTS {table_name} ({columns})'''
        
        cur.execute(query)
        conn.commit()
        conn.close()
 
    def create_users_tables(self,):
        self.create_table(self.users_table_template, self.tables_names['users_table'])
        pass
    
    def create_company_info_table(self):
        self.create_table(self.company_info_table_template, self.tables_names['company_info'])

    def create_info_db_table(self):
        self.create_table(self.info_db_table_template, self.tables_names['info_db']) 
        
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        # Insert default values
        placeholders = ', '.join(['?'] * len(self.info_db_table_template['values']))
        default_values_query = f"INSERT INTO info_db ({', '.join(self.info_db_table_template['columns'])}) VALUES ({placeholders})"
        cur.execute(default_values_query, self.info_db_table_template['values'])
        conn.commit()
        conn.close()
        
    def insert_company_info(self, company_info):
        # To do this method, we need:
        # 1. Check if company_info table exists, if not create it.
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        cur.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{self.tables_names['company_info']}'")
        table_exists = cur.fetchone()
        if table_exists is None:
            self.create_company_info_table()
        
        # 2. Check that the company_info is a dict and has the keys of the company_info_table_template. If not, raise an error.
        if not isinstance(company_info, dict):
            raise ValueError('company_info must be a dictionary')
        
        if not all(key in company_info for key in self.company_info_table_template['columns']):
            raise ValueError('company_info is missing required keys')
        
        # Here we need to check the keys: "bussiness_hours" and "services_offered" This keys are dict and list respectively
        # We need to convert them to string
        
        # 3. Check if there are data in the company_info table, if not, insert the data.
        cur.execute(f"SELECT COUNT(*) FROM {self.tables_names['company_info']}")
        count = cur.fetchone()[0]

        if count == 0:
            # Serialize dictionaries and lists in company_info
            serialized_company_info = {
                k: json.dumps(v) if isinstance(v, (dict, list)) else v
                for k, v in company_info.items()
            }
            #

            placeholders = ', '.join(['?'] * len(serialized_company_info))
            columns = ', '.join(serialized_company_info.keys())
            values = tuple(serialized_company_info.values())
            query = f"INSERT INTO {self.tables_names['company_info']} ({columns}) VALUES ({placeholders})"
            cur.execute(query, values)
            conn.commit()
            
        else:
            # Serialize dictionaries and lists in company_info
            serialized_company_info = {
                k: json.dumps(v) if isinstance(v, (dict, list)) else v
                for k, v in company_info.items()
            }

            placeholders = ', '.join([f"{col} = ?" for col in serialized_company_info])
            values = tuple(serialized_company_info.values())
            query = f"UPDATE {self.tables_names['company_info']} SET {placeholders}"
            cur.execute(query, values)
            conn.commit()

        conn.close()

    def get_company_info(self):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {self.tables_names['company_info']}")
        # Get column names
        columns = [col[0] for col in cur.description]
        
        # Obtain the data as dict
        row = cur.fetchone()
        conn.close()

        if row is None:
            return None
        else:
            company_info = dict(zip(columns[1:], row[1:]))
            
            # Deserialize fields that were serialized
            deserialized_company_info = {
                k: json.loads(v) if isinstance(v, str) and self.is_serialized(v) else v
                for k, v in company_info.items()
            }

            return deserialized_company_info
        
    def is_serialized(self, value):
        try:
            json.loads(value)
            return True
        except (json.JSONDecodeError, TypeError):
            return False
        
    def insert_input(self, table_name, input_dict):
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        # Validate data and table name
        if not isinstance(input_dict, dict):
            raise ValueError('Data must be a dictionary')
        
        # Check that data has the correct keys
        columns_query = f"PRAGMA table_info({table_name})"
        cur.execute(columns_query)

        # # Encriptar datos
        # key = get_key('user')  # Puedes cambiar 'user' por el usuario correspondiente
        # columns_to_encrypt = [col for col in table_columns if col in input_dict]
        # input_dict_encrypted = {col: encrypt(str(input_dict[col]).encode('utf-8'), key) for col in columns_to_encrypt}
        # # Insert data into the table
        # columns = ', '.join(input_dict_encrypted.keys())
        # placeholders = ', '.join(['?'] * len(input_dict_encrypted))
        # values = tuple(input_dict_encrypted.values())
        # query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"

        # Insert data into the table
        columns = ', '.join(input_dict.keys())
        placeholders = ', '.join(['?'] * len(input_dict))
        values = tuple(input_dict.values())
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        
        cur.execute(query, values)
        conn.commit()
        conn.close()
    
    def encrypt_all_database(self, encrypt=False):
        conn = sqlite3.connect(os.path.join(self.path, 'company_database.db'))
        cur = conn.cursor()

        # Obtener todas las tablas en la base de datos
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cur.fetchall()

        for table in tables:
            table_name = table[0]
            cur.execute(f"PRAGMA table_info({table_name})")
            columns_info = cur.fetchall()
            
            # Obtener las columnas que no son numéricas
            non_numeric_columns = [col[1] for col in columns_info if col[2] != 'INTEGER']
            
            for column in non_numeric_columns:
                # Obtener todos los valores no numéricos en la columna
                cur.execute(f"SELECT DISTINCT {column} FROM {table_name} WHERE typeof({column}) != 'integer'")
                results = cur.fetchall()

                for result in results:
                    original_value = result[0]

                    if encrypt:
                        # Encriptar el valor
                        key = get_key('user')  # Puedes cambiar 'user' por el usuario correspondiente
                        encrypted_value = encrypt(str(original_value).encode('utf-8'), key)
                        # Actualizar la base de datos con el valor encriptado
                        cur.execute(f"UPDATE {table_name} SET {column} = ? WHERE {column} = ?", (encrypted_value, original_value))
                    else:
                        # Si no se quiere encriptar, imprimir los valores no encriptados
                        print(f"Table: {table_name}, Column: {column}, Value: {original_value}")

        conn.commit()
        conn.close()
        
        
    def get_company_dashboard(self, period = 'yearly', start_filter_date = None, end_filter_date = None, 
                              aggregate=False, wheited=False, last_session=False, filters = None):
        """
        period: str, 'yearly', 'monthly', 'weekly'
        start_filter_date: str, format: 'YYYY-MM-DD'
        end_filter_date: str, format: 'YYYY-MM-DD'
        aggregate: bool, if True, the function returns the mean of the indicators
        wheited: bool, if True, the function returns the indicators wheited giving more importance to the lastest sessions
        last_session: bool, if True, the function returns the indicators of the last session
        filters: dict, {"position": list, "shift": list, "area": list, "vessel": list}
        """
        filter_order = ['vessel', 'area', 'shift', 'position']
        conn = sqlite3.connect(self.path)
        users_table = pd.read_sql_query("SELECT * FROM users_table", conn)
        conn.close()
        if users_table.empty:
            return None
        
        # Decrypt the dataframe columns position, shift, area, vessel
        user_company = 'usercompany'

        #users_table = decrypt_dataframe(users_table, get_key(user_company), ['position', 'shift', 'area', 'vessel'])

        if users_table.empty:
            return None
            
        users_table, start_filter_date, end_filter_date = datatime_df(users_table, start_filter_date = None, end_filter_date = None)

        emotions_list = EMOTIONS_CLASSIFICATIONS['positive']+ EMOTIONS_CLASSIFICATIONS['neutral']+ EMOTIONS_CLASSIFICATIONS['negative']
        # Normalize
        users_table[emotions_list] = users_table[emotions_list].div(users_table[emotions_list].sum(axis=1), axis=0) * 100
        # Calculate the mean of the emotions 
        users_table['mean_positive_emotions'] = users_table[EMOTIONS_CLASSIFICATIONS['positive']].mean(axis=1)
        users_table['mean_neutral_emotions'] = users_table[EMOTIONS_CLASSIFICATIONS['neutral']].mean(axis=1)
        users_table['mean_negative_emotions'] = users_table[EMOTIONS_CLASSIFICATIONS['negative']].mean(axis=1)  
        users_table['positive_score'] = users_table['mean_positive_emotions'] / (users_table['mean_positive_emotions'] + users_table['mean_neutral_emotions'] + users_table['mean_negative_emotions'])
        users_table['neutral_score'] = users_table['mean_neutral_emotions'] / (users_table['mean_positive_emotions'] + users_table['mean_neutral_emotions'] + users_table['mean_negative_emotions'])
        users_table['negative_score'] = users_table['mean_negative_emotions'] / (users_table['mean_positive_emotions'] + users_table['mean_neutral_emotions'] + users_table['mean_negative_emotions'])
        numeric_columns = list(set(users_table.select_dtypes(include='number').columns) - set(['id','session_id'])) 
        
        results = {}
        if filters:
            # Obtain only the keys and values that not are empty and mantain the filter_order if the filter 
            filters = {key: value for key, value in filters.items() if value}
            for key, value in filters.items():
                if key in users_table.columns:
                    users_table = users_table[users_table[key].isin(value)]
                else:
                    raise ValueError(f"The column {key} does not exist in the users_table.")
        
        
            results = create_main_indicators_structure(filter_order, filters, users_table, query ='', 
                                     numeric_columns = numeric_columns, emotions_class = EMOTIONS_CLASSIFICATIONS, start_period = start_filter_date, 
                                     end_period = end_filter_date, period=period,
                                     aggregate = aggregate, wheited = wheited, 
                                     last_session = last_session, n_round = 2)

            return results
        else:
            res_main_indicators = main_indicators_company_dashboard(users_table, numeric_columns, emotions_class = EMOTIONS_CLASSIFICATIONS,
                                                                    aggregate = aggregate, wheited = wheited , last_session = last_session, n_round =2 )
            res_evolution = emotions_evol_ind_company_dashboard(users_table, emotions_class = EMOTIONS_CLASSIFICATIONS, numeric_columns = numeric_columns, 
                                                                start_period = start_filter_date, end_period = end_filter_date, period = period, n_round = 2)
            return {**res_main_indicators, **res_evolution}
        
if __name__=="__main__":
    survey_db = SurveyDatabase("company")
    user_database = UserDatabase()
    # survey_json = {
    #         "name": "v1-anonymous health and wellbeing survey y2 2023",
    #         "date": "05-12-2023",
    #         "due_date": "05-02-2024",
    #         "questions": [
    #             {"question": "v1-What is your position?", "options": ["Officer / Chief / SL", "Operator / Rating", "Other"], "option_type": "single", "question_category": "Work Environment and Demographics"},
    #             {"question": "v1-What is your age?", "options": ["Under 24", "25 - 34", "35 - 44", "45 - 54", "Over 55"], "option_type": "single", "question_category": "Work Environment and Demographics"}
    #         ]
    #     }
    # survey_db.insert_new_survey(survey_json = survey_json)  
      
    user_database.get_survey_next_questions(0,1)
