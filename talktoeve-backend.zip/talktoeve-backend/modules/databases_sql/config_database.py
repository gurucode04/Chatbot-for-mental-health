import os
import datetime

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)

# DATA FORMAT FOR DATABASES
# TEXT as ISO8601 strings ("YYYY-MM-DD HH:MM:SS.SSS").

# Personal Information Template v1
DEFAULT_PERSONAL_INFO_v1 = { 'primary_key': 'personal_info_id', 'encrypted_columns': ['name', 'user_id','first_name','last_name',
                                                                                      'company_id','birthday', 'nationality','location',
                                                                                      'date_of_joining','employee_id_number','email','phone',
                                                                                      'department','designation','experience','brief',
                                                                                      'family', 'friends','partner', 'persons_with_whom_he_she_lives',
                                                                                    ],
                            'columns': ['user_type'],
                            'values': ['UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 
                                    'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 
                                    'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 
                                    'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 
                                    'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN']}

# Session Table Template v1
DEFAULT_SESSION_TABLE_v1 = { 'primary_key': 'session_id', 
                            'columns': ['date', 'duration', 'depression_score', 'stress_score', 
                                    'admiration', 'amusement', 'anger', 'annoyance', 'approval', 'caring',
                                    'confusion', 'curiosity', 'desire', 'disappointment', 'disapproval',
                                    'disgust', 'embarrassment', 'excitement', 'fear', 'gratitude', 'grief',
                                    'joy', 'love', 'nervousness', 'neutral', 'optimism', 'pride',
                                    'realization', 'relief', 'remorse', 'sadness', 'surprise'],
                                'encrypted_columns': ['summary']}

# SessionhISTORY  Table Template v1
DEFAULT_SESSION_HISTORY_TABLE_v1 = { 'primary_key': 'message_id', 
                                'columns': ['session_id', 'feedback', 'role', 'depression_score', 'stress_score',
                                    'admiration', 'amusement', 'anger', 'annoyance', 'approval', 'caring',
                                    'confusion', 'curiosity', 'desire', 'disappointment', 'disapproval',
                                    'disgust', 'embarrassment', 'excitement', 'fear', 'gratitude', 'grief',
                                    'joy', 'love', 'nervousness', 'neutral', 'optimism', 'pride',
                                    'realization', 'relief', 'remorse', 'sadness', 'surprise'],
                                'encrypted_columns': ['message']}


DEFAULT_KEYPHRASES_TABLE_v1 = { 'primary_key': 'edge_id', 
                                'columns': ['session_id','message_id', 'node_id0', 'node_id1']}

DEFAULT_NODE_TABLE = { 'primary_key': 'node_id', 
                        'encrypted_columns': ['node_name', 'node_notes']}

INDICATORS = ['depression_score', 'stress_score',
            'admiration', 'amusement', 'anger', 'annoyance', 'approval', 'caring',
            'confusion', 'curiosity', 'desire', 'disappointment', 'disapproval',
            'disgust', 'embarrassment', 'excitement', 'fear', 'gratitude', 'grief',
            'joy', 'love', 'nervousness', 'neutral', 'optimism', 'pride',
            'realization', 'relief', 'remorse', 'sadness', 'surprise']

# Obtain the current date and time in format YYYY-MM-DD HH:MM:SS.SSS
current_date = datetime.datetime.now()
DEFAULT_INFO_VERSION_TABLE_V1 = { 'primary_key': 'update_id', 'columns': ['version', 'date_of_update', 'update_description'],
                                  'values': ['v3', current_date, 'We add information about the company']}

DEFAULT_SURVEY_TABLE = {'primary_key': 'survey_id', 'columns': ['survey_name', 'survey_date', 'due_date', 'n_questions']}
DEFAULT_SURVEY_QUESTION_TABLE = {'primary_key': 'question_id', 'columns': ['question_id', 'survey_id', 'question', 'question_type']}
DEFAULT_SURVEY_ANSWER_TABLE = {'primary_key': 'answer_id_question_id' , 'columns': ['answer_id', 'question_id', 'survey_id', 'answer']}
DEFAULT_SURVEY_RESPONSE_TABLE = {'primary_key': 'response_id', 'columns': ['survey_id', 'question_id', 'answer_id']}

DEFAULT_USER_SURVEY_TABLE = {'primary_key': 'survey_id', 'columns': ['survey_name', 'finish_date', 'n_questions']}
DEFAULT_USER_SURVEY_RESPONSE_TABLE = {'primary_key': 'user_survey_response_id', 'columns': ['survey_id', 'question_id', 'answer_id']}


SURVEY_DB_PATH = os.path.join(grandparent_dir, 'documents', 'surveys', 'survey_database.db')
SURVEY_DB_PATH_test = os.path.join(grandparent_dir, 'documents', 'surveys', 'survey_database_test.db')
# List of emotions and their corresponding classification
EMOTIONS_CLASSIFICATIONS = {'positive': ['admiration', 'amusement', 'approval', 'caring', 'desire', 'excitement', 
                                         'gratitude', 'joy', 'love', 'optimism', 'pride', 'relief'],
                            'neutral': [ 'confusion', 'curiosity', 'realization', 'surprise'],
                            'negative': ['anger', 'annoyance', 'disappointment', 'disapproval', 'disgust', 
                                         'embarrassment','fear', 'grief', 'nervousness', 'remorse', 'sadness']}


# COMPANY DATABASES

# Company Database Template v1
COMPANY_DB_PATH = os.path.join(grandparent_dir, 'company/company_database.db')
COMPANY_DB_PATH_test = os.path.join(grandparent_dir, 'company/company_database_test.db')
DEFAULT_USERS_TABLE_DATABASE_v1 = { 'primary_key': 'id', 
                                    'columns': ['session_id', 'location', 
                                                'position', 'shift','area',
                                                'vessel','experience','date',
                                                'duration','depression_score', 'stress_score', 
                                                'admiration', 'amusement', 'anger', 
                                                'annoyance', 'approval', 'caring',
                                                'confusion', 'curiosity', 'desire', 
                                                'disappointment', 'disapproval', 'disgust', 
                                                'embarrassment', 'excitement', 'fear', 
                                                'gratitude', 'grief', 'joy', 
                                                'love', 'nervousness', 'neutral', 
                                                'optimism', 'pride','realization', 
                                                'relief', 'remorse', 'sadness', 
                                                'surprise'],
                                    'encrypted_columns': ['user_id']}

DEFAULT_COMPANY_INFORMATION_TABLE_v1 = { 'primary_key': 'company_id',
                                        'columns':['company_name', 'industry', 'address', 'company_email', 
                                                   'company_number', 'company_logo', 
                                                   'business_hours', 'services_offered', 'company_description']}





