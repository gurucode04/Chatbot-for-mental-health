import os
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

############################## LLMs  CONFIGS ##############################
# Configuration of the models
CHAT_TEMPERATURE = 0.5
CAMBALACHE_TEMPERATURE = 0.1
CAMBALACHE_MODEL_NAME = "gpt-3.5-turbo"
# OPENAI_API_KEY = "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"
# Model FInetune
# FT_NAME = "ft:gpt-3.5-turbo-0613:eve:eve-v1:88FhyNRo" #"ft:gpt-3.5-turbo-0613:talk-to-eve:eve-sailor-v1:8eplts2C"
OPENAI_API_KEY = "sk-proj-EaWPHv38y3CWASx9DA6yT3BlbkFJvFqpItCGq7Ra9WFbeMdo"#"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"
FT_NAME = "ft:gpt-3.5-turbo-0613:talk-to-eve:eve-sailor-v1:8eplts2C"#"ft:gpt-3.5-turbo-0613:eve:eve-v1:88FhyNRo" #"ft:gpt-3.5-turbo-0613:talk-to-eve:eve-sailor-v1:8eplts2C"

############################## PROMPTS CONFIGS ##############################
# Template of prompts
#PROMPTS_PATH = os.path.join(os.getcwd() , "documents" , "master_prompts")
PROMPTS_PATH = os.path.join(root_path, "documents" , "master_prompts")

SUMMARY_CONVERSATION_PROMPT_PATH = os.path.join(PROMPTS_PATH , "summary_conversations" , "summary_conversation_prompt_v0_english.txt")
SUMMARY_CONVERSATION = {'prompt_path': SUMMARY_CONVERSATION_PROMPT_PATH, 'input_variables': ['conversation'],
                        'model_name': CAMBALACHE_MODEL_NAME, 'temperature': CAMBALACHE_TEMPERATURE, 'max_tokens': None}

MODIFIED_PERSONAL_INFORMATION_PATIENT_PROMPT_PATH = os.path.join(PROMPTS_PATH , "modified_personal_information_patient" , "modified_personal_information_patient_prompt_v0_english.txt")
PERSONAL_INFORMATION = {'prompt_path': MODIFIED_PERSONAL_INFORMATION_PATIENT_PROMPT_PATH, 'input_variables': ['conversation', 'previous_information'],
                        'model_name': CAMBALACHE_MODEL_NAME, 'temperature': CAMBALACHE_TEMPERATURE, 'max_tokens': None}

SEARCH_IN_VECTORSTORE_DATABASE_PROMPT_PATH = os.path.join(PROMPTS_PATH , "search_in_database" , "search_in_database_prompt_v0_english.txt")
SEARCH_IN_VECTORSTORE_DATABASE = {'prompt_path': SEARCH_IN_VECTORSTORE_DATABASE_PROMPT_PATH, 'input_variables': ['message','description'], 
                                  'model_name': CAMBALACHE_MODEL_NAME, 'temperature': CAMBALACHE_TEMPERATURE, 'max_tokens': None}

CONTEXT_PROMPT_PATH = os.path.join(PROMPTS_PATH , "context_maker" , "context_maker_prompt.txt")
CONTEXT = {'prompt_path': CONTEXT_PROMPT_PATH, 'input_variables': ['conversations_summaries', 'emotions'], 
           'model_name': CAMBALACHE_MODEL_NAME, 'temperature': CAMBALACHE_TEMPERATURE, 'max_tokens': None}

EVE_PROMPT_PATH = os.path.join(PROMPTS_PATH , "eve_response" , "eve_response.txt")
EVE_PROMPT = {'prompt_path': EVE_PROMPT_PATH, 'input_variables': ['personal_information', 'previous_conversations_summary', 'last_messages','patient_message'],
              'model_name': FT_NAME, 'temperature': CHAT_TEMPERATURE, 'max_tokens': None}

# This is the template for finetune the model
EVE_PROMPT_SYSTEM_FOR_FINE_TUNNING = os.path.join(PROMPTS_PATH , "eve_response" , "eve_prompt_system_for_finetunning_english.txt")
EVE_RESPONSE_FINETUNE_PROMPT_PATH = os.path.join(PROMPTS_PATH , "eve_response" , "eve_response_finetune_prompt_english.txt")

MODELS = {'summary_conversation': SUMMARY_CONVERSATION, 
           'personal_information': PERSONAL_INFORMATION, 
           'context': CONTEXT,
           'eve_response': EVE_PROMPT}


############################# TEMPLATES CONFIGS #############################
PERSONAL_INFORMATION_TEMPLATE_PATH = os.path.join(os.getcwd(), "documents" , "templates" , "personal_information_template.txt")
 
############################# VETOR DB CONFIGS #############################
VECTOR_DB_PATH = os.path.join(os.getcwd() , "modules" , "vector_database", "chroma")



############################ GLOBAL CONFIGS ############################
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 200