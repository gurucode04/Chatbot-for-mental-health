from langchain.memory import ChatMessageHistory
from modules.auxiliar_functions import convert_messages_in_txt , convert_messages_in_dictionary
import pickle
import os

class BaseConversationManager():
    def __init__(self,):
        pass
    
    def load_conversation(self, path):
        pass
    
    def save_conversation(self, path):
        pass

class ConversationManager(BaseConversationManager):
    def __init__(self,):
        super().__init__()
        
        # Initialize the memory of current conversation
        self.memory_current_conversation = ChatMessageHistory()

        self.message_id = 0
            
    def load_conversation(self, path):
        with open(path, 'rb') as file:
            saved_instance = pickle.load(file)
        # Assuming ChatMessageHistory is also serializable
        self.memory_current_conversation = saved_instance.memory_current_conversation
        self.message_id = saved_instance.message_id
    
    def save_conversation(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'wb') as file:
            pickle.dump(self, file)
    
    def add_message(self, message, is_ai_message = False):
        if is_ai_message:
            self.memory_current_conversation.add_ai_message(message)
        else:
            self.memory_current_conversation.add_user_message(message)
        
        self.memory_current_conversation.messages[-1].additional_kwargs["messaje_id"] = self.message_id
        self.message_id += 1

    def add_feedback(self, message_id, feedback):
        self.memory_current_conversation.messages[int(message_id)].additional_kwargs["feedback"] = feedback

    
    def get_conversation(self,return_dict = False):
        if return_dict:
            return convert_messages_in_dictionary(self.memory_current_conversation.messages)
        else:
            return convert_messages_in_txt(self.memory_current_conversation.messages)
    
    def get_n_last_messages(self, n_last_messages = 2):
        # If the number of messages is less than n_last_messages, we obtain all the messages
        if len(self.memory_current_conversation.messages) < n_last_messages:
            messages = self.memory_current_conversation.messages
        else:
            # Obtain the last n messages
            messages = self.memory_current_conversation.messages[-n_last_messages:]
        return convert_messages_in_txt(messages)
    
    def get_user_messages(self,return_list = False):
        messages = convert_messages_in_dictionary(self.memory_current_conversation.messages)
        # Elimitad from the dictionary the messages of the AI
        messages_ = {}
        messages_['message_id'] = [message_id for message_id, role in zip(messages['message_id'], messages['role']) if role == 'User']
        messages_['message'] = [message for message, role in zip(messages['message'], messages['role']) if role == 'User']
        
        if return_list:
            # Obtain only a list of all MESSAGE from messages_
            return messages_['message']
        else:
            return messages_
        