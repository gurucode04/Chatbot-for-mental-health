from vector_database import *
import pandas as pd
import sqlite3
import chromadb

class ChromaSurvey():
    def __init__(self, chroma_path, user_manager, survey_on_conv_flow=True):

        self.n_results = 2
        self.dist_treshold = 1.5
        self.count_treshold = 10

        self.user_manager = user_manager
        # check if the user has answered all the surveys
        survey_df = user_manager.database.get_survey_df()
        # get the survey_id of the surveys that the user has not answered (finish_date==Null)
        survey_ids = survey_df[survey_df['finish_date'].isnull()]['survey_id'].values
        # survey on conv flow dict or False if the user did answer all the surveys
        if survey_on_conv_flow:
            if len(survey_ids) == 0:
                self.survey_on_conv_flow = False
            else:
                self.survey_on_conv_flow = True
                
                self.counts = pd.DataFrame(columns=['survey_id', 'question_id', 'count', 'dist', 'min_dist'])
                self.counts.set_index(['survey_id', 'question_id'], inplace=True)
                
                self.questions_answers = {}

                chroma_client = chromadb.PersistentClient(path=chroma_path)
                self.collection = chroma_client.get_collection("survey_questions")
        else:
            self.survey_on_conv_flow = False
        
    def search_message(self, message):
        survey_responses = self.user_manager.database.get_survey_responses_df()
        results = self.collection.query(query_texts=[message], n_results=self.n_results)

        answers = [{int(k): v for k, v in d.items() if k.isdigit()} for d in results['metadatas'][0]]
        questions = results['documents'][0]
        metadata = [{k: v for k, v in d.items() if not k.isdigit()} for d in results['metadatas'][0]]

        for j in range(self.n_results):
            current_id = tuple(map(int, results['ids'][0][j].split('_')))
            if current_id not in self.counts.index:
                self.counts.loc[current_id, :] = {'count': 1, 'dist': results['distances'][0][j], 'min_dist': results['distances'][0][j]}
                self.questions_answers[results['ids'][0][j]] = {'survey_id': current_id[0], 'question_id':current_id[1], 'title': questions[j], 'options': answers[j], 'type': metadata[j]['question_type']}
            else:
                self.counts.at[current_id, 'count'] += 1
                self.counts.at[current_id, 'dist'] = (self.counts.at[current_id, 'dist'] + results['distances'][0][j]) / 2
                self.counts.at[current_id, 'min_dist'] = min(self.counts.at[current_id, 'min_dist'], results['distances'][0][j])
        
        above_the_treshold = self.counts.query(f'count<{self.count_treshold} & min_dist<{self.dist_treshold}')
        # Combine DataFrames using merge
        merged_df = pd.merge(above_the_treshold, survey_responses, on=['survey_id', 'question_id'], how='left')
        # Filter rows where answer_id is null
        result_df = merged_df[merged_df['answer_id'].isnull()]

        # si hay resultados
        if len(result_df)>0:
            # sort the df first by min_dist and then by count finally by dist
            result_df.sort_values(by=['min_dist', 'count', 'dist'], ascending=[True, False, True], inplace=True)
            # get the first result
            result_id = f"{result_df.iloc[0]['survey_id']}_{result_df.iloc[0]['question_id']}"
            # get the question
            return self.questions_answers[result_id]
        else:
            return None
        
    def search_message_survey(self, message):
        survey_responses = self.user_manager.database.get_survey_responses_df()
        results = self.collection.query(query_texts=[message], n_results=self.n_results)

        answers = [{int(k): v for k, v in d.items() if k.isdigit()} for d in results['metadatas'][0]]
        questions = results['documents'][0]
        metadata = [{k: v for k, v in d.items() if not k.isdigit()} for d in results['metadatas'][0]]

        for j in range(self.n_results):
            current_id = tuple(map(int, results['ids'][0][j].split('_')))
            if current_id not in self.counts.index:
                self.counts.loc[current_id, :] = {'count': 1, 'dist': results['distances'][0][j], 'min_dist': results['distances'][0][j]}
                self.questions_answers[results['ids'][0][j]] = {'survey_id': current_id[0], 'question_id':current_id[1], 'title': questions[j], 'options': answers[j], 'type': metadata[j]['question_type']}
            else:
                self.counts.at[current_id, 'count'] += 1
                self.counts.at[current_id, 'dist'] = (self.counts.at[current_id, 'dist'] + results['distances'][0][j]) / 2
                self.counts.at[current_id, 'min_dist'] = min(self.counts.at[current_id, 'min_dist'], results['distances'][0][j])
        
        above_the_treshold = self.counts.query(f'count<{self.count_treshold} & min_dist<{self.dist_treshold}')
        # Combine DataFrames using merge
        merged_df = pd.merge(above_the_treshold, survey_responses, on=['survey_id', 'question_id'], how='left')
        # Filter rows where answer_id is null
        result_df = merged_df[merged_df['answer_id'].isnull()]

        # si hay resultados
        if len(result_df)>0:
            # sort the df first by min_dist and then by count finally by dist
            result_df.sort_values(by=['min_dist', 'count', 'dist'], ascending=[True, False, True], inplace=True)
            # get the first result
            result_id = f"{result_df.iloc[0]['survey_id']}_{result_df.iloc[0]['question_id']}"
            # get the question
            return self.questions_answers[result_id]
        else:
            return None