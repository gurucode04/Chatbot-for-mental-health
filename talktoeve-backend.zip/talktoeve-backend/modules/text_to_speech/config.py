import os
PATH_TO_SAVE = os.path.join(os.getcwd() , "documents" , "tts-stt_files")