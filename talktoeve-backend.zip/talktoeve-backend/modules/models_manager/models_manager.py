from langchain.chat_models import ChatOpenAI
import os
import sys
from modules.auxiliar_functions import read_txt_files
from langchain.prompts import PromptTemplate

# Obtain the path to the current directory
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
# Add the path to the sys.path list
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.global_configs import CAMBALACHE_TEMPERATURE, CAMBALACHE_MODEL_NAME, MODELS, FT_NAME, CHAT_TEMPERATURE
from langchain.prompts import PromptTemplate 
from langchain.chains import LLMChain

class ModelsManager():
    def __init__(self, models=MODELS):
        """
        This class is used to manage the models that are used in the conversation analysis
        models : dict : The models that are going to be used in the conversation analysis
        keys : str : The keys of the models
        values : dict : The values of the models : 
        {'prompt_path': str, 'input_variables': list, 'model_name': str, 'temperature': float, 'max_tokens': int}
        """
        # Model for the conversation analysis
        self.models = models
        
        self.information = {key : '' for key in models.keys()}
        
        self.prompt = {key : None for key in models.keys()}
        
        self.load_prompts(models)

    def predict(self, info_key, input_variables):
        # check if info is in information keys
        if info_key not in self.information.keys():
            raise KeyError("The info is not in the information keys")
        
        # Ensure input_variables is a dictionary
        if not isinstance(input_variables, dict):
            raise TypeError("input_variables must be a dictionary")
        
        chain = LLMChain(llm = ChatOpenAI(
            model_name = self.models[info_key]['model_name'], temperature = self.models[info_key]['temperature'],
            max_tokens = self.models[info_key]['max_tokens']), 
            verbose = False, prompt = self.prompt[info_key])
        
        if info_key == 'eve_response':
            return chain.predict(**input_variables)
        else:
            self.information[info_key] = chain.predict(**input_variables)

        if info_key == 'personal_information':
            self.information[info_key] = self.check_personal_information(self.information[info_key])
            
        return self.information[info_key]

    def load_information(self, info_key, information):
        # check if info is in information keys
        if info_key not in self.information.keys():
            raise KeyError("The info is not in the information keys")
        
        # Ensure information is a string
        if not isinstance(information, str):
            raise TypeError("information must be a string")
        
        self.information[info_key] = information

    def load_prompts(self, models):
        # Check that prompt_path, keys and input_variables are lists
        if not isinstance(models, dict):
            raise TypeError("models must be a dictionary")
        # Check that the prompt has the required input variables
        for key, value in models.items():
            if not isinstance(value, dict):
                raise TypeError("The values in models must be dictionaries")
            if 'prompt_path' not in value:
                raise KeyError("The key 'prompt_path' is not in the values")
            if 'input_variables' not in value:
                raise KeyError("The key 'input_variables' is not in the values")
            if not isinstance(value['input_variables'], list):
                raise TypeError("The input_variables must be a list")
        # Load the prompts
        for key, value in models.items():
            self.load_prompt(value['prompt_path'], key, value['input_variables'])
    
    def load_prompt(self, path, key, input_variables = []):
        # We need to check that path is a valid path
        if not os.path.exists(path):
            raise FileNotFoundError("The path to load the prompts from does not exist")
        template = read_txt_files(path)
        self.prompt[key] = PromptTemplate(input_variables = input_variables, 
                                                 output_parser = None, 
                                                 partial_variables = {},
                                                 template = template, 
                                                 template_format = 'f-string', 
                                                 validate_template = True)
        
    def change_prop(self, info_key, prop_name, prop):
        """
        change the prop of the model
        info_key : str : The key of the model
        prop_name : str : The name of the prop to change
        prop : 'model_name': str, 'temperature': float, 'max_tokens': int
        """
        # check if info is in information keys
        if info_key not in self.information.keys():
            raise KeyError("The info is not in the information keys")
        if prop_name not in self.models[info_key].keys():
            raise KeyError("The prop is not in the model keys")
        if prop_name=='temperature':
            # Ensure temperature is a float
            if not isinstance(prop, float):
                raise TypeError("temperature must be a float")
        elif prop_name=='max_tokens':
            # Ensure max_tokens is an integer
            if not isinstance(prop, int):
                raise TypeError("max_tokens must be an integer")
        elif prop_name=='model_name':
            # Ensure model_name is a string
            if not isinstance(prop, str):
                raise TypeError("model_name must be a string")
        else:
            raise ValueError("The prop is not a valid prop")
        
        self.models[info_key][prop_name] = prop

    # CHECK METHODS
    def check_personal_information(self, personal_information):
        #Check if personal_information has the characters < or > and eliminated if it has
        if '<' in personal_information:
            personal_information = personal_information.replace('<', '')
        if '>' in personal_information:
            personal_information = personal_information.replace('>', '')
        return personal_information
    
    
