from utils.logger import setup_logger
from modules.eve import Eve
from traceback import print_exc

# Global dictionary to store Eve instances for users
user_eve_instances = {}
class EveInitializer:
    @staticmethod
    def initialize_eve_instance(user_name, model_name):
        global user_eve_instances
        try:
            if user_name in user_eve_instances:
                setup_logger().info(f"User {user_name} already has an Eve instance.")
                return True

            # Create a new instance of Eve for the user
            user_eve_instances[user_name] = Eve()
            user_eve_instances[user_name].initialize(user_name)

            if model_name:
                setup_logger().info(f"Model name is provided for {user_name} user. Changing the model name to {model_name}")
                user_eve_instances[user_name].models_manager.change_prop(info_key='eve_response', 
                                                    prop_name='model_name', prop=model_name)
                user_eve_instances[user_name].models_manager.change_prop(info_key='eve_response', 
                                                    prop_name='max_tokens', prop=300)
            
            setup_logger().info(f"User {user_name} initialized successfully.")
            return True
        except Exception as e:
            print_exc()
            setup_logger().error(f"Failed to initialize user {user_name}. Error: {e}\n Detailed Error: {print_exc()}")
            raise Exception(f"Failed to initialize user {user_name}. Error: {e}")


# Usage Example:
# success = EveInitializer.initialize_eve_instance(user, login_request)
