from transformers import AutoModelForSequenceClassification, AutoTokenizer
from transformers import pipeline
import numpy as np
import pandas as pd

def stress_probas(array_of_chats):
    """
    Obtain the probability of stress in a chat.
    
    Args:
        array_of_chats (list): list of chats.
    
    Returns:
        probas (list): list of probabilities of stress in each chat.
    """

    model = AutoModelForSequenceClassification.from_pretrained("ValenHumano/roberta-base-bne-detector-de-stress")
    tokenizer = AutoTokenizer.from_pretrained("ValenHumano/roberta-base-bne-detector-de-stress")

    probas = []
    for chat in array_of_chats:
        inputs = tokenizer(chat, return_tensors="pt", max_length=512, truncation=True)
        outputs = model(**inputs)
        probas.append(outputs.logits.softmax(dim=1).detach().numpy()[0][1])
    return np.array(probas)

def depression_probas(array_of_chats):
    """
    Obtain the probability of depression in a chat.
    
    Args:
        array_of_chats (list): list of chats.
    
    Returns:
        probas (list): list of probabilities of depression in each chat.
    """

    model = AutoModelForSequenceClassification.from_pretrained("ShreyaR/finetuned-roberta-depression")
    tokenizer = AutoTokenizer.from_pretrained("ShreyaR/finetuned-roberta-depression")

    probas = []
    for chat in array_of_chats:
        inputs = tokenizer(chat, return_tensors="pt", max_length=512, truncation=True)
        outputs = model(**inputs)
        probas.append(outputs.logits.softmax(dim=1).detach().numpy()[0][1])
    return np.array(probas)

def go_emotions(array_of_chats):
    """
    Obtain the probabilities of each emotion in a chat.
    
    Args:
        array_of_chats (list): list of chats.
    
    Returns:
        probas (df): df of probabilities of each emotion in each chat.
    """

    classifier = pipeline(task="text-classification", model="SamLowe/roberta-base-go_emotions", top_k=None)

    for i, chat in enumerate(array_of_chats):
        if i==0:
            df = pd.DataFrame(classifier(chat)[0]).T
            # change column to the first row
            df.columns = df.iloc[0]
            df = df[1:]
            # sort columns by name
            df = df.sort_index(axis=1)
        else:
            ap = pd.DataFrame(classifier(chat)[0]).T
            # change column to the first row
            ap.columns = ap.iloc[0]
            ap = ap[1:]
            # sort columns by name
            ap = ap.sort_index(axis=1)
            df.loc[i] = ap.values[0]
    df.reset_index(drop=True, inplace=True)
    return df
