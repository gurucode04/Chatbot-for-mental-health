import os
import sys
current_dir = os.path.dirname(os.path.abspath(__file__))
# Obtain the parent directory
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.databases_sql import config_database as db_config

from langchain.text_splitter import CharacterTextSplitter

from modules.global_configs import CHUNK_OVERLAP, CHUNK_SIZE
import numpy as np
import pandas as pd
import sqlite3
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from os import urandom
from functools import wraps
from datetime import datetime, timedelta


def create_main_indicators_structure(order_filter, filters, df, query ='', 
                                     numeric_columns = None, emotions_class = None, start_period =None, 
                                     end_period= None, period='weekly',
                                     aggregate = False, wheited = False, 
                                     last_session = False, n_round = 2):
    results = {}
    if not order_filter:
        query = query[:-4]
        df_filtered = df.query(query)
        if df_filtered.empty:
            return None
        res_main_indicators = main_indicators_company_dashboard(df_filtered, numeric_columns, emotions_class,
                                                                aggregate, wheited , last_session , n_round )
        res_evolution = emotions_evol_ind_company_dashboard(df_filtered, emotions_class, numeric_columns, start_period, end_period, 
                                                                period , n_round )
        # Combine the results
        return {**res_main_indicators, **res_evolution}
    key = order_filter[0]
    rest_keys = order_filter[1:]
    for value in filters[key]:
        query_ = query[:] + f'{key} == "{value}" and '
        results[f'{key}:{value}'] = create_main_indicators_structure(rest_keys, filters, df, query_, numeric_columns, 
                                                                     emotions_class,start_period,end_period,period,
                                                                     aggregate,wheited,last_session,n_round)
        if results[f'{key}:{value}'] is None or results[f'{key}:{value}'] == {}:
            del results[f'{key}:{value}']
        
    
    return results 
        


def create_nested_structure(keys, structure):
    if not keys:
        return None
    key = keys[0]
    rest_keys = keys[1:]
    return {value: create_nested_structure(rest_keys, structure) for value in structure[key]}

def fill_values(node, df_filtered, function = None, arguments = {}):
    if isinstance(node, dict):
        for key in node:
            node[key] = fill_values(node[key], df_filtered, function, arguments)
        return node
    else:
        if function is not None:
            return function(df_filtered, **arguments)

def main_indicators_user_dashboard(sessions_table_filtered, numeric_columns, emotions_class, 
                                   aggregate = False, wheited = False, last_session = False, n_round = 2):
    results = {}
    if sessions_table_filtered.empty:
        results['main_indicators'] = None
        results['positive_emotions'] = None
        results['negative_emotions'] = None
        results['neutral_emotions'] = None
    else:
        scores = pd.DataFrame()
        scores_except_last_session = pd.DataFrame()
        if len(sessions_table_filtered) == 1:
            scores = sessions_table_filtered[numeric_columns]
            scores_except_last_session = sessions_table_filtered[numeric_columns]
        else:
            if aggregate:
                # Main indicators
                scores = sessions_table_filtered[numeric_columns].agg(['mean'])
                scores_except_last_session = (sessions_table_filtered.sort_values('session_id', ascending=False).iloc[1:][numeric_columns].agg(['mean']))
            elif wheited:
                scores = pd.DataFrame()  # DataFrame para almacenar los resultados
                scores_except_last_session = pd.DataFrame()
                sessions_table_filtered.sort_values('session_id', ascending=False)
                for col in numeric_columns:
                    col_scores = exponential_average(sessions_table_filtered.sort_values('session_id', ascending=False)[col])
                    col_scores_except_last_session = exponential_average(sessions_table_filtered.sort_values('session_id', ascending=False).iloc[1:][col])
                    scores[col] = col_scores
                    scores_except_last_session[col] = col_scores_except_last_session 
            elif last_session:
                df_sorted = sessions_table_filtered.sort_values(['session_id'], ascending=[False])
                scores = df_sorted.head(1)[numeric_columns]
                scores_except_last_session = df_sorted.iloc[1:2][numeric_columns]
        average_score = scores.copy()
        delta_score = average_score - scores_except_last_session
        # Here we fill nan values with 0
        average_score.fillna(0, inplace=True)
        delta_score.fillna(0, inplace=True)
        
        # Positive Emotions
        top_3_emotions = average_score[emotions_class['positive']].T
        top_3_emotions = top_3_emotions.nlargest(3,top_3_emotions.columns[0])
        positive_emotions_names =  top_3_emotions.index.to_list()
        positive_emotions_values = np.squeeze(top_3_emotions.values)
        # Neutral Emotions
        top_3_emotions = average_score[emotions_class['neutral']].T
        top_3_emotions = top_3_emotions.nlargest(3, top_3_emotions.columns[0])
        neutral_emotions_names =  top_3_emotions.index.to_list()
        neutral_emotions_values = np.squeeze(top_3_emotions.values)
        # Negative Emotions
        top_3_emotions = average_score[emotions_class['negative']].T
        top_3_emotions = top_3_emotions.nlargest(3, top_3_emotions.columns[0])
        negative_emotions_names =  top_3_emotions.index.to_list()
        negative_emotions_values = np.squeeze(top_3_emotions.values)

        results['main_indicators'] = {
            'stress_score': round(average_score['stress_score'].iloc[0], n_round),
            'delta_stress_score': round(delta_score['stress_score'].iloc[0], n_round),
            'depression_score': round(average_score['depression_score'].iloc[0], n_round),
            'delta_depression_score': round(delta_score['depression_score'].iloc[0], n_round),
            'positive_score': round(average_score['positive_score'].iloc[0], n_round),
            'delta_positive_score': round(delta_score['positive_score'].iloc[0], n_round),
            'neutral_score': round(average_score['neutral_score'].iloc[0], n_round),
            'delta_neutral_score': round(delta_score['neutral_score'].iloc[0], n_round),
            'negative_score': round(average_score['negative_score'].iloc[0], n_round),
            'delta_negative_score': round(delta_score['negative_score'].iloc[0], n_round)
        }
            
        results['positive_emotions'] = {
                            '1_emotion_name':  positive_emotions_names[0],
                            '1_emotion_score': round( positive_emotions_values[0], n_round),
                            '2_emotion_name':positive_emotions_names[1],
                            '2_emotion_score': round( positive_emotions_values[1], n_round),  
                            '3_emotion_name':  positive_emotions_names[2],
                            '3_emotion_score':  round(positive_emotions_values[2], n_round),
                            }

        results['negative_emotions'] = {
                            '1_emotion_name': negative_emotions_names[0],
                            '1_emotion_score':  round(negative_emotions_values[0], n_round),
                            '2_emotion_name': negative_emotions_names[1],
                            '2_emotion_score':  round(negative_emotions_values[1], n_round),
                            '3_emotion_name': negative_emotions_names[2],
                            '3_emotion_score':  round(negative_emotions_values[2], n_round),
                            }

        results['neutral_emotions'] = {
                            '1_emotion_name': neutral_emotions_names[0],
                            '1_emotion_score': round( neutral_emotions_values[0], n_round),
                            '2_emotion_name': neutral_emotions_names[1],
                            '2_emotion_score':  round(neutral_emotions_values[1], n_round),
                            '3_emotion_name': neutral_emotions_names[2],
                            '3_emotion_score':  round(neutral_emotions_values[2], n_round),
                            }
    
    return results
    
def emotions_evol_ind_user_dashboard(sessions_table, emotions_class, start_period, end_period, period, n_round = 2):
    results = {'mental_health': {},
               'evolution_metrics': {}}
    results_dict = calcular_fechas(period, start_period, end_period)
    it_key = 0
    for key in results_dict.keys():
        results_dict[key]['init_date'] = pd.to_datetime(results_dict[key]['init_date'], format='%d/%m/%Y')
        results_dict[key]['end_date'] = pd.to_datetime(results_dict[key]['end_date'], format='%d/%m/%Y')
        init_date = results_dict[key]['init_date']
        end_date = results_dict[key]['end_date']
        sessions_table_filtered = sessions_table[(sessions_table['date'] >= init_date) & (sessions_table['date'] <= end_date)]
        
        if not sessions_table_filtered.empty:
            
            p_score = sessions_table_filtered[emotions_class['positive']].mean(axis = 1)[0] / (sessions_table_filtered[emotions_class['positive']].mean(axis = 1)[0] + sessions_table_filtered[emotions_class['neutral']].mean(axis = 1)[0] + sessions_table_filtered[emotions_class['negative']].mean(axis = 1)[0])
            neu_score = sessions_table_filtered[emotions_class['neutral']].mean(axis = 1)[0] / (sessions_table_filtered[emotions_class['positive']].mean(axis = 1)[0] + sessions_table_filtered[emotions_class['neutral']].mean(axis = 1)[0] + sessions_table_filtered[emotions_class['negative']].mean(axis = 1)[0])
            neg_score = sessions_table_filtered[emotions_class['negative']].mean(axis = 1)[0] / (sessions_table_filtered[emotions_class['positive']].mean(axis = 1)[0] + sessions_table_filtered[emotions_class['neutral']].mean(axis = 1)[0] + sessions_table_filtered[emotions_class['negative']].mean(axis = 1)[0])
            results['mental_health'][it_key] = {'period': f'{init_date.strftime("%d/%m/%Y")} - {end_date.strftime("%d/%m/%Y")}',
                                             'positive_score': round(p_score, n_round),
                                             'neutral_score': round(neu_score, n_round),
                                             'negative_score': round(neg_score, n_round),}
            results['evolution_metrics'][it_key] = {'period': f'{init_date.strftime("%d/%m/%Y")} - {end_date.strftime("%d/%m/%Y")}',
                                             'stress_score': round(sessions_table_filtered['stress_score'].mean(), n_round),
                                            'depression_score': round(sessions_table_filtered['depression_score'].mean(), n_round),
                                            'positive_score': round(sessions_table_filtered[emotions_class['positive']].mean(axis = 1)[0], n_round),}
            it_key += 1
    return results
            
            
def emotions_evol_ind_company_dashboard(users_table, emotions_class, numeric_columns, start_period, end_period, 
                                        period, n_round = 2):
    results = {'mental_health': {},
               'evolution_metrics': {}}
    results_dict = calcular_fechas(period, start_period, end_period)
    it_key = 0
    for key in results_dict.keys():
        results_dict[key]['init_date'] = pd.to_datetime(results_dict[key]['init_date'], format='%d/%m/%Y')
        results_dict[key]['end_date'] = pd.to_datetime(results_dict[key]['end_date'], format='%d/%m/%Y')
        init_date = results_dict[key]['init_date']
        end_date = results_dict[key]['end_date']
        users_table_filtered = users_table[(users_table['date'] >= init_date) & (users_table['date'] <= end_date)]
        users_table_filtered.reset_index(inplace = False, drop = True)
        if not users_table_filtered.empty:
            scores = users_table_filtered.groupby('user_id')[numeric_columns].mean()
            p_score = scores[emotions_class['positive']].mean(axis = 1) / (scores[emotions_class['positive']].mean(axis = 1) + scores[emotions_class['neutral']].mean(axis = 1) + scores[emotions_class['negative']].mean(axis = 1))
            neu_score = scores[emotions_class['neutral']].mean(axis = 1) / (scores[emotions_class['positive']].mean(axis = 1) + scores[emotions_class['neutral']].mean(axis = 1) + scores[emotions_class['negative']].mean(axis = 1))
            neg_score = scores[emotions_class['negative']].mean(axis = 1) / (scores[emotions_class['positive']].mean(axis = 1) + scores[emotions_class['neutral']].mean(axis = 1) + scores[emotions_class['negative']].mean(axis = 1))
            pp_score = scores[emotions_class['positive']].mean(axis = 1)
            if len(scores)>1:
                p_score = p_score.mean()
                neu_score = neu_score.mean()
                neg_score = neg_score.mean()
                pp_score = pp_score.mean()
            else:
                p_score = p_score.reset_index(drop=True)[0]
                neu_score = neu_score.reset_index(drop=True)[0]
                neg_score = neg_score.reset_index(drop=True)[0]
                pp_score = pp_score.reset_index(drop=True)[0]
            results['mental_health'][it_key] = {'period': f'{init_date.strftime("%d/%m/%Y")} - {end_date.strftime("%d/%m/%Y")}',
                                             'positive_score': round(p_score, n_round),
                                             'neutral_score': round(neu_score, n_round),
                                             'negative_score': round(neg_score, n_round),}
            results['evolution_metrics'][it_key] = {'period': f'{init_date.strftime("%d/%m/%Y")} - {end_date.strftime("%d/%m/%Y")}',
                                             'stress_score': round(scores['stress_score'].mean(), n_round),
                                            'depression_score': round(scores['depression_score'].mean(), n_round),
                                            'positive_score': round(pp_score, n_round),}
            it_key += 1
    return results
            
            

def ritik_format(dashboard):
    
    # Positive emotions format
    dashboard['positive_emotions'] = [
        {'emotion_name': dashboard['positive_emotions']['1_emotion_name'], 'emotion_score': dashboard['positive_emotions']['1_emotion_score']},
        {'emotion_name': dashboard['positive_emotions']['2_emotion_name'], 'emotion_score': dashboard['positive_emotions']['2_emotion_score']},
        {'emotion_name': dashboard['positive_emotions']['3_emotion_name'], 'emotion_score': dashboard['positive_emotions']['3_emotion_score']}
    ]
            
    # Neutral emotions format
    dashboard['neutral_emotions'] = [
        {'emotion_name': dashboard['neutral_emotions']['1_emotion_name'], 'emotion_score': dashboard['neutral_emotions']['1_emotion_score']},
        {'emotion_name': dashboard['neutral_emotions']['2_emotion_name'], 'emotion_score': dashboard['neutral_emotions']['2_emotion_score']},
        {'emotion_name': dashboard['neutral_emotions']['3_emotion_name'], 'emotion_score': dashboard['neutral_emotions']['3_emotion_score']}
    ]
    # Negative emotions format
    dashboard['negative_emotions'] = [
        {'emotion_name': dashboard['negative_emotions']['1_emotion_name'], 'emotion_score': dashboard['negative_emotions']['1_emotion_score']},
        {'emotion_name': dashboard['negative_emotions']['2_emotion_name'], 'emotion_score': dashboard['negative_emotions']['2_emotion_score']},
        {'emotion_name': dashboard['negative_emotions']['3_emotion_name'], 'emotion_score': dashboard['negative_emotions']['3_emotion_score']}
    ]
    # Mental health format
    period = []
    values_ps = []
    values_ns = []
    values_neutrals = []
    for k in dashboard['mental_health'].keys():
        period.append(dashboard['mental_health'][k]['period'])
        values_ps.append(dashboard['mental_health'][k]['positive_score'])
        values_ns.append(dashboard['mental_health'][k]['negative_score'])
        values_neutrals.append(dashboard['mental_health'][k]['neutral_score'])
    dashboard['mental_health'] = {'period': period,
                                'positive_score': values_ps,
                                'negative_score': values_ns,
                                'neutral_score': values_neutrals}
    # Evolution metrics format
    period = []
    values_ss = []
    values_ds = []
    values_ps = []
    for k in dashboard['evolution_metrics'].keys():
        period.append(dashboard['evolution_metrics'][k]['period'])
        values_ps.append(dashboard['evolution_metrics'][k]['positive_score'])
        values_ss.append(dashboard['evolution_metrics'][k]['stress_score'])
        values_ds.append(dashboard['evolution_metrics'][k]['depression_score'])
    dashboard['evolution_metrics'] = {'period': period,
                                'positive_score': values_ps,
                                'stress_score': values_ss,
                                'depression_score': values_ds}
    return dashboard
    

            
            
def main_indicators_company_dashboard(users_table, numeric_columns, emotions_class,
                                      aggregate = False, wheited = False, last_session = False, 
                                      n_round = 2):
    results = {}
    if users_table.empty:
        results['main_indicators'] = None
            
        results['positive_emotions'] = None

        results['negative_emotions'] = None

        results['neutral_emotions'] = None
    else:
        if len(users_table) == 1:
            scores = users_table[numeric_columns]
            scores_except_last_session = users_table[numeric_columns]
        else:
            if aggregate:
                # Main indicators
                scores = users_table.groupby('user_id')[numeric_columns].mean()
                scores_except_last_session = (users_table.sort_values('session_id', ascending=False)
                                                .groupby('user_id')[numeric_columns]
                                                .apply(lambda x: x.iloc[1:].mean())
                                            )
            elif wheited:
                # Main indicators
                scores = users_table.groupby('user_id')[numeric_columns].apply(exponential_average)
                scores_except_last_session = (users_table.sort_values('session_id', ascending=False)
                                                .groupby('user_id')[numeric_columns]
                                                .apply(lambda x: x.iloc[1:].pipe(exponential_average) if len(x) > 1 else pd.DataFrame(0, columns=numeric_columns, index=[x.name]))
                                            )
            elif last_session:
                df_sorted = users_table.sort_values(['user_id', 'session_id'], ascending=[True, False])
                # Obtener las dos últimas sesiones para cada usuario
                last_two_sessions = df_sorted.groupby('user_id').head(2)
                scores = last_two_sessions[last_two_sessions['session_id'] == last_two_sessions.groupby('user_id')['session_id'].transform('max')]
                scores_except_last_session = last_two_sessions[last_two_sessions['session_id'] == last_two_sessions.groupby('user_id')['session_id'].transform(lambda x: x.nlargest(2).iloc[-1])]
            
        # Here we calculate the mean across every subject
        scores_except_last_session.fillna(0, inplace=True)
        average_score = scores.mean()
        delta_score = average_score - scores_except_last_session.mean()

        # Positive Emotions
        top_3_emotions = average_score[emotions_class['positive']].nlargest(3)
        positive_emotions_names =  top_3_emotions.index.to_list()
        positive_emotions_values = top_3_emotions.values
        # Neutral Emotions
        top_3_emotions = average_score[emotions_class['neutral']].nlargest(3)
        neutral_emotions_names =  top_3_emotions.index.to_list()
        neutral_emotions_values = top_3_emotions.values
        # Negative Emotions
        top_3_emotions = average_score[emotions_class['negative']].nlargest(3)
        negative_emotions_names =  top_3_emotions.index.to_list()
        negative_emotions_values = top_3_emotions.values


        results['main_indicators'] = { 'stress_score': round(average_score['stress_score'],n_round),
                'delta_stress_score': round(delta_score['stress_score'], n_round),
                'depression_score': round(average_score['depression_score'], n_round),
                'delta_depression_score': round(delta_score['depression_score'], n_round),
                'positive_score': round(average_score['positive_score'], n_round),
                'delta_positive_score': round(delta_score['positive_score'], n_round),
                'neutral_score': round(average_score['neutral_score'], n_round),
                'delta_neutral_score':round(delta_score['neutral_score'], n_round),
                'negative_score': round(average_score['negative_score'], n_round),
                'delta_negative_score': round(delta_score['negative_score'], n_round)}
            
        results['positive_emotions'] = {
                            '1_emotion_name': positive_emotions_names[0],
                            '1_emotion_score': round(positive_emotions_values[0], n_round),
                            '2_emotion_name': positive_emotions_names[1],
                            '2_emotion_score': round(positive_emotions_values[1], n_round),  
                            '3_emotion_name': positive_emotions_names[2],
                            '3_emotion_score': round(positive_emotions_values[2], n_round),
                            }

        results['negative_emotions'] = {
                            '1_emotion_name': negative_emotions_names[0],
                            '1_emotion_score': round(negative_emotions_values[0], n_round),
                            '2_emotion_name': negative_emotions_names[1],
                            '2_emotion_score': round(negative_emotions_values[1], n_round),
                            '3_emotion_name': negative_emotions_names[2],
                            '3_emotion_score': round(negative_emotions_values[2], n_round),
                            }

        results['neutral_emotions'] = {
                            '1_emotion_name': neutral_emotions_names[0],
                            '1_emotion_score': round(neutral_emotions_values[0], n_round),
                            '2_emotion_name': neutral_emotions_names[1],
                            '2_emotion_score': round(neutral_emotions_values[1], n_round),
                            '3_emotion_name': neutral_emotions_names[2],
                            '3_emotion_score': round(neutral_emotions_values[2], n_round),
                            }
        
    return results

def datatime_df(sessions_table, start_filter_date = None, end_filter_date = None):
    sessions_table['date'] = pd.to_datetime(sessions_table['date'], format='%Y_%m_%d')
    if start_filter_date is not None and end_filter_date is not None:
        # Here the formate used in users_table is 'YYYY_MM_DD'
        start_filter_date = pd.to_datetime(start_filter_date, format='%Y-%m-%d')
        end_filter_date = pd.to_datetime(end_filter_date, format='%Y-%m-%d')
        sessions_table = sessions_table[(sessions_table['date'] >= start_filter_date) & (sessions_table['date'] <= end_filter_date)]
        end_filter_date = end_filter_date
        start_filter_date = start_filter_date
    else:
        end_filter_date = sessions_table['date'].max()
        start_filter_date = sessions_table['date'].min()
    
    return sessions_table, start_filter_date, end_filter_date

def exponential_average(df, factor=0.5):
    # Check if df is a dataframe or a series
    if df.__class__.__name__ == 'Series':
        df = pd.DataFrame(df)
        
    weigths = np.power(factor, np.arange(len(df)))
    average = np.average(df, weights=weigths, axis=0)
    
    df_ = pd.DataFrame(average, index=df.columns, columns=['average']).T
    return df_

def diff_weeks(d1, d2):
    return (d1 - d2).days // 7

def diff_months(d1, d2):
    return (d1.year - d2.year) * 12 + d1.month - d2.month

def diff_years(d1, d2):
    return d1.year - d2.year

def calcular_fechas(periodo, fecha_inicio, fecha_actual):
    fechas_dict = {}
    
    if periodo == 'weekly':
        semanas_diferencia = diff_weeks(fecha_actual, fecha_inicio)
        init_date = fecha_inicio
        for i in range(1, semanas_diferencia + 2):
            end_date = init_date + timedelta(days=7 - 1)
            fechas_dict[i] = {'init_date': init_date.strftime("%d/%m/%Y"), 'end_date': end_date.strftime("%d/%m/%Y")}
            init_date = end_date + timedelta(days=1)
            
    elif periodo == 'monthly':
        months_diff = diff_months(fecha_actual, fecha_inicio)
        init_date = fecha_inicio.replace(day=1)
        for month in range(1, months_diff + 1):
            end_date = init_date.replace(day=1, month=init_date.month + 1) - timedelta(days=1)
            fechas_dict[month] = {'init_date': init_date.strftime("%d/%m/%Y"), 'end_date': end_date.strftime("%d/%m/%Y")}
            init_date = end_date + timedelta(days=1)
            
    elif periodo == 'yearly':
        years_diff = diff_years(fecha_actual, fecha_inicio)
        init_date = fecha_inicio.replace(month=1, day=1)
        for year in range(years_diff + 1):
            end_date = init_date.replace(month=12, day=31, year=init_date.year)
            fechas_dict[year] = {'init_date': init_date.strftime("%d/%m/%Y"), 'end_date': end_date.strftime("%d/%m/%Y")}
            init_date = end_date + timedelta(days=1)
    
    else:
        raise ValueError("Periodo no válido. Debe ser 'weekly', 'monthly' o 'yearly'")
    
    return fechas_dict


def filter_columns(source, target):
    return [column for column in source.get('columns', []) if column in target] + \
           [column for column in source.get('encrypted_columns', []) if column in target]

def encrypt(text, key):
    iv = urandom(16)  # Initialization Vector de 16 bytes
    cipher = Cipher(algorithms.AES(key), modes.OFB(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(text) + encryptor.finalize()
    return iv + ciphertext

def decrypt(text, key):
    iv = text[:16]
    ciphertext = text[16:]
    cipher = Cipher(algorithms.AES(key), modes.OFB(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    plaintext = decryptor.update(ciphertext) + decryptor.finalize()
    return plaintext

def get_encrypted_columns(db_path, table_name):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute(f'PRAGMA table_info({table_name})')
    columns_info = cursor.fetchall()

    columns_to_encrypt = [column_info[1] for column_info in columns_info if column_info[2] == 'BLOB']

    conn.close()
    return columns_to_encrypt


def encrypt_dataframe(df, key, columns_to_encrypt):
    for column in columns_to_encrypt:
        df[column] = df[column].apply(lambda x: encrypt(str(x).encode('utf-8'), key))
    return df

def decrypt_dataframe(df, key, columns_to_decrypt):
    for column in columns_to_decrypt:
        df[column] = df[column].apply(lambda x: decrypt(x, key).decode('utf-8'))
    return df

def decrypt_dataframe_survey(df, key, columns_to_decrypt):
    for column in columns_to_decrypt:
        df[column] = df[column].apply(lambda x: decrypt(x, key).decode('utf-8'))
    return df

def get_key(user):
    key = b'<b\xe1\xf1Q\x08\x9b\xf6U\x80_\xf9\xbc\xa8E8\x93Z\xda\x9bS\xf6\xa6\x1dD\x84!2L\xb0\xe43'
    return key


def calculate_emotion_score(df, emotions = [], per_session = True):
    filter_dataframe = df[emotions]
    score = filter_dataframe.sum(axis=1)
    

def obtain_number_session(file_name):
    parts = file_name.split("_")
    return int(parts[2])

def read_txt_files(path):
    file_path  = path 
    with open(file_path, 'r') as output_file:
        content = output_file.read()
    return content


def split_txt_file(raw_text, separator = "\n#"):
    text_splitter = CharacterTextSplitter(
            separator=separator,
            chunk_size= CHUNK_SIZE,
            chunk_overlap= CHUNK_OVERLAP,
            length_function=len,
            
            
        )
    chunks = text_splitter.split_text(raw_text)
    return chunks


def convert_messages_in_txt(conversation_messages):
    conversation_txt = ""
    for message in conversation_messages:
        if message.__class__.__name__ == "AIMessage":
            conversation_txt += 'EVE: ' + message.content + '\n'
        elif message.__class__.__name__ == "HumanMessage":
            conversation_txt += 'User: ' + message.content + '\n'
    return conversation_txt

def convert_messages_in_dictionary(conversation_messages):
    conversation_dict = {'message_id': [], 'role': [], 'message': [], 'feedback': []}
    message_it = 0

    for message in conversation_messages:
        if message.__class__.__name__ == "AIMessage":
            conversation_dict['message_id'].append(str(message_it))
            conversation_dict['role'].append('Eve')
            conversation_dict['message'].append(message.content)
            if 'feedback' in message.additional_kwargs:
                conversation_dict['feedback'].append(message.additional_kwargs['feedback'])
            else:
                conversation_dict['feedback'].append(np.nan)
        elif message.__class__.__name__ == "HumanMessage":
            conversation_dict['message_id'].append(str(message_it))
            conversation_dict['role'].append('User')
            conversation_dict['message'].append(message.content)
            conversation_dict['feedback'].append(np.nan)

        message_it += 1

    return conversation_dict


def save_as_txt(path, content):
    file_path  = path 
    if not os.path.exists(os.path.dirname(file_path)):
        #Create the directory
        os.makedirs(os.path.dirname(file_path))
    with open(file_path, 'w') as output_file:
        output_file.write(content)
        
def read_txt_file(path):
    file_path  = path 
    with open(file_path, 'r') as output_file:
        content = output_file.read()
    return content
        
def convert_state_str_to_variables(state_str):
    lineas = state_str.split('\n')

    opciones = {}  # Crear un diccionario para almacenar las opciones

    for linea in lineas:
        if ":" in linea:
            clave, valor = linea.split(':')
            opciones[clave.strip()] = valor.strip() == "True"

    # Encontrar las claves con valores "True"
    claves_true = [clave for clave, valor in opciones.items() if valor]

    return claves_true[0] 

def intercalar_con_nan(array, last_role):
    tamaño = len(array)
    if last_role == 'Eve':
        output = np.empty(2 * tamaño)
    else:
        output = np.empty(2 * tamaño - 1)
    output[::2] = array
    output[1::2] = np.nan
    return output

def intercalar_con_nan_df(df, last_role):
    df_intercalado = pd.DataFrame(index=np.arange(len(df)*2 - 1 if last_role == 'Adam' else len(df)*2), columns=df.columns)

    for column in df.columns:
        output = np.empty(len(df)*2 - 1 if last_role == 'Adam' else len(df)*2)
        output[: : 2] = df[column].values
        output[1: : 2] = np.nan
        df_intercalado[column] = output
    
    return df_intercalado

def promedio_ponderado_exponencial(df, columnas_excluidas, columna_sesion, factor=0.5):
    # Filtrar las columnas del DataFrame que no están en la lista de columnas excluidas
    columnas_calculo = [col for col in df.columns if col not in columnas_excluidas]
    
    # Ordenar el DataFrame por la columna de sesión para asegurar que esté en el orden correcto
    df = df.sort_values(by=columna_sesion, ascending=True)
    
    # Crear un vector de pesos exponenciales
    pesos = np.power(factor, df[columna_sesion])
    
    # Seleccionar solo las columnas para el cálculo
    df_calculo = df[columnas_calculo]
    
    # Multiplicar cada valor de las columnas por los pesos y calcular el promedio ponderado
    promedio_ponderado = np.average(df_calculo, weights=pesos, axis=0)
    
    # Crear un dataframe con los promedios por columna
    promedios_por_columna = pd.DataFrame(promedio_ponderado, index=df_calculo.columns, columns=['promedio_ponderado']).T
    
    return promedios_por_columna

def exponential_average(df, factor=0.5):
    # Check if df is a dataframe or a series
    if df.__class__.__name__ == 'Series':
        df = pd.DataFrame(df)
        
    weigths = np.power(factor, np.arange(len(df)))
    average = np.average(df, weights=weigths, axis=0)
    
    df_ = pd.DataFrame(average, index=df.columns, columns=['average']).T
    return df_


    
    
    