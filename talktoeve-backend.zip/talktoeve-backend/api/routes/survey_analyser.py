import datetime
import os
from db.schema.ChatMessages import ChatMessages
from db.services.ChatMessageServiceProvider import ChatMessageServiceProvider
from fastapi import APIRouter, Depends, HTTPException
from typing import Annotated  # , Optional,  Literal

# from db.session import get_db, AsyncSessionLocal
from db.GenericAccessProvider import GenericAccessProvider
from config.constants.prompt_constants import summary_system_prompt
from db.session import get_db


from sentence_transformers import SentenceTransformer, util
from typing import List, Dict, Any


# Load the pre-trained SBERT model
model = SentenceTransformer('paraphrase-mpnet-base-v2')


def compute_similarity(question, response):
    """
    Computes the similarity between a survey question and a user response using SBERT.
    Args:
        question (str): The survey question.
        response (str): The user response.
    Returns:
        float: A similarity score between 0 and 1.
    """
    embeddings = model.encode([question, response], convert_to_tensor=True)
    similarity = util.pytorch_cos_sim(embeddings[0], embeddings[1])
    return similarity.item()

def match_response_to_question(response, survey_questions, threshold):
    """
    Matches a user response to the most relevant survey question based on semantic similarity.
    Args:
        response (str): The user response.
        survey_questions (Dict[str, str]): Dictionary of survey questions.
        threshold (float): Similarity threshold to determine if a question is answered.
    Returns:
        str: The ID of the matched question, or None if no match exceeds the threshold.
    """
    best_match = None
    highest_similarity = 0

    for question_id, question_data in survey_questions.items():
        question_text = question_data['question'].strip().lower()
        similarity_score = compute_similarity(question_text, response)
        
        if similarity_score > highest_similarity and similarity_score >= threshold:
            highest_similarity = similarity_score
            best_match = question_id
    
    return best_match

def analyze_survey_responses(user_responses, survey_questions, threshold):
    """
    Analyzes the user responses and determines if they have answered any survey questions.
    Args:
        user_responses (List[str]): List of user responses.
        survey_questions (Dict[str, Dict]): Dictionary of survey questions.
        threshold (float): Similarity threshold to consider a question as answered.
    Returns:
        Dict[str, bool]: Dictionary indicating whether each survey question has been answered.
    """
    answered_questions = {q_id: False for q_id in survey_questions.keys()}

    for response in user_responses:
        matched_question = match_response_to_question(response, survey_questions, threshold)
        
        if matched_question:
            answered_questions[matched_question] = True

    return answered_questions

def count_answered_questions(answered_questions):
    """
    Counts the total number of answered questions.
    Args:
        answered_questions (Dict[str, bool]): Dictionary of answered questions.
    Returns:
        int: The total number of questions answered.
    """
    return sum(answered_questions.values())


router = APIRouter()

@router.get("/survey_analyser")
async def survey_analyser():
    db = get_db()
    chat_messages_access_provider = GenericAccessProvider(ChatMessages, db)
    chat_message_service = ChatMessageServiceProvider(chat_messages_access_provider)
    
    # Sample survey data
    survey = {
        "id": "000",
        "name": "anonymous health and wellbeing survey y2 2023",
        "date": "05-12-2023",
        "questions": {
            "question_0": {
                "question": "What is your position?", 
                "answers": ["Officer / Chief / SL", "Operator / Rating", "Other"]
            },
            "question_1": {
                "question": "What is your age?", 
                "answers": ["Under 24", "25 - 34", "35 - 44", "45 - 54", "Over 55"]
            },
            "question_2": {
                "question": "What shift are you on?", 
                "answers": ["00 - 12", "12 - 24", "Dayshift", "Other"]
            },
            "question_3": {
                "question": "How many years of seismic offshore experience do you have?", 
                "answers": ["1 year or less", "2 - 4 years", "5 - 9 years", "10 - 15 years", "Over 15 years"]
            },
            "question_4": {
                "question": "Which vessel do you work on?", 
                "answers": ["Tethys","Sovereign","Vanguard","Atlas","Hyperion","Tansa","Apollo","Swift","Victory"]
            },
            "question_5": {
                "question": "How many hours per day (on - and off shift) do you spend sitting orphysically inactive?", 
                "answers": ["Less than 2 hrs", "3 - 4 hrs", "5 - 7 hrs", "8 - 11 hrs", "Over 11 hrs"]
            },
            "question_6": {
                "question": "How often do you go outside to get some fresh air during a day?", 
                "answers": ["Never", "Almost never", "Sometimes", "Fairly often", "Very often"]
            },
            "question_7": {
                "question": "How often do you do exercise in your time off per week?", 
                "answers": ["Never","0 - 60 minutes","61 - 100 minutes","101 - 149 minutes","150 - 300 minutes","More than 300 minutes"]
            },
            "question_8": {
                "question": "How many servings of fruit and vegetables do you usually eat per day (athome and at work)?", 
                "answers": ["1 or less", "2 servings", "3 servings", "4 servings", "5 or more"]
            },
            "question_9": {
                "question": "How many days a week do you usually eat fast food or food that is highin fat and salt (at home and at work)?", 
                "answers": ["None", "1", "2 - 3 times", "4 - 5 times", "5 or more"]
            },
            "question_10": {
                "question": "Healthy options that I want to eat are served onboard?", 
                "answers": ["Never", "Almost never", "Sometimes", "Fairly often", "Very often"]
            },
            "question_11": {
                "question": "When was the last time you had your cholesterol measured?", 
                "answers": ["Never", "Last month", "6 months", "1 year", "Over 2 years"]
            },
            "question_12": {
                "question": "When was the last time you had your blood pressuremeasured?", 
                "answers": ["Last month", "6 months", "1 year", "Over 2 years"]
            },
            "question_13": {
                "question": "I'm comfortable seeing the Medic if I feel unwell.", 
                "answers": ["Strongly agree", "Agree", "Neutral", "Disagree", "Strongly disagree"]
            },
            "question_14": {
                "question": "In the last month, how often have you felt that you were unable to control the important things in your life?", 
                "answers": ["Never", "Almost never", "Sometimes", "Fairly often", "Very often"]
            },
            "question_15": {
                "question": "In the last month, how often have you felt confident about your ability to handle your personal problems?", 
                "answers": ["Never", "Almost never", "Sometimes", "Fairly often", "Very often"]
            },
        }
    }

    # Extracting conversation history from database 
    query = """
            SELECT user_id, role, message
            FROM chatmessages
            WHERE created_on >= timezone('UTC', now() - interval '1 day')::date
            AND created_on < timezone('UTC', now())::date
            order by created_on;
        """
    previous_chats = await chat_message_service.custom_query(query)
    user_responses = []
    for chat in previous_chats:
        if chat.role=="user":
            user_responses.append(chat.message.strip().lower())

    answered = analyze_survey_responses(user_responses, survey["questions"], threshold=0.4)
    total_answered = count_answered_questions(answered)

    print(f"Survey answered questions: {answered}")
    print(f"Total questions answered: {total_answered}")
