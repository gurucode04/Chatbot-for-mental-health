from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from utils.security.TokenVerifier import TokenVerifier
from typing import Annotated
from utils.admin.MailSender import MailSender
from config.settings import settings
from utils.admin.utils import encrypt_data, generate_key    
from db.session import get_db 
from sqlmodel import Session, select, Field
from db.schema.Company import Company
import traceback
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession as Session
from sqlalchemy.future import select
from sqlalchemy.orm import Session
import traceback
from typing import Annotated
from db.schema.Credit import Credit
from datetime import datetime, timezone
from typing import Optional
from typing import Literal
from db.schema.InviteHistory import InviteHistory

class InviteComapny(BaseModel):
    email: EmailStr
    role : Literal['company_admin',]

router = APIRouter()#dependencies=[Depends(verify_token_dependency)])

@router.post("/invite-company")
async def invite_company(company: InviteComapny, 
                         result: Annotated[dict, Depends(TokenVerifier().verify_super_admin)], 
                         db: Session = Depends(get_db)):
    try:
        user_detail, result = result

        mail_sender = MailSender()
        invite_data = {"email": company.email, "role": company.role}
        invitation_url = encrypt_data(str(invite_data), generate_key())

        invitation_url_for_signup = f"{settings.IP_ADDRESS}/auth/company/invite?email={company.email}&token={invitation_url}"

        html_content = mail_sender.html_mail_template.replace('<paragraph_text>', 'You can onboard via sign up.') \
                                                     .replace('<token_url>', invitation_url_for_signup) \
                                                     .replace('<button_text>', 'Signup Now')
        recipient = company.email
        subject = 'Invitation for Talk to Eve'
        mail_sender.send_mail(recipient, subject, html_content)

        # Add invitation detail to InviteHistory table
        invite_history = InviteHistory(
            email=company.email,
            role=company.role,
            invite_date=datetime.utcnow(),
            resend=False,
            invited_by=result.get('user_id'),
            status='unaccepted'
        )
        db.add(invite_history)
        await db.commit()
        await db.refresh(invite_history)

        final_response = {
            "status": True,
            "message": "Email sent successfully",
            "data": company
        }
        return final_response
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to send email. Error: {e}")

@router.get("/companies")
async def get_all_companies(
    result: Annotated[dict, Depends(TokenVerifier().verify_super_admin)],
    db: Session = Depends(get_db)
):
    try:
        statement = select(Company)
        companies = (await db.execute(statement)).scalars().all()
        final_data = {
            "status": True,
            "message": "Company information Fetched successfully",
            "data": companies
        }
        return final_data
    except Exception as e:
        print(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Failed to retrieve companies. Error: {e}")


class UpdateStatus(BaseModel):
    id : int
    status: Literal['rejected','active', 'inactive', 'suspended', 'deleted']

@router.put("/update-company-status")
async def update_company_status(
    status_update: UpdateStatus,
    result: Annotated[dict, Depends(TokenVerifier().verify_super_admin)],
    db: Session = Depends(get_db)
):
    try:
        user_detail, result = result

        statement = select(Company).where(Company.id == status_update.id)
        company = (await db.execute(statement)).scalars().first()

        if not company:
            raise HTTPException(status_code=404, detail="Company not found")

        company.status = status_update.status

        db.add(company)
        await db.commit()
        await db.refresh(company)

        return {
            "status": True,
            "message": "Company status updated successfully",
            "data": company
        }
    except Exception as e:
        print(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Failed to update company status. Error: {e}")
    
class CreditUpdate(BaseModel):
    id: int
    allocated_credits: int

@router.put("/update-credits")
async def update_credits(
    credit_update: CreditUpdate,
    result: Annotated[dict, Depends(TokenVerifier().verify_super_admin)],
    db: Session = Depends(get_db)
):
    try:
        user_detail, result = result
        company_id = credit_update.id
        allocated_credits = credit_update.allocated_credits

        statement = select(Credit).where(Credit.company_id == company_id)
        credit = (await db.execute(statement)).scalars().first()

        if credit:
            # Update existing record
            credit.allocated_credits = allocated_credits
        else:
            # company not found
            raise HTTPException(status_code=404, detail="Company not found")
        
        await db.commit()
        await db.refresh(credit)

        return {
            "status": True,
            "message": "Credits updated successfully",
            "data": credit
        }
    except Exception as e:
        print(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Failed to update credits. Error: {e}")



@router.get("/invite-history")
async def get_invite_history(result: Annotated[dict, Depends(TokenVerifier().verify_super_admin)], db: Session = Depends(get_db)):
    try:
        invite_history = await db.execute(select(InviteHistory))
        invite_history_data = invite_history.scalars().all()

        return {
            "status": True,
            "message": "Invite history fetched successfully",
            "data": invite_history_data
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch invite history. Error: {e}")
