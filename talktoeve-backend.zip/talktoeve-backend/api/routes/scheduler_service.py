# import asyncio
from db.session import AsyncSessionLocal
from api.routes.scheduler import scheduler
from api.routes.survey_analyser import survey_analyser

async def call_scheduler():
    try:
        # Create a database session manually
        # db = AsyncSessionLocal()
        print('Scheduler service called')
        await scheduler()
        print("Scheduler service ended")
    except Exception as e:
        print(f"An error occurred: {e}")

async def call_survey():
    try:
        # Create a database session manually
        # db = AsyncSessionLocal()
        print('Survey Analyser service called')
        await survey_analyser()
        print('Survey Analyser service ended')
    except Exception as e:
        print(f"An error occurred: {e}")
