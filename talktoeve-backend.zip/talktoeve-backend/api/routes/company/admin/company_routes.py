from db.schema.ChatMessages import ChatMessages
import os
from azure_endpoints.general_chat import GeneralChat
from config.constants.prompt_constants import system_prompt
from db.services.ChatMessageServiceProvider import ChatMessageServiceProvider
from fastapi import APIRouter, Depends, HTTPException, UploadFile, BackgroundTasks
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, Annotated, Literal, Union
from datetime import datetime
import traceback

from db.session import get_db, AsyncSessionLocal
from db.schema.Company import Company
from db.schema.InviteHistory import InviteHistory
from db.services.CompanyServiceProvider import CompanyServiceProvider
from db.services.InviteHistoryServiceProvider import InviteHistoryServiceProvider
from db.GenericAccessProvider import GenericAccessProvider
from utils.security.TokenVerifier import TokenVerifier
from utils.admin.MailSender import MailSender
from utils.admin.utils import encrypt_data, generate_key
from config.settings import settings
from modules.users_manager.user_manager import UserManager
from modules.speech_to_text.speech_to_text import S2T_with_openai


class UpdateCompanyInfo(BaseModel):
    company_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    street: Optional[str] = None
    city: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None
    registration_number: Optional[str] = None
    tax_identification_number: Optional[str] = None
    vat_number: Optional[str] = None
    industry_type: Optional[str] = None
    legal_form: Optional[str] = None
    incorporation_date: Optional[datetime] = None
    number_of_employees: Optional[int] = None
    annual_revenue: Optional[float] = None
    website_url: Optional[str] = None
    updated_on: Optional[datetime] = Field(
        default_factory=lambda: datetime.utcnow())


class InviteEmployee(BaseModel):
    email: EmailStr
    role: Literal['employee']


router = APIRouter()


@router.post("/update-company-info")
async def update_company_info(
    company_info: UpdateCompanyInfo,
    result: Annotated[dict, Depends(TokenVerifier().verify_company_admin)],
    db: Annotated[AsyncSessionLocal, Depends(get_db)]
):
    try:
        user_detail, result = result
        company_id = result.get("company_id")
        if not company_id:
            raise HTTPException(
                status_code=400, detail="Invalid token. Company ID not found.")

        company_access_provider = GenericAccessProvider(Company, db)
        company_service = CompanyServiceProvider(company_access_provider)

        company = await company_service.fetch_row_by_id(company_id)
        if not company:
            raise HTTPException(status_code=404, detail="Company not found")

        update_data = company_info.dict(exclude_unset=True)
        updated_company = await company_service.update_row(company_id, update_data, res=result)

        employee_info = employee_info.model_dump()
        employee_info['user_type'] = 'user'
        employee_info['username'] = user_detail.user_name
        user_manager = UserManager(sign_up=True)
        employee_info['edit'] = True

        user_manager.create_edit_user(employee_info)
        del user_manager

        return {
            "status": True,
            "message": "Company information updated successfully",
            "data": updated_company
        }
    except Exception as e:
        print(traceback.format_exc())
        raise HTTPException(
            status_code=500, detail=f"Failed to update company information. Error: {e}")


@router.get("/company-info")
async def get_company_info(
    result: Annotated[dict, Depends(TokenVerifier().verify_company_admin)],
    db: Annotated[AsyncSessionLocal, Depends(get_db)]
):
    try:
        user_detail, result = result
        company_id = result.get("company_id")
        if not company_id:
            raise HTTPException(
                status_code=400, detail="Invalid token. Company ID not found.")

        company_access_provider = GenericAccessProvider(Company, db)
        company_service = CompanyServiceProvider(company_access_provider)

        company = await company_service.fetch_row_by_id(company_id)
        if not company:
            raise HTTPException(status_code=404, detail="Company not found")
        elif company.status == "pending":
            raise HTTPException(
                status_code=403, detail="Company is not approved yet")
        elif company.is_deleted:
            raise HTTPException(status_code=403, detail="Company is deleted")

        final_data = {
            "status": True,
            "message": "Company information fetched successfully",
            "data": company
        }
        return final_data
    except Exception as e:
        print(traceback.format_exc())
        raise HTTPException(
            status_code=500, detail=f"Failed to retrieve company information. Error: {e}")


@router.post("/invite-emplyee")
async def invite_employee(
    company: InviteEmployee,
    result: Annotated[dict, Depends(TokenVerifier().verify_company_admin)],
    db: Annotated[AsyncSessionLocal, Depends(get_db)]
):
    try:
        user_detail, result = result
        company_id = result.get('company_id')

        mail_sender = MailSender()
        invite_data = {"email": company.email,
                       "role": company.role, "company_id": company_id}
        invitation_url = encrypt_data(str(invite_data), generate_key())

        invitation_url_for_signup = f"{settings.IP_ADDRESS}/auth/user/invite?email={company.email}&token={invitation_url}"

        html_content = mail_sender.html_mail_template.replace('<paragraph_text>', 'You can onboard via sign up.') \
                                                     .replace('<token_url>', invitation_url_for_signup) \
                                                     .replace('<button_text>', 'Signup Now')
        recipient = company.email
        subject = 'Invitation for Talk to Eve'
        mail_sender.send_mail(recipient, subject, html_content)

        invite_history_access_provider = GenericAccessProvider(
            InviteHistory, db)
        invite_history_service = InviteHistoryServiceProvider(
            invite_history_access_provider)

        invite_history_data = {
            "email": company.email,
            "role": company.role,
            "invite_date": datetime.utcnow(),
            "resend": False,
            "company_id": company_id,
            "invited_by": user_detail.id,
            "status": 'unaccepted'
        }

        invite_history = await invite_history_service.add_row(invite_history_data)

        return {
            "status": True,
            "message": "Email sent successfully",
            "data": invite_history
        }
    except Exception as e:
        traceback.print_exc()
        await db.rollback()
        raise HTTPException(
            status_code=500, detail=f"Failed to send email. Error: {e}")


@router.get("/company-invite-history")
async def get_company_invite_history(
    result: Annotated[dict, Depends(TokenVerifier().verify_company_admin)],
    db: Annotated[AsyncSessionLocal, Depends(get_db)]
):
    try:
        user_detail, result = result
        company_id = result.get("company_id")
        if not company_id:
            raise HTTPException(
                status_code=400, detail="Company ID not provided.")

        invite_history_access_provider = GenericAccessProvider(
            InviteHistory, db)
        invite_history_service = InviteHistoryServiceProvider(
            invite_history_access_provider)

        invite_history_data = await invite_history_service.filter_rows({"company_id": company_id})

        return {
            "status": True,
            "message": "Invite history for Company fetched successfully",
            "data": invite_history_data
        }
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch invite history. Error: {e}")


from keywords.keywords import  keywords_from_embeddings_similarities
from modules.analysis.analysis import *
from db.schema.Nodes import Nodes
from db.services.NodesServiceProvider import NodesServiceProvider


async def mindmap_edit_background(
    session: str,
    user_detail,
    db: Annotated[AsyncSessionLocal, Depends(get_db)]
):
    try:
        # Initialize Access Providers and Service Providers
        chat_messages_access_provider = GenericAccessProvider(ChatMessages, db)
        chat_message_service = ChatMessageServiceProvider(chat_messages_access_provider)
        
        nodes_access_provider = GenericAccessProvider(Nodes, db)
        nodes_service = NodesServiceProvider(nodes_access_provider)
        
        query = f"""
            SELECT *
            FROM chatmessages c
            WHERE user_id = {user_detail.id}
            AND session_id = {session} ::character varying
            ORDER BY created_on ASC;
        """
        previous_chats = await chat_message_service.custom_query(query)

        if not previous_chats: 
            query = f"""
                SELECT *
                FROM chatmessages c
                WHERE user_id = {user_detail.id}
                AND created_on >= timezone('UTC', now())::date
                AND created_on < timezone('UTC', now() + interval '1 day')::date
                ORDER BY created_on ASC;
            """
            previous_chats = await chat_message_service.custom_query(query)
        
        user_messages = []
        for chat in previous_chats:
            if chat.role == "user":
                user_messages.append(chat.message)

        
        # chat_messages = {'message_id': [], 'role': [], 'message': []}
        # for chat in previous_chats:
        #     chat_messages['message_id'].append(str(index))
        #     chat_messages['role'].append(chat.role)
        #     chat_messages['message'].append(chat.message)
        #     index += 1
        # if len(user_messages) > 0:
        #     stress_score = stress_probas(user_messages)
        #     depression_score = depression_probas(user_messages)

        keyphrases_df = keywords_from_embeddings_similarities(user_messages)
        keyphrases_df['session_id'] = session
        keyphrases_df.columns = ['message_id','node', 'parent_node', 'session_id']
        keyphrases_df.drop_duplicates(subset=['message_id', 'node', 'parent_node'], inplace=True)
        keyphrases_df.reset_index(drop=True, inplace=True)

        nodes = keyphrases_df['node'].tolist()
        parent_nodes = keyphrases_df['parent_node'].tolist()
        unique_nodes = set(nodes+parent_nodes)

        # Get the Main node of the user mindmap.
        YOU = await nodes_service.filter_rows( filters= {
                "user_id": user_detail.id,
                "company_id": user_detail.company_id,
                "node_name": "YOU",
            })
        YOU = YOU[0]        # [0] Because filter_rows returns a list.
        default_parent = YOU.id
        default_childs = set()
        if YOU.child_node_ids:
            default_childs = set(YOU.child_node_ids)
        for node_name in list(unique_nodes):
            description = ""
            prev_data = await nodes_service.filter_rows( filters= {
                "user_id": user_detail.id,
                "company_id": user_detail.company_id,
                "node_name": node_name,
            })
            if prev_data:
                description = prev_data[0].description + description
                await nodes_service.update_row(prev_data[0].id, {
                        "session_id": session,
                        "description":description
                    })
            else:
                node_data = {
                    "user_id": user_detail.id,
                    "company_id": user_detail.company_id,
                    "session_id": session,
                    "parent_node_id": default_parent,
                    "node_name": node_name,
                    "description": description
                }
                await nodes_service.add_row(node_data)
                node = await nodes_service.filter_rows( filters= {
                    "user_id": user_detail.id,
                    "company_id": user_detail.company_id,
                    "node_name": node_name,
                })
                default_childs.add(node[0].id)
        
        await nodes_service.update_row(YOU.id, {
                "child_node_ids": default_childs,
            })

        for node_name, parent_node_name in zip(nodes, parent_nodes):
            parent_node = await nodes_service.filter_rows( filters= {
                "user_id": user_detail.id,
                "company_id": user_detail.company_id,
                "node_name": parent_node_name,
            })
            node = await nodes_service.filter_rows( filters= {
                "user_id": user_detail.id,
                "company_id": user_detail.company_id,
                "node_name": node_name,
            })
            if node and parent_node:
                if parent_node[0].child_node_ids:
                    childs = [x for x in parent_node[0].child_node_ids if x != node[0].id]
                    childs = set(childs)
                else:
                    childs = set()
                await nodes_service.update_row(node[0].id, {
                        "parent_node_id": parent_node[0].id,
                        "sibling_node_ids":childs
                    })
                if childs:
                    childs.add(node[0].id)
                else:
                    childs = {node[0].id}
                await nodes_service.update_row(parent_node[0].id, {
                        "child_node_ids": childs,
                    })
                default_childs.remove(node[0].id)

        await nodes_service.update_row(YOU.id, {
                "child_node_ids": default_childs,
            })

    except Exception as e:
        print(f"Error occurred in finalizing in background: {e}")
        raise HTTPException(status_code=500, detail="Internal server error.")

# Data models for request and response
class ChatRequest(BaseModel):
    session_id: str
    message: Optional[str]
    audio_file: Optional[bytes] = None
    audio_response_flag: bool = False

    class Config:
        arbitrary_types_allowed = True

class ChatResponse(BaseModel):
    role: str
    content: str

s2t = S2T_with_openai()

@router.post("/chat", response_model=ChatResponse)
async def chat(
    chat_request: ChatRequest,
    result: Annotated[dict, Depends(TokenVerifier().verify_employee)],
    db: Annotated[AsyncSessionLocal, Depends(get_db)],
    background_tasks: BackgroundTasks
):
    if chat_request.message is None and chat_request.audio_file is None:
        raise HTTPException(status_code=400, detail="Message is empty")
    try:
        if chat_request.audio_response_flag:
            if chat_request.audio_file:
                chat_request.message = s2t.transcribe(chat_request.audio_file)
        user_detail, result = result
        # Initialize Access Providers and Service Providers
        chat_messages_access_provider = GenericAccessProvider(ChatMessages, db)
        chat_message_service = ChatMessageServiceProvider(chat_messages_access_provider)

        # query = f"""
        #     SELECT *
        #     FROM chatmessages c
        #     WHERE user_id = {user_detail.id}
        #     AND created_on >= timezone('UTC', now())::date
        #     AND created_on < timezone('UTC', now() + interval '1 day')::date
        #     ORDER BY created_on ASC;
        # """


        # This query will retrieve the chat history from previous 2 sessions. [ LIMIT 2 ]
        query = f"""
            WITH latest_session_times AS (
                SELECT session_id, MAX(created_on) as latest_time
                FROM chatmessages
                WHERE user_id = {user_detail.id}
                GROUP BY session_id
            ),
            recent_sessions AS (
                SELECT session_id
                FROM latest_session_times
                ORDER BY latest_time DESC
                LIMIT 2
            )
            SELECT c.*
            FROM chatmessages c
            JOIN recent_sessions rs ON c.session_id = rs.session_id
            ORDER BY c.created_on ASC;
        """

        previous_chats = await chat_message_service.custom_query(query)

        query = f"""
            SELECT *
            FROM ChatSessionSummaries
            where user_id = {user_detail.id}
            ORDER BY created_on DESC
            LIMIT 1;
            """
        previous_summary = await chat_message_service.custom_query(query)

        chat_history = []
        # Add previous chat history if it exists
        messages = {}
        for chat in previous_chats:
            role = chat.role
            message = chat.message
            
            if role == "user":
                messages["inputs"] = {"question": message}
            elif role == "assistant":
                messages["outputs"] = {"answer": message}
                chat_history.append(messages)
                messages = {}

        # Initialize Azure AI client
        azure_chat = GeneralChat()

        # Get the response from AI
        if previous_summary:
            response = azure_chat.ask_question(question=chat_request.message, chat_history=chat_history, summary=previous_summary.summary)
        else:
            response = azure_chat.ask_question(question=chat_request.message, chat_history=chat_history)
        
        print(response)
        
        if response.get("answer"):
            # Save the user's message to the database
            user_message_data = {
                "user_id": user_detail.id,
                # Assuming company_id is optional, set it if necessary
                "company_id": user_detail.company_id,
                "session_id": chat_request.session_id,
                "role": "user",
                "message": chat_request.message
            }
            await chat_message_service.add_row(user_message_data)

            # Save the AI's response to the database
            assistant_message_data = {
                "user_id": user_detail.id,
                # Assuming company_id is optional, set it if necessary
                "company_id": user_detail.company_id,
                "session_id": chat_request.session_id,
                "role": "assistant",
                "message": response.get("answer")
            }
            await chat_message_service.add_row(assistant_message_data)

        # Add the task of editing mindmap to the background
        background_tasks.add_task(mindmap_edit_background, chat_request.session_id, user_detail, db)

        # Return the AI's response
        return ChatResponse(role="assistant", content=response.get("answer"))

    except Exception as e:
        print(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal server error.")
