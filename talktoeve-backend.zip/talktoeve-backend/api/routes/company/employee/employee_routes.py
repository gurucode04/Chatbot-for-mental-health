from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession as Session
from sqlalchemy.future import select
from typing import Annotated
from db.schema.Employee import Employee
from utils.security.TokenVerifier import TokenVerifier
import traceback
from typing import Optional
from datetime import datetime
from db.session import get_db 
from db.schema.Employee import UpdateEmployeeInfo
from modules.users_manager.user_manager import UserManager

router = APIRouter()

@router.post("/update-employee-info")
async def update_employee_info(
    employee_info: UpdateEmployeeInfo,
    result: Annotated[dict, Depends(TokenVerifier().verify_employee)],
    db: Session = Depends(get_db)
):
    try:
        user_detail, result = result
        
        statement = select(Employee).where(Employee.user_id == user_detail.id)
        employee = (await db.execute(statement)).scalars().first()

        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")

        update_data = employee_info.dict(exclude_unset=True)
        for key, value in update_data.items():
            if value is not None:
                setattr(employee, key, value)

        db.add(employee)
        await db.commit()
        await db.refresh(employee)

        employee_info = employee_info.model_dump()
        employee_info['user_type'] = 'user'
        employee_info['username'] = user_detail.user_name
        user_manager = UserManager(sign_up=True)
        employee_info['edit'] = True

        user_manager.create_edit_user(employee_info)
        del user_manager

        return {
            "status": True,
            "message": "Employee information updated successfully",
            "data": employee
        }
    except Exception as e:
        print(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Failed to update employee information. Error: {e}")
