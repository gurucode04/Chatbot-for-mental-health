import datetime
from db.schema.ChatSessionSummaries import ChatSessionSummaries
import os
from openai_service.openaiclient import OpenAIClient
# from config.constants.prompt_constants import system_prompt
# from db.services.ChatMessageServiceProvider import ChatMessageServiceProvider
from fastapi import APIRouter, Depends, HTTPException
# from pydantic import BaseModel, EmailStr, Field
from typing import Annotated  # , Optional,  Literal
import traceback

from db.session import get_db, AsyncSessionLocal
# from db.schema.Company import Company
# from db.schema.InviteHistory import InviteHistory
from db.services.ChatSessionSummariesServiceProvider import ChatSessionSummariesServiceProvider
# from db.services.InviteHistoryServiceProvider import InviteHistoryServiceProvider
from db.GenericAccessProvider import GenericAccessProvider
# from utils.security.TokenVerifier import TokenVerifier
# from utils.admin.MailSender import MailSender
# from utils.admin.utils import encrypt_data, generate_key
# from config.settings import settings
# from modules.users_manager.user_manager import UserManager
from config.constants.prompt_constants import summary_system_prompt
# import requests


# def call_scheduler():
#     url = "https://127.0.0.1:8000/scheduler"

#     try:
#         # Sending the list as JSON payload
#         response = requests.get(url, verify=False)
#     except requests.exceptions.RequestException as e:
#         print(f"An error occurred: {e}")

# import asyncio

# from api.routes.scheduler import scheduler

# def call_scheduler():
#     try:
#         # Create a database session manually
#         db = AsyncSessionLocal()

#         # Since `scheduler` is an async function, we need to run it in an event loop
#         asyncio.run(scheduler(db=db))
#     except Exception as e:
#         print(f"An error occurred: {e}")


def transform_messages(messages):
    result = {}
    for message in messages:
        user_id = f"{message[7]}-{message[8]}"
        if user_id not in result:
            result[user_id] = ""
        result[user_id] += f"{message[10]}-{message[11]}\n"
    return result


# router = APIRouter()


# @router.get("/scheduler")
# async def scheduler(
#     db: Annotated[AsyncSessionLocal, Depends(get_db)]
# ):
#     try:
#         chat_session_summaries_access_provider = GenericAccessProvider(
#             ChatSessionSummaries, db)
#         chat_session_summaries_service_provider = ChatSessionSummariesServiceProvider(
#             chat_session_summaries_access_provider)
#         query = """
#             SELECT *
#             FROM chatmessages
#             WHERE created_on >= timezone('UTC', now() - interval '1 day')::date
#             AND created_on < timezone('UTC', now())::date
#             order by created_on ;
#         """
#         messages = await chat_session_summaries_service_provider.custom_query(query)
#         user_chats: dict = transform_messages(
#             messages)  # user id(int) : messages(str)
#         print(user_chats)
#         for user_id_comapany_id, user_messages in user_chats.items():
#             user_id, company_id = user_id_comapany_id.split('-')
#             client = OpenAIClient(api_key=os.getenv(
#                 "OPENAI_API_KEY"), model="gpt-4o")
#             messages = [
#                 {"role": "system", "content": summary_system_prompt.replace(
#                     '{conversation}', user_messages)}
#             ]
#             response = client.get_response(messages)
#             summary = response.get('content')
#             data = {
#                 'user_id': int(user_id),
#                 'company_id': int(company_id),
#                 'summary': summary,
#                 'created_on': datetime.datetime.utcnow() - datetime.timedelta(days=1),
#                 'created_by': int(user_id)
#             }
#             instance = await chat_session_summaries_service_provider.add_row(data)
#             print(instance)

#         return None
#     except Exception as e:
#         print(traceback.format_exc())
#         raise HTTPException(
#             status_code=500, detail=f"Failed to retrieve company information. Error: {e}")

# from fastapi import APIRouter, Depends
# from db.session import get_db

router = APIRouter()


@router.get("/scheduler")
async def scheduler():
    try:
        db=get_db()
        chat_session_summaries_access_provider = GenericAccessProvider(
            ChatSessionSummaries, db)
        chat_session_summaries_service_provider = ChatSessionSummariesServiceProvider(
            chat_session_summaries_access_provider)

        query = """
            SELECT *
            FROM chatmessages
            WHERE created_on >= timezone('UTC', now() - interval '1 day')::date
            AND created_on < timezone('UTC', now())::date
            order by created_on;
        """
        messages = await chat_session_summaries_service_provider.custom_query(query)
        user_chats: dict = transform_messages(messages)

        query = """
            SELECT DISTINCT user_id
            FROM chatsessionsummaries;
        """
        user_ids = await chat_session_summaries_service_provider.custom_query(query)
        user_ids = [item[0] for item in user_ids]

        for user_id_comapany_id, user_messages in user_chats.items():
            print(f'user_id_comapany_id: {user_id_comapany_id}')
            user_id, company_id = user_id_comapany_id.split('-')
            user_id, company_id = int(user_id), int(company_id)
            if user_id not in user_ids:
                user_data_query = f"""
                    SELECT company_id
                    FROM user
                    WHERE id = {user_id};
                """
                user_data = await chat_session_summaries_service_provider.custom_query(user_data_query)
                if user_data:
                    company_id = user_data[0][0]
                    summary = f"Main topic of the conversation:\nMain topic of the latest conversation:\nInformation provided by the patient:\nFeelings expressed by the patient:\nRequests expressed by the patient:\nRecommendations provided by the assistant:\nGoals provided by the assistant:\nSuicidal thoughts (YES/NO):\nStatic Memory(very short):"
                    data = {
                        'user_id': int(user_id),
                        'company_id': int(company_id),
                        'summary': summary,
                        'created_on': datetime.datetime.utcnow() - datetime.timedelta(days=1),
                        'created_by': int(user_id)
                    }
                    instance = await chat_session_summaries_service_provider.add_row(data)
                    print(instance)
            client = OpenAIClient(api_key=os.getenv(
                "OPENAI_API_KEY"), model="gpt-4o")
            previous_summary = " "
            previous_summary_query = f"""
                SELECT *
                FROM chatsessionsummaries
                WHERE user_id = {user_id}
                AND company_id = {company_id}
                ORDER BY created_on DESC
                LIMIT 1;"""
            previous_summary_data = await chat_session_summaries_service_provider.custom_query(previous_summary_query)
            if previous_summary_data:
                previous_summary = previous_summary_data[0][-1]

            messages = [
                {"role": "system", "content": summary_system_prompt.replace(
                    '{conversation}', user_messages).replace('{summary}', previous_summary)}
            ]

            response = client.get_response(messages)
            summary = response.get('content')

            data = {
                'user_id': int(user_id),
                'company_id': int(company_id),
                'summary': summary,
                'created_on': datetime.datetime.utcnow() - datetime.timedelta(days=1),
                'created_by': int(user_id)
            }

            instance = await chat_session_summaries_service_provider.add_row(data)
            print(instance)

        return {"status": "scheduler executed"}
    except Exception as e:
        print(traceback.format_exc())
        raise HTTPException(
            status_code=500, detail=f"Failed to retrieve company information. Error: {e}"
        )
