from fastapi import APIRouter, HTTPException, Depends
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.exc import SQLAlchemyError
from db.session import get_db
from db.schema.User import User
from db.schema.Company import Company
from db.schema.Nodes import Nodes
from utils.login.PasswordGenerator import PasswordGenerator
from utils.logger import setup_logger
from sqlalchemy.future import select
from utils.login.LoginSignupResponseGenerator import LoginSignupResponseGenerator
from models.LoginRequest import LoginRequest
from models.SignupRequest import SignupRequest
from utils.admin.utils import decrypt_token, generate_key
import json
from db.schema.Credit import Credit
from db.schema.InviteHistory import InviteHistory 
from datetime import datetime
from db.schema.Employee import Employee
from modules.users_manager.user_manager import UserManager
from traceback import print_exc
from modules.EveInitializer import user_eve_instances, EveInitializer
import traceback

logger = setup_logger()

router = APIRouter()

@router.post("/company-signup")
async def signup(signup_request: SignupRequest, db: AsyncSession = Depends(get_db)):
    try:
        existing_user = await db.execute(select(User).where(User.email == signup_request.email))
        if existing_user.scalar():
            return {
                "status": False,
                "message": "User already exists"
            }

        # check if user_name already exists
        existing_user = await db.execute(select(User).where(User.user_name == signup_request.user_name))
        if existing_user.scalar():
            return {
                "status": False,
                "message": "User name already exists. Please choose a different user name."
            }
        
        decrypted_data = decrypt_token(signup_request.token.replace('b\'',"").replace("\'",""), generate_key()).replace("'","\"")#.replace("b'", "").replace("'", ""))
        print("Decrypted Data:", decrypted_data)  # Check what the decrypted data looks like
        data = json.loads(decrypted_data)
        email = data.get("email")
        role=data.get("role")

        if email != signup_request.email:
            raise HTTPException(status_code=400, detail="Invalid email. invitation Email and signup email does not match.")

        if role not in ["company_admin", "super_admin"]:
            raise HTTPException(status_code=400, detail="Invalid role. Role should be either company_admin or super_admin.")

        company = Company(company_name="",email=signup_request.email,phone="",street="",city="",postal_code="",country="",number_of_employees=0)    
        db.add(company)
        await db.commit()
        await db.refresh(company)

        # add credits to the company
        credits = Credit(company_id=company.id, allocated_credits=0,used_credits=0,assigned_date=datetime.utcnow())
        db.add(credits)
        await db.commit()
        await db.refresh(credits)

        # Update status to 'accepted' in InviteHistory
        invite_history = await db.execute(select(InviteHistory).where(InviteHistory.company_id == company.id, InviteHistory.email == email))
        invite_instance = invite_history.scalar()
        if invite_instance:
            invite_instance.status = 'accepted'
            invite_instance.company_id = company.id
            await db.commit()
            await db.refresh(invite_instance)


        print(f"Company ID is: {company.id}")
        print(f"cridits are : {credits.allocated_credits}")

        password_generator = PasswordGenerator()
        encrypted_password = password_generator.encrypt(signup_request.password)
        
        user = User(user_name=signup_request.user_name, email=signup_request.email, password=encrypted_password,role=role,company_id=company.id)
        db.add(user)
        await db.commit()
        await db.refresh(user)
        
        tokens = await LoginSignupResponseGenerator.get_tokens(user.id, company.id, role)
        
        payload = {}
        payload["user_id"] = user.id
        payload['username'] = user.user_name
        payload["name"] = user.user_name
        payload["email"] = user.email
        user_manager = UserManager(sign_up=True)

        #add the user
        payload['edit'] = False
        payload['user_type'] = 'user'
        user_manager.create_edit_user(payload)
        del user_manager

        return {
            "status": "success",
            "message": "User created successfully",
            "data": {
                "user_id": user.id,
                "user_name": user.user_name,
                "email": user.email,
                "company_id": company.id,
                "access_token": tokens["access_token"],
                "refresh_token": tokens["refresh_token"]
            }
        }
    except SQLAlchemyError as e:
        logger.error(f"SQLAlchemyError in signup: {e}")
        await db.rollback()
        return {
            "status": False,
            "message": f"Database error: {str(e)}"
        }
    except Exception as e:
        logger.error(f"Exception in signup: {e}")
        await db.rollback()
        return {
            "status": False,
            "message": f"An unexpected error occurred: {str(e)}"
        }
    

@router.post("/employee-signup")
async def signup(signup_request: SignupRequest, db: AsyncSession = Depends(get_db)):
    try:
        # Check if user already exists
        existing_user = await db.execute(select(User).where(User.email == signup_request.email))
        if existing_user.scalar():
            return {
                "status": False,
                "message": "User already exists"
            }
        
        # check if user_name already exists
        existing_user = await db.execute(select(User).where(User.user_name == signup_request.user_name))
        if existing_user.scalar():
            return {
                "status": False,
                "message": "User name already exists. Please choose a different user name."
            }
        
        # Decrypt token and extract data
        decrypted_data = decrypt_token(signup_request.token.replace('b\'',"").replace("\'",""), generate_key()).replace("'", "\"")
        print("Decrypted Data:", decrypted_data)  # Check what the decrypted data looks like
        data = json.loads(decrypted_data)
        email = data.get("email")
        role = data.get("role")
        company_id = data.get("company_id")

        if email != signup_request.email:
            raise HTTPException(status_code=400, detail="Invalid email. Invitation email and signup email do not match.")

        if role not in ["employee", "company_admin", "super_admin"]:
            raise HTTPException(status_code=400, detail="Invalid role. Role should be either user, company_admin or super_admin.")

        # Update used_credits for the company in the Credit table
        credit = await db.execute(select(Credit).where(Credit.company_id == company_id))
        credit_instance = credit.scalar()
        if credit_instance:
            credit_instance.used_credits += 1
            if credit_instance.used_credits >= credit_instance.allocated_credits:
                raise ValueError("Credits are exhausted. Please contact the admin.")
            db.add(credit_instance)
        
        # Update status to 'accepted' in InviteHistory
        invite_history = await db.execute(select(InviteHistory).where(InviteHistory.company_id == company_id, InviteHistory.email == email))
        invite_instance = invite_history.scalar()
        if invite_instance:
            invite_instance.status = 'accepted'
            invite_instance.company_id = company_id
            await db.commit()
            await db.refresh(invite_instance)
        
        # Encrypt the password
        password_generator = PasswordGenerator()
        encrypted_password = password_generator.encrypt(signup_request.password)
        
        # Create the user
        user = User(user_name=signup_request.user_name, email=signup_request.email, password=encrypted_password, role=role, company_id=company_id)
        db.add(user)
        await db.commit()
        await db.refresh(user)

        # add it to emaployee table
        employee = Employee(user_id=user.id, first_name=signup_request.user_name,last_name="", email=signup_request.email, company_id=company_id)
        db.add(employee)
        await db.commit()
        await db.refresh(employee)

        node = Nodes(user_id=user.id, company_id=company_id, session_id = "0", node_name = "YOU", description = "It's all about you!", child_node_ids = {})
        db.add(node)
        await db.commit()
        await db.refresh(node)

        # Generate tokens
        tokens = await LoginSignupResponseGenerator.get_tokens(user.id, company_id, role)
        
        payload = {}
        payload["user_id"] = user.id
        payload['username'] = user.user_name
        payload["name"] = user.user_name
        payload["email"] = user.email
        user_manager = UserManager(sign_up=True)

        #add the user
        payload['edit'] = False
        payload['user_type'] = 'user'
        user_manager.create_edit_user(payload)
        del user_manager

        return {
            "status": "success",
            "message": "User created successfully",
            "data": {
                "user_id": user.id,
                "user_name": user.user_name,
                "email": user.email,
                "company_id": company_id,
                "access_token": tokens["access_token"],
                "refresh_token": tokens["refresh_token"]
            }
        }
    except SQLAlchemyError as e:
        print_exc()
        logger.error(f"SQLAlchemyError in signup: {e}")
        await db.rollback()
        return {
            "status": False,
            "message": f"Database error: {str(e)}"
        }
    except Exception as e:
        print_exc()
        logger.error(f"Exception in signup: {e}")
        await db.rollback()
        return {
            "status": False,
            "message": f"An unexpected error occurred: {str(e)}"
        }

@router.post("/login")
async def login(login_request: LoginRequest, db: AsyncSession = Depends(get_db)):
    try:
        password_generator = PasswordGenerator()
        
        result = await db.execute(select(User).where(User.email == login_request.email))
        user = result.scalar()
        print(f"User information : {user}")
        logger.info(f"User information : {user}")

        if not user or not password_generator.verify(login_request.password, user.password):
            return {
                "status": False,
                "message": "Invalid email or password"
            }

        result = await db.execute(select(Company).where(Company.id == user.company_id))
        company = result.scalar()
        if not company:
            return {
                "status": False,
                "message": "Company not found"
            }
        print(f"Company information is : {company}")
        logger.info(f"Company information is : {company}")
        
        tokens = await LoginSignupResponseGenerator.get_tokens(user.id, company.id, user.role)

        if user.role != "super_admin":
            success = EveInitializer.initialize_eve_instance(user.user_name, login_request.model_name)

        # if payload.username in user_conversations:
        #     response_generator_object = user_conversations[payload.username]
        # else:
        #     user_conversations[payload.username] = ResponseGenerator()
        final_result = {
                            "status": "success",
                            "message": "Login successful and user initialized successfully.",
                            "data": {
                                "user_id": user.id,
                                "user_name": user.user_name,
                                "email": user.email,
                                "company_id": company.id,
                                "access_token": tokens["access_token"],
                                "refresh_token": tokens["refresh_token"],
                                "model_name": login_request.model_name if login_request.model_name else "default"
                            }
                        }
        logger.info(f"user id : {user.id} user_name : {user.user_name} logged in successfully.")
        return final_result
    except SQLAlchemyError as e:
        traceback.print_exc()
        logger.error(f"SQLAlchemyError in login: {e}")
        return {
            "status": False,
            "message": f"Database error: {str(e)}"
        }
    except Exception as e:
        traceback.print_exc()
        logger.error(f"Exception in login: {e}")
        return {
            "status": False,
            "message": f"An unexpected error occurred: {str(e)}"
        }
