from starlette.config import Config

try:
    print("Trying to read .env file....")
    config = Config(".env")
    print("File found....")
except Exception as e:
    print(e)
    print("File not found....")
    config = Config()