HTML_MAIL_TEMPLATE = """
<div class="container" style="margin: auto; width: 50%; padding: 20px 0;">
    <div class="header" style="border-bottom: 1px solid #eee;">
        <a href="#" style="font-size: 1.4em; color: #2fa77c; text-decoration: none; font-weight: 600;">Talk To Eve</a>
    </div>
    <div class="content" style="font-size: 1.1em;">
        <p>Hi,</p>
        <p><paragraph_text></p>
        <div style="text-align: center;">
            <a href="<token_url>" target="_blank" style="background: #2fa77c; color: #FFFFFF; padding: 10px 20px; text-decoration: none; border-radius: 3px; display: inline-block;">
                    <button_text>
                </a>
        </div>
        <p class="footer" style="font-size: 0.9em;">Regards,<br />Talk To Eve</p>
        <hr style="border: none; border-top: 1px solid #eee;" />
        <div class="address" style="float: right; padding: 8px 0; color: #aaa; font-size: 0.8em; line-height: 1; font-weight: 300;">
            <p>Talk To Eve</p>
            <p>Universitetsgata 2, Oslo, <br />0164,</p>
            <p>Norway</p>
        </div>
    </div>
</div>
"""

