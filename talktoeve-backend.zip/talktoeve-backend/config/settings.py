from pydantic_settings import BaseSettings
from starlette.datastructures import Secret
from config.config import config
import json

class Settings(BaseSettings):
    try:
        _ENV = config("TALK_TO_EVE_ENV")
        _DATABASE_CONFIG = json.loads(config("DATABASE_CONFIG")) 
        _IP_CONFIG = json.loads(config("IP_CONFIG"))
        _EMAIL_ADDRESS: str = config("EMAIL_ADDRESS")
        _EMAIL_PASSWORD = config("EMAIL_PASSWORD", cast=Secret)
        _DATABASE_URL:str = str(_DATABASE_CONFIG[_ENV]).replace("postgresql://", "postgresql+asyncpg://").replace('?sslmode=require', '')
        
        DATABASE_URL: Secret = Secret(_DATABASE_URL)
        EMAIL_ADDRESS: str = _EMAIL_ADDRESS
        EMAIL_PASSWORD: str = str(_EMAIL_PASSWORD)
        IP_ADDRESS: str = _IP_CONFIG[_ENV]
        connect_args:json = {"ssl": True} if _ENV == "dev" or _ENV == "prod"  else {}
        
        print(f"ENV: {_ENV}")
        print(f"DATABASE_URL: {DATABASE_URL}")
    
    except Exception as e:
        raise ValueError(f"Invalid Environment. Please set ENV to local or dev. Exception: {e}")

settings = Settings()

# Determine if SSL should be used based on the environment
