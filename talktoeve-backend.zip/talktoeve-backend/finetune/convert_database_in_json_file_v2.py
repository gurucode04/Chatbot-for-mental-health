import re
import json
import random
from configurations import EVE_PROMPT_SYSTEM_FOR_FINE_TUNNING
import os 
import sys

# Add path to sys
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

# read EVE_PROMPT_SYSTEM_FOR_FINE_TUNNING file
with open(EVE_PROMPT_SYSTEM_FOR_FINE_TUNNING, "r") as archivo:
    PROMPT_PSYCOLOGIST = archivo.read()

# Lista de archivos en el directorio actual
conversations_path = os.path.join(os.getcwd(),"documents","conversations_examples","data_augmentation","conversations")

file_dict = {}
# Agrupar archivos por categoría (eliminar el número al final para comparar nombres)ee
for file_name in os.listdir(conversations_path):
    base_name = file_name[:-5] # Eliminar el número al final
    if base_name not in file_dict:
        file_dict[base_name] = []
    file_dict[base_name].append(file_name)

# Listas para nombres de archivos de entrenamiento y validación
train_files_list = []
val_files_list = []

# Dividir archivos y obtener nombres para entrenamiento y validación
for category, files in file_dict.items():
    # Obtener archivos para entrenamiento y validación
    num_files = len(files)
    num_train = int(0.7 * num_files)
    train_files = random.sample(files, num_train)
    val_files = [file for file in files if file not in train_files]

    # Almacenar nombres de archivos para entrenamiento y validación
    train_files_list.extend(train_files)
    val_files_list.extend(val_files)

# Imprimir nombres de archivos para entrenamiento y validación
print("Archivos de entrenamiento:")
for file_name in train_files_list:
    print(file_name)

print("\nArchivos de validación:")
for file_name in val_files_list:
    print(file_name)
    

# Ahora tenemos que crear los archivos .jsonl con el contenido de los archivos de texto
path_to_save = os.path.join(os.getcwd(),"documents","conversations_examples","data_augmentation")
file_path = os.path.join(path_to_save, "conversations_train.jsonl")

# Check if the directory exists or not, create it if it doesn't
if not os.path.exists(path_to_save):
    os.makedirs(path_to_save)

# Train
with open(file_path, "w") as jsonl_file:
    it = 0
    # Leemos los archivos de texto de entrenamiento
    examples_train = []
    for file_name in train_files_list:
        with open(os.path.join(conversations_path, file_name), "r") as file:
            file_content = file.read()
            
        lines = file_content.strip().split('\n')
        
        messages = []
        messages.append({"role": "system", "content": PROMPT_PSYCOLOGIST})
        for index in range(len(lines)):
            line = lines[index]
            # Here we need to check if the message is from the user or from the assistant
            if 'Therapist:' in line:
                line = line.replace("Therapist: ","")
                messages.append({"role": "assistant", "content": line})
            elif 'Sailor:' in line:
                line = line.replace("Sailor: ","")
                messages.append({"role": "user", "content": line})
            else:
                print("Error: no se ha encontrado el rol del mensaje")
                
        # Escribe el objeto JSON en una línea del archivo JSONL
        json_str = json.dumps({"messages": messages}, separators=(',', ':'))
        jsonl_file.write(json_str + '\n')
        it+=1
        
# Ahora tenemos que crear los archivos .jsonl con el contenido de los archivos de texto
file_path = os.path.join(path_to_save, "conversations_val.jsonl")

# Check if the directory exists or not, create it if it doesn't
if not os.path.exists(path_to_save):
    os.makedirs(path_to_save)

# Validation
with open(file_path, "w") as jsonl_file:
    it = 0
    # Leemos los archivos de texto de entrenamiento
    examples_val = []
    for file_name in val_files_list:
        with open(os.path.join(conversations_path, file_name), "r") as file:
            file_content = file.read()
            
        lines = file_content.strip().split('\n')
        
        messages = []
        messages.append({"role": "system", "content": PROMPT_PSYCOLOGIST})
        for index in range(len(lines)):
            line = lines[index]
            # Here we need to check if the message is from the user or from the assistant
            if 'Therapist:' in line:
                line = line.replace("Therapist: ","")
                messages.append({"role": "assistant", "content": line})
            elif 'Sailor:' in line:
                line = line.replace("Sailor: ","")
                messages.append({"role": "user", "content": line})
            else:
                print("Error: no se ha encontrado el rol del mensaje")
                
        # Escribe el objeto JSON en una línea del archivo JSONL
        json_str = json.dumps({"messages": messages}, separators=(',', ':'))
        jsonl_file.write(json_str + '\n')
        it+=1



