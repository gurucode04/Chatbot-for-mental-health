import os
from openai import OpenAI
from configurations import OPENAI_API_KEY

client = OpenAI(api_key=OPENAI_API_KEY)

train_path = os.path.join(os.getcwd(),"documents","conversations_examples","data_augmentation","conversations_train.jsonl")
train_file = client.files.create(
                                file = open(train_path, "rb"),
                                purpose='fine-tune'
                                )
val_path = os.path.join(os.getcwd(),"documents","conversations_examples","data_augmentation","conversations_val.jsonl")
val_file = client.files.create(
                                file = open(val_path, "rb"),
                                purpose='fine-tune'
                                )


# Finetune the model
hyperparameters = {"n_epochs": 20}
model = "ft:gpt-3.5-turbo-0613:eve:eve-v1:88FhyNRo" #"gpt-3.5-turbo"

client.fine_tuning.jobs.create(
  training_file=train_file.id, 
  validation_file= val_file.id,
  model=model,
  hyperparameters=hyperparameters,
  suffix="eve_sailor_v1"
)

# # Finetune other model
# client.fine_tuning.jobs.create(
#   training_file=train_file.id, 
#   validation_file= val_file.id,
#   model='gpt-4-0613',
#   hyperparameters=hyperparameters
# )

# Check the process
client.fine_tuning.jobs.list(limit=10)

