from openai import OpenAI
from configurations import EVE_PROMPT_SYSTEM_FOR_FINE_TUNNING, OPENAI_API_KEY

client = OpenAI(api_key=OPENAI_API_KEY)

continue_chatting = True
while continue_chatting:
    input_text = input("You: ")
    if input_text == "exit":
        continue_chatting = False
        break
    else:
        response = client.chat.completions.create(
        model="ft:gpt-3.5-turbo-0613:talk-to-eve:eve-sailor-v1:8eplts2C",
        messages=[
            {"role": "system", "content": EVE_PROMPT_SYSTEM_FOR_FINE_TUNNING},
            {"role": "user", "content": input_text}
        ]
        )
    
        print(response.choices[0].message.content)



