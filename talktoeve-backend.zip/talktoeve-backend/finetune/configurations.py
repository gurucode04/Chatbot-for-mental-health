import sys
import os
# Template of prompts
PROMPTS_PATH = os.path.join(os.getcwd(),"documents","master_prompts")
EVE_PROMPT_SYSTEM_FOR_FINE_TUNNING = os.path.join(PROMPTS_PATH,"eve_response","eve_prompt_system_for_finetunning_english_specific_saylor_v1.txt")
OPENAI_API_KEY = "sk-proj-EaWPHv38y3CWASx9DA6yT3BlbkFJvFqpItCGq7Ra9WFbeMdo"#"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"