import pytest
from fastapi.testclient import TestClient
from api import app
import shutil
import os  
import sys
# add root directory to the sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from modules.databases_sql.databases import SurveyDatabase
from modules.databases_sql.config_database import SURVEY_DB_PATH_test

client = TestClient(app)

    
def test_sign_up():
    payload = {
        "username": "test_user",
        "user_id": "123",
        "name": "John Doe",
        "birthday": "1990-01-01",
        "nationality": "US",
        "location": "City",
        "position": "Developer",
        "area": "IT",
        "shift": "Day",
        "vessel": "Vessel1",
        "experience": "5",
        "studies": "Computer Science",
        "user_type": "test"
    }
    if os.path.exists("users/test_user"):
        shutil.rmtree("users/test_user")
    
    response = client.post("/sign_up", params=payload)
    assert response.status_code == 200
    assert response.json() =={"message": "User created", "data": None}

def test_initialize_eve():
    payload = {"username": "test_user"}
    response = client.post("/initialize_eve", params=payload)
    assert response.status_code == 200
    assert response.json() == {"message": "User initialized", "data": None}


def test_is_eve_initialized():
    # Assuming there is a user named 'test_user' and Eve is initialized for this user
    test_username = 'test_user'

    response = client.get(f"/is_eve_initialized?username={test_username}")
    assert response.status_code == 200
    assert response.json() == {"message": True, "data": None}

    # Test for a user for whom Eve is not initialized
    response = client.get("/is_eve_initialized?username=non_initialized_user")
    assert response.status_code == 200
    assert response.json() == {"message": False, "data": None}

def test_is_user():
    payload = {"username": "test_user"}

    response = client.get("/is_user", params=payload)
    assert response.status_code == 200
    assert response.json() == {"message": True, "data": None}

    # Test for a non-existing user
    payload = {"username": "non_existing_user"}
    response = client.get("/is_user", params=payload)
    assert response.status_code == 200
    assert response.json() == {"message": False, "data": None}

def test_edit_user():

    payload = {"username": 'test_user',
        "username_to_edit": 'test_user',
        "user_id": "123",
        "name": "Test User",
        "birthday": "1990-01-01",
        "nationality": "Testland",
        "location": "Test City",
        "position": "Test Position",
        "area": "Test Area",
        "shift": "Test Shift",
        "vessel": "Test Vessel",
        "experience": "5",
        "studies": "Test Studies",
        "user_type": "test"
    }

    response = client.post("/edit_user", params=payload)
    assert response.status_code == 200
    assert response.json() == {"message": "User edited", "data": None}

    # Test for a non-existing user
    payload['username_to_edit'] = "non_existing_user"
    response = client.post("/edit_user", params=payload)
    assert response.status_code == 400

def test_insert_new_survey():
    if os.path.exists(SURVEY_DB_PATH_test):
        os.remove(SURVEY_DB_PATH_test)

    payload = {
            "name": "anonymous health and wellbeing survey y2 2023",
            "date": "05-12-2023",
            "due_date": "05-02-2024",
            "questions": [
                {
                    "question": "What is your position?",
                    "options": ["Officer / Chief / SL", "Operator / Rating", "Other"],
                    "option_type": "single"
                },
                {
                    "question": "What is your age?",
                    "options": ["Under 24", "25 - 34", "35 - 44", "45 - 54", "Over 55"],
                    "option_type": "single"
                }
                # Agrega más preguntas según sea necesario
            ]
        }
    
    response = client.post("/insert_new_survey", params={"username": "test_user"} , json=payload)
    assert response.status_code == 200
    assert response.json() == {"message": "Survey inserted", "data": None}
    # to delete the survey
    response = client.post("/insert_new_survey", params={"username": "test_user"} , json=payload)

def test_get_survey_json():
    payload = {
        "username": "test_user",
        "survey_id": 0
    }
    
    response = client.post("/get_survey_json", params=payload)
    assert response.status_code == 200
    assert "data" in response.json()

def test_modify_survey():
    params = {"username": "test_user", 'survey_id': 0}
    payload = {
            "name": "modified health and wellbeing survey y2 2023",
            "date": "05-12-2023",
            "due_date": "05-02-2024",
            "questions": [
                {
                    "question": "What is your position?",
                    "options": ["Officer / Chief / SL", "Operator / Rating", "Other"],
                    "option_type": "single"
                },
                {
                    "question": "What is your age?",
                    "options": ["Under 24", "25 - 34", "35 - 44", "45 - 54", "Over 55"],
                    "option_type": "single"
                }
                # Agrega más preguntas según sea necesario
            ]
        }
    
    response = client.put("/modify_survey", params=params , json=payload)
    assert response.status_code == 200
    assert response.json() == {"message": "Survey modified", "data": None}

def test_delete_survey():
    payload = {
        "username": "test_user",
        "survey_id": 1
    }
    
    response = client.delete("/delete_survey", params=payload)
    assert response.status_code == 200
    assert response.json() == {"message": "Survey deleted", "data": None}


def test_response():
    payload = {"username": "test_user", "message": "Hello, Eve!"}
    response = client.post("/response", params=payload)
    assert response.status_code == 200
    assert response.json()['message'] == "Correctly processed"
    # Add more assertions based on the expected response structure

def test_feedback():
    payload = {"username": "test_user", "message_id": 1, "feedback": 5}
    response = client.post("/message_feedback", params=payload)
    assert response.status_code == 200
    assert response.json() == {"message": "Feedback saved", "data": None}

def test_get_user_conversations():
    # Assuming 'testuser' is not in user_eve_instances
    response = client.get("/user_conversations", params={"username": "test_user"})
    assert response.status_code == 200
    response = client.get("/user_conversations", params={"username": "bad_user"})
    assert response.status_code == 400

def test_indicators():
    payload = {"username": "test_user"}
    response = client.post("/indicators", params=payload)
    assert response.status_code == 200
    # Add more assertions based on the expected response structure

def test_mindmap():
    payload = {"username": "test_user"}
    response = client.post("/mindmap", params=payload)
    assert response.status_code == 200
    assert response.json()['message'] == "Data available"
    # Add more assertions based on the expected response structure

def test_todo_survey():
    payload = {"username": "test_user"}
    response = client.post("/todo_survey", params=payload)
    assert response.status_code == 200
    assert response.json()['message'] == "Data available"
    # Add more assertions based on the expected response structure

def test_survey_next_questions():
    payload = {"username": "test_user", "survey_id": 1, "number_of_questions": 3}
    response = client.post("/survey_next_questions", params=payload)
    assert response.status_code == 200
    assert response.json()['message'] == "Data available"
    # Add more assertions based on the expected response structure

def test_response_survey():
    payload = {"username": "test_user", "survey_id": 0}
    responses = {i: i % 2 for i in range(2)} # TO response all the questions of the survey 0
    response = client.post("/response_survey", params=payload, json=responses)
    assert response.status_code == 200
    assert response.json() == {"message": "Survey response saved", "data": None}

def test_finalize_eve():
    payload = {"username": "test_user"}
    response = client.post("/finalize_eve", params=payload)
    assert response.status_code == 200
    assert response.json() == {"message": "Eve finalized", "data": None}
    # Add more assertions based on the expected response structure

def test_user_dashboard():
    payload = {"username": "test_user"}
    response = client.post("/initialize_eve", params=payload)
    payload = {
        "username": "test_user",
        "start_filter_date": "2023-01-01",
        "end_filter_date": "2030-01-01",
        "aggregate": True,
        "wheited": False,
        "last_session": True,
        "period": "weekly"
    }
    response = client.post("/user_dashboard", params=payload)
    assert response.status_code == 200
    assert response.json()['message'] == "Data available"

# Comapny tests

def test_company_dashboard():
    payload = {
        "username": "test_user",
        "filters": None,
        "start_date": "2023-01-01",
        "end_date": "2025-01-01",
        "aggregate": True,
        "wheited": False,
        "last_session": True,
    }
    response = client.post("/company_dashboard", params=payload)
    assert response.status_code == 200
    # Add more assertions based on the expected response structure
    payload = {
        "username": "test_user",
        "start_filter_date": "2023-01-01",
        "end_filter_date": "2025-01-01",
        "aggregate": True,
        "wheited": False,
        "last_session": True,
    }
    filters =  {"position": [' UNKNOWN', ' Engineer', ' dgfg', 'Developer', ' Developer'], 
               "shift": [' UNKNOWN', ' fdg', 'Day', ' Day'], 
               "area": [' UNKNOWN', ' Engineering', ' gfdg', 'IT', ' IT'], 
               "vessel": [ ' Margarita', ' Norwegian Spirit', ' dfg', 'Vessel1', ' UNKNOWN',' Vessel1']}
    response = client.post("/company_dashboard", params=payload, json=filters)
    assert response.status_code == 200
    if response.json()['data'] is None:
        assert response.json()['message'] == "No data available in the selected period/with the selected filters"
    else:
        assert response.json()['message'] == "Data available"
        


def test_insert_company_info():
    payload = {"username": "test_user"}
    response = client.post("/initialize_eve", params=payload)
    payload = {
        "username": "test_user",
        "company_name": "Tech Innovations Inc.",
        "industry": "Information Technology",
        "address": "123 Tech Street, Innovation City",
        "company_email": "contact@techinnovations.com",
        "company_number": "+11234567890",
        "company_logo": "https://filepath.com",
        "company_description": "Tech Innovations Inc. is at the forefront of the digital revolution, offering cutting-edge software solutions, web and mobile development services, and comprehensive IT consulting to help businesses thrive in today's fast-paced technological landscape.",
        "services_offered" : "Software Development,Web Design and Development,Mobile App Development,Cloud Solutions,IT Consulting"
    }
    business_hours = {
            "Monday": "9:00 AM - 5:00 PM",
            "Tuesday": "9:00 AM - 5:00 PM",
            "Wednesday": "9:00 AM - 5:00 PM",
            "Thursday": "9:00 AM - 5:00 PM",
            "Friday": "9:00 AM - 5:00 PM",
            "Saturday": "Closed",
            "Sunday": "Closed"
            
        }
    response = client.post("/insert_company_info",params = payload, json= business_hours)
    assert response.status_code == 200

   
def test_get_company_info():
    payload = {"username": "test_user"}
    response = client.post("/initialize_eve", params=payload)
    response = client.post("/get_company_info", params=payload)
    assert response.status_code == 200
    
def test_get_surveys_responses():
    payload = {
        "username": "test_user",
        "survey_id": 0,
    }
    response = client.post("/getsurveysresponses", params=payload)
    assert response.status_code == 200
