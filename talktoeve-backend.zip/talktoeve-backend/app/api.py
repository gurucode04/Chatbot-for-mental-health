from fastapi import FastAPI, HTTPException, Response, Depends, UploadFile, File, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
import base64
from pydantic import BaseModel
import sys
import os
from typing import Union, List, Dict
import shutil
import pandas as pd
from fastapi.middleware.cors import CORSMiddleware
# add root directory to the sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from modules.users_manager.user_manager import UserManager
from modules.databases_sql.databases import SurveyDatabase
import ssl
from modules.users_manager.config import PATH_USERS_FOLDERS
current_dir = os.path.dirname(os.path.abspath(__file__))
# Obtain the parent directory
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.eve import Eve
from modules.databases_sql.databases import CompanyDatabase
from modules.auxiliar_functions import ritik_format
    
    
app = FastAPI()

@app.exception_handler(500)
async def internal_exception_handler(request: Request, exc: Exception):
  return JSONResponse(status_code=500, content=jsonable_encoder({"detail": "Internal Server Error"}))

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain('app/cert.pem', keyfile='app/key.pem')

user_eve_instances = {}

class sign_in(BaseModel):
    username: str
    model_name: Union[str, None] = None 

@app.post("/initialize_eve")
def initialize_eve(payload: sign_in = Depends()):
    if payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is already initialized for this user")

    # Crear una nueva instancia de Eve para el usuario
    user_eve_instances[payload.username] = Eve()
    user_eve_instances[payload.username].initialize(payload.username)

    if payload.model_name:
        user_eve_instances[payload.username].models_manager.change_prop(info_key='eve_response', 
                                            prop_name='model_name', prop=payload.model_name)
        user_eve_instances[payload.username].models_manager.change_prop(info_key='eve_response', 
                                            prop_name='max_tokens', prop=300)
    
    return {"message": "User initialized",
        "data": None}

@app.get("/is_eve_initialized")
def is_eve_initialized(payload: sign_in = Depends()):
    if payload.username in user_eve_instances:
        return {"message": True,
                "data": None}
    else:
        return {"message": False,
                "data": None}

@app.get("/is_user")
def is_user(payload: sign_in = Depends()):
    
    if payload.username in os.listdir(PATH_USERS_FOLDERS):
        return {"message": True,
                "data": None}
    else:
        return {"message": False,
                "data": None}

class sign_up(BaseModel):
    username: str
    user_id : str
    name: str
    birthday: str
    nationality: str
    location: str
    position: str
    area: str
    shift: str
    vessel: str
    experience: str
    studies: str
    user_type: str = "user"

@app.post("/sign_up")
def sign_up(payload: sign_up = Depends()):
    user_manager = UserManager(sign_up=True)
    payload = payload.model_dump()
    #add the user
    payload['edit'] = False
    user_manager.create_edit_user(payload)
    del user_manager
    return {"message": "User created",
        "data": None}

class edit_user(BaseModel):
    username: str
    username_to_edit: str
    user_id : str
    name: str
    birthday: str
    nationality: str
    location: str
    position: str
    area: str
    shift: str
    vessel: str
    experience: str
    studies: str
    user_type: str = "user"

@app.post("/edit_user")
def edit_user(payload: edit_user = Depends()):

    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to delete a user")

    payload = payload.model_dump()
    payload['username'] = payload['username_to_edit']
    payload.pop('username_to_edit')
    payload['edit'] = True

    eve.user_manager.create_edit_user(payload)

    return {"message": "User edited",
        "data": None}

class PatientMessage(BaseModel):
    username: str
    message: Union[str, None] = None
    audio: Union[UploadFile, None] = None
    audio_response_flag: bool = True 

@app.post("/response")
async def response(payload: PatientMessage = Depends()):

    audio_response_path = None
    
    if payload.message is None and payload.audio is None:
        raise HTTPException(status_code=400, detail="Message is empty")
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    
    if payload.audio:
        audio_path = os.path.join(current_dir, "TEMP", eve.username, "audio", payload.audio.filename)
        os.makedirs(os.path.dirname(audio_path), exist_ok=True)
        with open(audio_path, "wb") as f:
            f.write(payload.audio.file.read())
        user_input = eve.speech_to_text.transcribe(audio_path)
    else:
        user_input = payload.message

    response_dict = eve.response(user_input, audio_response_flag=payload.audio_response_flag)
    eve_message, audio_response_path, survey = response_dict["eve_message"], response_dict["audio_path_file"], response_dict["survey"]
    
    if payload.audio_response_flag:
        with open(audio_response_path, "rb") as f:
            audio_bytes = f.read()
        # audio_response = FileResponse(audio_response_path, media_type="audio/mpeg")
        audio_base64 = base64.b64encode(audio_bytes).decode("utf-8")
        return {"message": "Correctly processed",
                "data": {"message_id": response_dict['message_id'], "response": eve_message, "audio_b64": audio_base64, "survey": survey, "sessoion_id": eve.session_id}}

    return {"message": "Correctly processed",
            "data": {"message_id": response_dict['message_id'], "response": eve_message, "audio_b64": None, "survey": survey, "sessoion_id": eve.session_id}}

class message_feedback(BaseModel):
    username: str
    message_id: str
    feedback: str

@app.post("/message_feedback")
def message_feedback(payload: message_feedback = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    eve.conversation_manager.add_feedback(message_id = payload.message_id, feedback = payload.feedback)    

    return {"message": "Feedback saved",
            "data": None}


class indicators(BaseModel):
    username: str
    session_id: Union[str, None] = None
    from_date: Union[str, None] = None
    to_date: Union[str, None] = None
    aggregate: bool = False

@app.post("/indicators")
def indicators(payload: indicators = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    
    indicators = eve.user_manager.get_indicators(session_id = payload.session_id, from_date = payload.from_date, to_date = payload.to_date, aggregate = payload.aggregate)
    
    return indicators.to_dict('records')

class mindmap(BaseModel):
    username: str
    session_id: Union[str, None] = None
    from_date: Union[str, None] = None
    to_date: Union[str, None] = None
    parent_node_id : Union[int, None] = None

@app.post("/mindmap")
def mindmap(payload: mindmap = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    
    graph_df, nodes_df = eve.user_manager.database.get_mindmap(session_id = payload.session_id, 
                                                         from_date = payload.from_date, to_date = payload.to_date,
                                                         parent_node_id = payload.parent_node_id)
    
    return {"message": "Data available",
            "edgelist": graph_df.to_dict('records'),
            "nodelist": nodes_df.to_dict('records')}


class node_notes(BaseModel):
    username: str
    node_id: int
    notes: str

@app.post("/uptade_node_notes")
def node_note(payload: node_notes = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    eve.user_manager.database.update_node_notes(node_id = payload.node_id, note = payload.notes)    

    return {"message": "Node notes saved",
            "data": None}

class todo_survey_(BaseModel):
    username: str

@app.post("/todo_survey")
def todo_survey(payload: todo_survey_ = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    
    survey_df = eve.user_manager.database.get_survey_df()
    return {"message": "Data available",
            "data": survey_df.to_dict('records')}

class NextQuestion(BaseModel):
    username: str
    survey_id: int
    number_of_questions: int = 1

@app.post("/survey_next_questions")
def survey_next_questions(payload: NextQuestion = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    
    survey_formatted = eve.user_manager.database.get_survey_next_questions(survey_id = payload.survey_id, number_of_questions = payload.number_of_questions)
    # question_dicts = eve.obtain_question(question_id = None, return_dict = True, n_questions = payload.number_of_questions)
    
    return {"message": "Data available",
            "data": survey_formatted}
    
class Response(BaseModel):
    username: str
    survey_id: int
    responses: Dict[int, int]

@app.post("/response_survey")
def response_survey(payload: Response = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    survey_response = {'survey_id':payload.survey_id, 'username':payload.username, 'responses':payload.responses}
    eve.user_manager.database.insert_survey_response(survey_response)    

    return {"message": "Survey response saved",
            "data": None}

class user_conv(BaseModel):
    username: str

@app.get("/user_conversations")
def get_user_conversations(message: user_conv = Depends()):

    if not message.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[message.username]
    conversations_list = eve.user_manager.database.get_session_history_data_as_dataframe(session_id=None)
    if len(conversations_list) > 0:
        conversations_list = conversations_list[['message_id', 'message', 'role']].copy()
        # change role to a boolean column isEve (True if the role is eve)
        conversations_list['isEve'] = conversations_list['role'].apply(lambda x: True if x == 'Eve' else False)
        conversations_list.drop(columns=['role'], inplace=True)
        conversations_list = conversations_list.to_dict('records')
    else:
        conversations_list = []

    actual_conversation = eve.conversation_manager.get_conversation()
    if len(actual_conversation) > 0:
        actual_conversation = actual_conversation.split("\n")
        # add message_id to the conversation
        biggest_message_id = conversations_list[-1]['message_id'] if len(conversations_list) > 0 else 0
        actual_list = [{'message_id': biggest_message_id + i + 1, 'message': message[len("User:" if message.startswith("User:") else "EVE:"):].strip(), 'isEve': message.startswith("EVE:")} for i, message in enumerate(actual_conversation) if message.startswith("User:") or message.startswith("EVE:")]
        conversations_list = conversations_list + actual_list
      
    if len(conversations_list) == 0:
        return {"message": "No data available",
                "data": None}
    else:
        return {
            "message": 'Data available',
            "data": conversations_list
        }

class UserDashboard(BaseModel):
    username: str
    start_filter_date: Union[str, None] = None
    end_filter_date: Union[str, None] = None
    aggregate: bool = False
    wheited: bool = True
    last_session: bool = False
    period: str = 'weekly'

@app.post("/user_dashboard")
def user_dashboard(payload: UserDashboard = Depends()):
    """Example of a user dashboard output: 
        dashboard: is a dict with the following keys:
        - main_indicators: dict with the keys:
                * 'stress_score': float,
                * 'delta_stress_score': float,
                * 'depression_score': float,
                * 'delta_depression_score':float,
                * 'positive_score': float,
                * 'delta_positive_score':float,
                * 'neutral_score': float,
                * 'delta_neutral_score':float,
                * 'negative_score': float,
                * 'delta_negative_score': float
        - positive_emotions: dict with the keys:
                * '1_emotion_name': float,
                * '1_emotion_score':float,
                * '2_emotion_name': float,
                * '2_emotion_score':float,  
                * '3_emotion_name': float,
                * '3_emotion_score': float,
        - neutral_emotions: dict with the keys:
                * '1_emotion_name': float,
                * '1_emotion_score':float,
                * '2_emotion_name': float,
                * '2_emotion_score':float,  
                * '3_emotion_name': float,
                * '3_emotion_score': float,
        - negative_emotions: dict with the keys:
                * '1_emotion_name': float,
                * '1_emotion_score':float,
                * '2_emotion_name': float,
                * '2_emotion_score':float,  
                * '3_emotion_name': float,
                * '3_emotion_score': float,
        - mental_health: dict with the keys of each period of time:
                * '1' : dict with the keys:
                        + period: str : 'dd/mm/yyyy - dd/mm/yyyy'
                        + positive_score: float
                        + neutral_score: float
                        + negative_score: float
                * '2' : ....
        - evolution_metrics: dict with the keys of each period of time:
                * '1' : dict with the keys:
                        + period: str : 'dd/mm/yyyy - dd/mm/yyyy'
                        + stress_score: float
                        + depression_score: float
                        + positive_score: float
                * '2' : ....
    
    
    """
    
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]
    dashboard = eve.user_manager.database.get_user_dashboard(   start_filter_date = payload.start_filter_date, 
                                                                end_filter_date = payload.end_filter_date, 
                                                                aggregate = payload.aggregate, 
                                                                wheited = payload.wheited, 
                                                                last_session = payload.last_session)
    
    if dashboard:
        # Change the format
        dashboard = ritik_format(dashboard)
        return {"message": "Data available",
                "data": dashboard}
    else: 
        return {"message": "No data available in the selected period",
                "data": None}

class CompanyDashboard(BaseModel):
    username: str
    filters: Union[dict[str, List[str]], None] = None
    start_filter_date: Union[str, None] = None
    end_filter_date: Union[str, None] = None
    aggregate: bool = False
    wheited: bool = True
    last_session: bool = False
    period: str = 'weekly'

@app.post("/company_dashboard")
def company_dashboard(payload: CompanyDashboard = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to get company dashboard data")
    
    companyDB = CompanyDatabase(eve.user_type)
    dashboard = companyDB.get_company_dashboard(period = payload.period, 
                                        start_filter_date = payload.start_filter_date, 
                                        end_filter_date = payload.end_filter_date, 
                                        aggregate = payload.aggregate, 
                                        wheited = payload.wheited, 
                                        last_session = payload.last_session, 
                                        filters = payload.filters)
    del companyDB
    if dashboard:
        #dashboard = ritik_format(dashboard) # Here we need to change the functions
        return {"message": "Data available",
                "data": dashboard}
    else:
        return {"message": "No data available in the selected period/with the selected filters",
                "data": None}


class finalize_eve_(BaseModel):
    username: str
@app.post("/finalize_eve")
def finalize_eve(payload: finalize_eve_ = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances.pop(payload.username)
    
    # delete temporary files
    eve.finalize()
    shutil.rmtree(os.path.join(current_dir, "TEMP", eve.username))
    # delete eve object
    del eve
    # create new eve object
    return {"message": "Eve finalized",
            "data": None}
    
class Question(BaseModel):
    question: str
    options: List[str]|None = None
    option_type: str # 'single', 'multiple' or 'text'

class Survey(BaseModel):
    name: str
    date: str
    due_date: str
    questions: List[Question]

class InsertSurvey(BaseModel):
    username: str
    survey: Survey
    
@app.post("/insert_new_survey")
def insert_new_survey(payload: InsertSurvey = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to insert a new survey")
    
    survey_db = SurveyDatabase(eve.user_type)
    survey_db.insert_new_survey(survey_json = payload.survey.model_dump())    
    return {"message": "Survey inserted",
            "data": None}

class SurveyID(BaseModel):
    username: str
    survey_id: int

@app.post("/get_survey_json")
def get_survey_json(payload: SurveyID = Depends()):
    if payload.username not in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to access surveys")

    survey_db = SurveyDatabase(eve.user_type)
    try:
        survey_json = survey_db.get_survey_json(survey_id=payload.survey_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    
    return {"message": "Survey retrieved", "data": survey_json}

class ModifySurvey(InsertSurvey):
    survey_id: int

@app.put("/modify_survey")
def modify_survey(payload: ModifySurvey = Depends()):
    if payload.username not in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to modify surveys")

    survey_db = SurveyDatabase(eve.user_type)
    try:
        survey_db.edit_survey(survey_id=payload.survey_id, survey_json=payload.survey.model_dump())
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    
    return {"message": "Survey modified", "data": None}

@app.delete("/delete_survey")
def delete_survey(payload: SurveyID = Depends()):
    if payload.username not in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")

    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to delete surveys")

    survey_db = SurveyDatabase(eve.user_type)
    try:
        survey_db.delete_survey(survey_id=payload.survey_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    
    return {"message": "Survey deleted", "data": None}


class delete_user(BaseModel):
    username: str
    username_to_delete: str

@app.post("/delete_user")
def delete_user(payload: delete_user = Depends()):

    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to delete a user")

    eve.user_manager.delete_user(payload.username_to_delete)

    return {"message": "User deleted",
        "data": None}

class getsurveysresponses(BaseModel):
    username: str
    survey_id: int
@app.post("/getsurveysresponses")
def getsurveysresponses(payload: getsurveysresponses = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to get survey responses")
    
    survey_db = SurveyDatabase(eve.user_type)
    get_survey_responses = survey_db.get_survey_responses(survey_id = payload.survey_id)
    if get_survey_responses:
        return {"message": "Data available",
                "data": get_survey_responses}
    else:
        return {"message": "No data available",
                "data": None}


class InsertCompanyInfo(BaseModel):
    username: str
    company_name : str
    industry : str
    address : str
    company_email : str
    company_number : str
    company_logo : str
    business_hours : Dict[str, str]
    services_offered : str
    company_description : str   

@app.post("/insert_company_info")
def insert_company_info(payload: InsertCompanyInfo = Depends()):
    
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to get company dashboard data")
    # Create a list of service offered by the company
    services_offered = [service.strip() for service in payload.services_offered.split(",")]
    companyDB = CompanyDatabase(eve.user_type)
    company_info = {
        "company_name": payload.company_name,
        "industry": payload.industry,
        "address": payload.address,
        "company_email": payload.company_email,
        "company_number": payload.company_number,
        "company_logo": payload.company_logo,
        "business_hours": payload.business_hours,
        "services_offered": services_offered,
        "company_description": payload.company_description
    }
    companyDB.insert_company_info(company_info)
    return {"message": "Company info inserted",
            "data": None}
    
class GetCompanyInfo(BaseModel):
    username: str
@app.post("/get_company_info")
def get_company_info(payload: GetCompanyInfo = Depends()):
    if not payload.username in user_eve_instances:
        raise HTTPException(status_code=400, detail="Eve is not initialized for this user")
    
    eve = user_eve_instances[payload.username]

    if eve.user_type == "user":
        raise HTTPException(status_code=401, detail="User is not authorized to get company dashboard data")
    
    companyDB = CompanyDatabase(eve.user_type)
    company_info = companyDB.get_company_info()
    return {"message": "Company info available",
            "data": company_info}

@app.get("/")
def read_root():
    return "Talk to Eve API is running"