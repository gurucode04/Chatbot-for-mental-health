import openai
from openai import OpenAI
from modules.global_configs import OPENAI_API_KEY
from config.constants.prompt_constants import system_prompt
from utils.logger import setup_logger
from traceback import print_exc
# openai.api_key = OPENAI_API_KEY
client = OpenAI(
    # This is the default and can be omitted
    api_key=OPENAI_API_KEY,
)

user_conversations:dict = {} # user_name : <conversation> 

class ResponseGenerator():
    def __init__(self) -> None:
        self.intent_state:dict = {}
        self.session_state:dict = {}
        if "messages" not in self.session_state:
            self.session_state["messages"] = self.set_bot_persona()
            self.intent_state["messages"] = []


    def set_bot_persona(self):
        messages = [
            {
                "role": "system",
                "content": system_prompt
            },
        ]
        return messages

    def generate_response(self, messages):
        try:
            response = client.chat.completions.create(model="gpt-4o", messages=messages,
                                                    # use this for 16k model : gpt-3.5-turbo-16k, gpt-4
                                                    temperature=0.7,
                                                    max_tokens=4000,
                                                    # max_tokens=8000 - num_tokens_from_string(str(messages)),
                                                    # make it 16000 while using 16k model
                                                    top_p=1,
                                                    frequency_penalty=0,
                                                    presence_penalty=0
                                                    )
            msg = response.choices[0].message

        except openai.RateLimitError as e:
            return {"role": "assistant",
                   "content": "Error from OpenAI service --> Rate Limit Error. Please try again after a few seconds."}
        except openai.APIConnectionError as e:
            # Handle connection error here
            return {"role": "assistant",
                   "content": "Error from OpenAI service --> Failed to connect to OpenAI API. Please try again after a few seconds."}
        except openai.APIError as e:
            # Handle API error here, e.g. retry or log
            return {"role": "assistant",
                   "content": "Error from OpenAI service --> API Error. Please try again after a few seconds."}
        except Exception as e:
            print(f"Unexpected Error from OpenAI, {e}")
            return {"role": "assistant",
                   "content": "Error from OpenAI service --> Unexpected Error. Please try again after a few seconds."}

        return {"role": "assistant",
                   "content": msg.content}
    
    # def get_response(self, query, previous_chat):
    #     pass
    def get_user_conversation(user_name):
        try:
            global user_conversations
            if user_name in user_conversations:
                return user_conversations[user_name]
            else:
                return None
        except Exception as e:
            print_exc()
            setup_logger().error(f"Failed to get user conversation for {user_name}. Error: {e}\n Detailed Error: {print_exc()}")
            raise Exception(f"Failed to get user Conversation for user {user_name}. Error: {e}")


    def set_user_conversation(user_name):
        try:
            global user_conversations
            user_conversations[user_name] = ResponseGenerator()
            return user_conversations[user_name]
        except Exception as e:
            print_exc()
            setup_logger().error(f"Failed to set user conversation for {user_name}. Error: {e}\n Detailed Error: {print_exc()}")
            raise Exception(f"Failed to set user Conversation for user {user_name}. Error: {e}")


    def update_user_conversation(user_name,message:dict):
        try:
            global user_conversations
            if user_name in user_conversations:
                user_conversations[user_name].append(message)
                return user_conversations[user_name]
            else:
                raise ValueError(f"update_user_conversation failed for {user_name}")
        except Exception as e:
            print_exc()
            setup_logger().error(f"Failed to set user conversation for {user_name}. Error: {e}\n Detailed Error: {print_exc()}")
            raise Exception(f"Failed to set user Conversation for user {user_name}. Error: {e}")