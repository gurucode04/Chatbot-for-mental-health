import openai
import os
from typing import List, Dict, Union, Optional
from pydantic import BaseModel
from traceback import print_exc
from utils.enums.model_enum import OpenaiModelNames


class OpenAIClient:
    def __init__(
        self,
        api_key: str,
        # The model to use, e.g., "gpt-4", "gpt-3.5-turbo", etc.
        model: str = OpenaiModelNames.GPT4O.value,
        # Controls the randomness of the output; higher values = more random
        temperature: float = 0.5,
        # Maximum number of tokens to generate in the completion
        max_tokens: Optional[int] = None,
        # Nucleus sampling: considers tokens within the top_p probability mass
        top_p: float = 1.0,
        # Penalizes new tokens based on frequency in the text so far
        frequency_penalty: float = 0.0,
        # Penalizes new tokens if they appear in the text so far
        presence_penalty: float = 0.0,
        # Adjusts likelihood of specified tokens appearing
        logit_bias: Optional[Dict[str, int]] = None,
        n: int = 1,  # Number of completions to generate for each prompt
        # If true, streams partial message deltas as they become available
        stream: Optional[bool] = False,
        # Sequences where the API will stop generating further tokens
        stop: Optional[Union[str, List[str]]] = None,
        # Unique identifier representing the end-user
        user: Optional[str] = None,
        # Ensures deterministic sampling for the given seed
        seed: Optional[int] = None,
        # Specifies the format the model must output
        response_format: Optional[Dict] = None,
    ):
        # Initialize OpenAI client with the provided API key
        self.client = openai.OpenAI(api_key=api_key)
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.top_p = top_p
        self.frequency_penalty = frequency_penalty
        self.presence_penalty = presence_penalty
        self.logit_bias = logit_bias
        self.n = n
        self.stream = stream
        self.stop = stop
        self.user = user
        self.seed = seed
        self.response_format = response_format

    def get_response(self, messages: List[Dict[str, str]]):
        """
        Creates a model response for the given chat conversation.

        :param messages: A list of messages comprising the conversation so far.
        :return: The generated response from the model.
        """
        try:
            # Create a completion using the OpenAI client
            completion = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                top_p=self.top_p,
                frequency_penalty=self.frequency_penalty,
                presence_penalty=self.presence_penalty,
                logit_bias=self.logit_bias,
                n=self.n,
                stream=self.stream,
                stop=self.stop,
                user=self.user,
                seed=self.seed,
                response_format=self.response_format
            )

            return {"role": "assistant",
                    "content": completion.choices[0].message.content}

        except openai.RateLimitError as e:
            print_exc()
            return {"role": "assistant",
                    "content": "Error from OpenAI service --> Rate Limit Error. Please try again after a few seconds."}
        except openai.APIConnectionError as e:
            print_exc()
            return {"role": "assistant",
                    "content": "Error from OpenAI service --> Failed to connect to OpenAI API. Please try again after a few seconds."}
        except openai.APIError as e:
            print_exc()
            return {"role": "assistant",
                    "content": "Error from OpenAI service --> API Error. Please try again after a few seconds."}
        except Exception as e:
            print_exc()
            print(f"Unexpected Error from OpenAI, {e}")
            return {"role": "assistant",
                    "content": f"Error from OpenAI service --> Unexpected Error {e}. Please try again after a few seconds."}

    def get_structured_response(self, messages: List[Dict[str, str]], response_format: BaseModel):
        try:
            completion = self.client.beta.chat.completions.parse(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                top_p=self.top_p,
                frequency_penalty=self.frequency_penalty,
                presence_penalty=self.presence_penalty,
                logit_bias=self.logit_bias,
                n=self.n,
                stream=self.stream,
                stop=self.stop,
                user=self.user,
                seed=self.seed,
                response_format=response_format.dict() if response_format else None
            )

            return {"role": "assistant",
                    "content": completion.choices[0].message.parsed}

        except openai.RateLimitError as e:
            print_exc()
            return {"role": "assistant",
                    "content": "Error from OpenAI service --> Rate Limit Error. Please try again after a few seconds."}
        except openai.APIConnectionError as e:
            print_exc()
            return {"role": "assistant",
                    "content": "Error from OpenAI service --> Failed to connect to OpenAI API. Please try again after a few seconds."}
        except openai.APIError as e:
            print_exc()
            return {"role": "assistant",
                    "content": "Error from OpenAI service --> API Error. Please try again after a few seconds."}
        except Exception as e:
            print_exc()
            print(f"Unexpected Error from OpenAI, {e}")
            return {"role": "assistant",
                    "content": f"Error from OpenAI service --> Unexpected Error {e}. Please try again after a few seconds."}

    # Setter methods to update parameters if needed

    def set_model(self, model: str):
        self.model = model

    def set_temperature(self, temperature: float):
        self.temperature = temperature

    def set_max_tokens(self, max_tokens: int):
        self.max_tokens = max_tokens

    def set_frequency_penalty(self, frequency_penalty: float):
        self.frequency_penalty = frequency_penalty

    def set_presence_penalty(self, presence_penalty: float):
        self.presence_penalty = presence_penalty

    def set_logit_bias(self, logit_bias: Dict[str, int]):
        self.logit_bias = logit_bias

    def set_stop(self, stop: Union[str, List[str]]):
        self.stop = stop


# Example usage
if __name__ == "__main__":
    # Initialize the client with the API key and specific model
    client = OpenAIClient(api_key=os.getenv(
        "OPENAI_API_KEY"), model="gpt-4o-mini")

    # Example of generating a chat completion
    messages = [
        {"role": "system", "content": "You are a helpful assistant. Help me with my math homework!"},
        {"role": "user", "content": "Hello! Could you solve 2+2?"}
    ]

    response = client.get_response(messages)
    print(response.get('content'))

    # # Example for structured output

    # class Step(BaseModel):
    #     explanation: str
    #     output: str

    # class MathReasoning(BaseModel):
    #     steps: list[Step]
    #     final_answer: str

    # messages = [
    #     {"role": "system", "content": "You are a helpful math tutor."},
    #     {"role": "user", "content": "Solve 2x + 3 = 7"}
    # ]
    # math_response = client.generate_response(
    #     messages, response_format=MathReasoning)
    # print("Math Reasoning:", math_response)
