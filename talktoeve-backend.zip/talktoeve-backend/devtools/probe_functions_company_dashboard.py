import pandas as pd
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.databases_sql.databases import CompanyDatabase

company_db = CompanyDatabase(usertype = 'test')

company_info = {
       "company_name": "Tech Innovations Inc.",
       "industry": "Information Technology",
       "address": "123 Tech Street, Innovation City ",
       "company_email": "contact@techinnovations.com",
       "company_number": "+11234567890",
       "company_logo":"https://filepath.com",    
       "business_hours": {
                            "Monday": "9:00 AM - 5:00 PM",
                            "Tuesday": "9:00 AM - 5:00 PM",
                            "Wednesday": "9:00 AM - 5:00 PM",
                            "Thursday": "9:00 AM - 5:00 PM",
                            "Friday": "9:00 AM - 5:00 PM",
                            "Saturday": "Closed",
                            "Sunday": "Closed"
                            },
       "services_offered": [
       "Software Development",
       "Web Design and Development",
       "Mobile App Development",
       "Cloud Solutions",
       "IT Consulting"
       ],
       "company_description": "Tech Innovations Inc. is at the forefront of the digital revolution, offering cutting-edge software solutions, web and mobile development services, and comprehensive IT consulting to help businesses thrive in today's fast-paced technological landscape."
}
       
company_db.insert_company_info(company_info)

dict_info = company_db.get_company_info()

att = {'period': 'weekly', 
       'start_filter_date': None, 
       'end_filter_date': None, 
       'aggregate': True, 
       'wheited': False, 
       'last_session': False, 
       'filters': None}

dict_ = company_db.get_company_dashboard(**att)

