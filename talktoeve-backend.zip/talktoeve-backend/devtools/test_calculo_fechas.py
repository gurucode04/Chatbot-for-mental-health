from datetime import datetime, timedelta

def diff_weeks(d1, d2):
    return (d1 - d2).days // 7

def diff_months(d1, d2):
    return (d1.year - d2.year) * 12 + d1.month - d2.month

def diff_years(d1, d2):
    return d1.year - d2.year


def calcular_fechas(periodo, fecha_inicio, fecha_actual):
    fechas_dict = {}
    
    if periodo == 'weekly':
        semanas_diferencia = diff_weeks(fecha_actual, fecha_inicio)
        init_date = fecha_inicio
        for i in range(1, semanas_diferencia + 1):
            end_date = init_date + timedelta(days=7 - 1)
            fechas_dict[i] = {'init_date': init_date.strftime("%d/%m/%Y"), 'end_date': end_date.strftime("%d/%m/%Y")}
            init_date = end_date + timedelta(days=1)
            
    elif periodo == 'monthly':
        months_diff = diff_months(fecha_actual, fecha_inicio)
        init_date = fecha_inicio.replace(day=1)
        for month in range(1, months_diff + 1):
            end_date = init_date.replace(day=1, month=init_date.month + 1) - timedelta(days=1)
            fechas_dict[month] = {'init_date': init_date.strftime("%d/%m/%Y"), 'end_date': end_date.strftime("%d/%m/%Y")}
            init_date = end_date + timedelta(days=1)
            
    elif periodo == 'yearly':
        years_diff = diff_years(fecha_actual, fecha_inicio)
        init_date = fecha_inicio.replace(month=1, day=1)
        for year in range(years_diff + 1):
            end_date = init_date.replace(month=12, day=31, year=init_date.year)
            fechas_dict[year] = {'init_date': init_date.strftime("%d/%m/%Y"), 'end_date': end_date.strftime("%d/%m/%Y")}
            init_date = end_date + timedelta(days=1)
    
    else:
        raise ValueError("Periodo no válido. Debe ser 'weekly', 'monthly' o 'yearly'")
    
    return fechas_dict

# Definir las fechas de inicio y actual
fecha_inicio = datetime(2023, 1, 1)
fecha_actual = datetime(2024, 1, 1)

# Obtener el diccionario de fechas para el periodo mensual
periodo = 'yearly'
fechas_dict = calcular_fechas(periodo, fecha_inicio, fecha_actual)

# Imprimir el diccionario para verificar
for clave, (inicio_periodo, fin_periodo) in fechas_dict.items():
    print(f"{periodo.capitalize()} {clave}: Inicio - {inicio_periodo}, Fin - {fin_periodo}")
