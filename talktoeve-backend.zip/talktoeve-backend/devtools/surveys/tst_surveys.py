import os
import sys

#Obtain the path to the current directory
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
# Add the path to the sys.path list
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.chatbot.surveys_manager import SurveyManager_v1

survey_manager = SurveyManager_v1()

user_path = os.path.join(grandparent_dir, 'users', 'bzorzet', 'surveys')

dict_surveys = survey_manager.load_surveys_list(survey_user_path = user_path, return_survey_list = True)
print(dict_surveys)


flag = survey_manager.load_survey(survey_id='000')
print(flag)

n_question = survey_manager.obtain_number_of_questions()

save_flag = False
while not survey_manager.survey_answered:
    question, question_id = survey_manager.obtain_question(question_id = None, return_dict = True)
    print(question)
    if question == None and question_id == None:   
        break
    response = str(0)
    survey_manager.load_response(question_id=question_id , response_id = response)
    print(survey_manager.survey_responses_dataframe)
    if save_flag:
        survey_manager.save_survey_responses()
        
survey_manager.save_survey_responses()
        