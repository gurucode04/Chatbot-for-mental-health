import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.eve import Eve

if __name__ == "__main__":

    # Initialize Eve
    eve = Eve()
    
    # Username and password
    username = "ChuckBOT"
    password = "test1"
    
    # Initialize Eve
    eve.initialize(username=username)
    
    # # Load the surveys list
    # print(eve.load_survey_list(return_survey_list=True))
    
    # # Load the survey
    # print(eve.load_survey(survey_id='000')) 
    
    
    # Define the flag chat
    chat = True
    while chat:
        # Obtain the user message
        message = input("USER: ")
        # Check if the user wants to exit
        if message.lower() == "exit":
            chat = False
        else:
            # Obtain the response of Eve
            eve_message = eve.response_text(message)

    # Finalize Eve
    eve.finalize()

