import pandas as pd
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.databases_sql.databases import CompanyDatabase

company_db = CompanyDatabase()
att = {'period': 'weekly', 
       'start_filter_date': None, 
       'end_filter_date': None, 
       'aggregate': True, 
       'wheited': False, 
       'last_session': False, 
       'filters': {"position": [' UNKNOWN', ' Engineer', ' dgfg', 'Developer', ' Developer'], 
               "shift": [' UNKNOWN', ' fdg', 'Day', ' Day'], 
               "area": [' UNKNOWN', ' Engineering', ' gfdg', 'IT', ' IT'], 
               "vessel": [ ' Margarita', ' Norwegian Spirit', ' dfg', 'Vessel1', ' UNKNOWN',' Vessel1']}}

dict_ = company_db.get_company_dashboard(**att)

import json
# Save the dictionary as .json
path = os.path.join(parent_dir,'test_company_dashboard_with_differents_filters.json')
json_data = json.dumps(dict_, indent=4)
with open(path, 'w') as json_file:
    json_file.write(json_data)
    
att = {'period': 'weekly', 
       'start_filter_date': None, 
       'end_filter_date': None, 
       'aggregate': True, 
       'wheited': False, 
       'last_session': False, 
       'filters':None}

dict_ = company_db.get_company_dashboard(**att)
path = os.path.join(parent_dir,'test_company_dashboard_without_differents_filters.json')
json_data = json.dumps(dict_, indent=4)
with open(path, 'w') as json_file:
    json_file.write(json_data)
    
a=20