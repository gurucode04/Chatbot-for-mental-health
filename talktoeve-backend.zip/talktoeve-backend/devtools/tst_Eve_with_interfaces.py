import gradio as gr
import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
# Obtain the parent directory
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.eve import Eve

""" This scripts doesn't implement the methods of Eve to do the survey. It only implements the methods to chat with Eve. """""

if __name__ == "__main__":
    # Initialize Eve
    eve = Eve()
    eve.initialize(username = "dahustle", survey_on_conv_flow=False)
    eve.models_manager.change_prop(info_key='eve_response', prop_name='model_name', prop='gpt-4o')
    eve.models_manager.change_prop(info_key='eve_response', prop_name='max_tokens', prop=300)
    
    # js code to autoplay the audio of the bot
    js = """
        function playNewBotAudio(mutationList) {
        mutationList.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
            if (node.nodeName === 'BUTTON' && node.getAttribute('data-testid') === 'bot') {
                const audioElement = node.querySelector('audio');
                if (audioElement) {
                audioElement.play();
                }
            }
            });
        });
        }

        const observer = new MutationObserver(playNewBotAudio);
        const observerOptions = {
        childList: true,
        subtree: true
        };

        const targetNode = document.body; // Observar cambios en todo el documento
        observer.observe(targetNode, observerOptions);
     """
    
    def response(input_patient, chat_history = None):
        global eve
        global response_type
        # Obtain the response of Eve(self, input_user, audio_flag=False, audio_response_flag = False):
        if input_patient.endswith('.wav'):
            audio_flag = True
        else:
            audio_flag = False

        if response_type == "both":
            if audio_flag:
                chat_history.append(((input_patient,), None))
                input_patient = eve.speech_to_text.transcribe(input_patient)
            dic_aux = eve.response(input_patient, audio_response_flag=True)
            eve_message, audio_path, survey = dic_aux['eve_message'], dic_aux['audio_path_file'], dic_aux['survey']
            
            # Print the response of Eve
            if audio_flag:
                chat_history.append((None, eve_message))
            else:
                chat_history.append((input_patient, eve_message))
            # Check if audio path + '.wav' exists 
            if os.path.exists(audio_path + '.wav'):
                # If it exists, delete it
                os.remove(audio_path + '.wav')
            os.rename(audio_path, audio_path + '.wav')
            chat_history.append(( None , (audio_path + '.wav',),))
        elif response_type == "audio":
            if audio_flag:
                chat_history.append(((input_patient,), None))
                input_patient = eve.speech_to_text.transcribe(input_patient)
            else:
                chat_history.append((input_patient, None))
            dic_aux = eve.response(input_patient, audio_response_flag=True)
            eve_message, audio_path, survey = dic_aux['eve_message'], dic_aux['audio_path_file'], dic_aux['survey']
            # Check if audio path + '.wav' exists
            if os.path.exists(audio_path + '.wav'):
                # If it exists, delete it
                os.remove(audio_path + '.wav')
            os.rename(audio_path, audio_path + '.wav')
            chat_history.append(( None , (audio_path + '.wav',),))
        else:
            if audio_flag:
                chat_history.append(((input_patient,), None))
                input_patient = eve.speech_to_text.transcribe(input_patient)
            dic_aux = eve.response(input_patient, audio_response_flag=False)
            eve_message, audio_path, survey = dic_aux['eve_message'], dic_aux['audio_path_file'], dic_aux['survey']
            if audio_flag:
                chat_history.append((None, eve_message))
            else:
                chat_history.append((input_patient, eve_message))
        return chat_history

    def finish_session( chat_history = None):
        #global eve
        eve.finalize()
        chat_history.append((None, "Session finished"))
        return chat_history
    
    def update_response_type(radio):
        global response_type
        response_type = radio

    block = gr.Blocks(theme='soft', title="Talk to Eve", head="<script>\n"+js+"\n</script>")
    with block:
        gr.Markdown("""
                    # Talk to Eve Demo
                    """)
        # This is the output
        chatbot = gr.Chatbot(bubble_full_width=False)
        
        # Inputs
        patient_message = gr.Textbox(label = "Write a message")
        mic_input = gr.Audio(sources=["microphone"],label = "Record a message", type="filepath", editable=False)
        
        patient_message.submit(response, [patient_message, chatbot], [chatbot])
        patient_message.submit(lambda x: gr.update(value=''), None,[patient_message])
        
        mic_input.stop_recording(response, [mic_input, chatbot], [chatbot]).then(lambda:None, None, mic_input, queue=False) #here clean up passing None to audio.

        finish_button = gr.Button(value="Finish session")
        finish_button.click(finish_session, [chatbot], [chatbot])
        
        response_type = "audio"
        radio = gr.Radio(["audio", "text", "both"], label="Response type", value=response_type, interactive=True)
        # change the variable response_type when change the value of the radio button
        radio.change(update_response_type, [radio])
        
    block.queue().launch(share=True)
        