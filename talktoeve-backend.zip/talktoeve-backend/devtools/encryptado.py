import pandas as pd
from cryptography.fernet import Fernet

# Función para encriptar un DataFrame
def encrypt_dataframe(dataframe, key):
    # Convertir el DataFrame a formato de bytes
    dataframe_bytes = dataframe.to_csv(index=False).encode()

    # Crear un objeto Fernet con la clave proporcionada
    cipher_suite = Fernet(key)

    # Encriptar los datos del DataFrame
    encrypted_data = cipher_suite.encrypt(dataframe_bytes)

    return encrypted_data

# Función para desencriptar un DataFrame
def decrypt_dataframe(encrypted_data, key):
    # Crear un objeto Fernet con la clave proporcionada
    cipher_suite = Fernet(key)

    # Desencriptar los datos
    decrypted_data = cipher_suite.decrypt(encrypted_data)

    # Convertir los datos desencriptados a un DataFrame
    decrypted_dataframe = pd.read_csv(pd.compat.StringIO(decrypted_data.decode()))

    return decrypted_dataframe

# # Ejemplo de uso:
# # Supongamos que tienes un DataFrame llamado 'my_dataframe'
# # Genera una clave para encriptar y desencriptar (esto debería hacerse de manera segura)
# key = Fernet.generate_key()

# # Encriptar el DataFrame
# encrypted = encrypt_dataframe(my_dataframe, key)

# # Desencriptar el DataFrame
# decrypted = decrypt_dataframe(encrypted, key)

# # Ahora 'decrypted' contiene el DataFrame desencriptado
