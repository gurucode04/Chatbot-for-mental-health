import sqlite3
import pandas as pd
import os
import sys

from config_database import DEFAULT_PERSONAL_INFO_v1, DEFAULT_SESSION_TABLE_v1, DEFAULT_SESSION_HISTORY_TABLE_v1, DEFAULT_SESSION_SUMMARY_TABLE_v1

class UserDatabase():
    
    def __init__(self, path):
        self.path = path
        self.conn = sqlite3.connect(self.path)
        self.cursor = self.conn.cursor()
        
        self.tables_names = {'personal_information':'PersonalInformation', 
                             'sessions': 'Sessions', 
                             'sessions_history': 'SessionsHistory', 
                             'session_summary': 'SessionsSummary'}
        
        # Personal Information Table Template
        self.personal_information_template = DEFAULT_PERSONAL_INFO_v1
        self.session_table_template = DEFAULT_SESSION_TABLE_v1
        self.session_history_table_template = DEFAULT_SESSION_HISTORY_TABLE_v1
        self.session_summary_table_template = DEFAULT_SESSION_SUMMARY_TABLE_v1
        
    def create_personal_information_table(self):
        columns = ', '.join(self.personal_information_template['columns'])
        query = f'''CREATE TABLE IF NOT EXISTS {self.tables_names['personal_information']} (
                    ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    {columns}
                    )'''
        self.cursor.execute(query)
        
        # Insert default values
        placeholders = ', '.join(['?'] * len(self.personal_information_template['values']))
        default_values_query = f"INSERT INTO PersonalInformation ({', '.join(self.personal_information_template['columns'])}) VALUES ({placeholders})"
        self.cursor.execute(default_values_query, self.personal_information_template['values'])
        self.conn.commit()

        
    def update_last_personal_information(self, data_dict):
        # Validate keys and length of data_dict
        if set(data_dict.keys()) != set(self.personal_information_template['columns']):
            raise ValueError('Data must have the correct keys')
        
        if len(data_dict) != len(self.personal_information_template['columns']):
            raise ValueError('Data must have the correct length')
        
        # Get the last row id
        query = F"SELECT MAX(ID) FROM {self.tables_names['personal_information']}"
        self.cursor.execute(query)
        last_row_id = self.cursor.fetchone()[0]
        
        # Update data for the last row
        set_values = ', '.join([f"{col} = ?" for col in data_dict.keys()])
        values = tuple(data_dict.values())
        query = f"UPDATE {self.tables_names['personal_information']} SET {set_values} WHERE ID = ?"
        self.cursor.execute(query, values + (last_row_id,))
        self.conn.commit()

        
    def create_session_table(self):
        columns = ', '.join(f"{col} TEXT" for col in self.session_table_template['columns'])
        query = f'''CREATE TABLE IF NOT EXISTS {self.tables_names['sessions']} (
                    {columns}
                    )'''
        self.cursor.execute(query)
        self.conn.commit()

    def create_session_history_table(self):
        columns = ', '.join(f"{col} TEXT" for col in self.session_history_table_template['columns'])
        query = f'''CREATE TABLE IF NOT EXISTS {self.tables_names['sessions_history']} (
                    {columns}
                    )'''
        self.cursor.execute(query)
        self.conn.commit()

    def create_session_summary_table(self):
        columns = ', '.join(f"{col} TEXT" for col in self.session_summary_table_template['columns'])
        query = f'''CREATE TABLE IF NOT EXISTS {self.tables_names['session_summary']} (
                    {columns}
                    )'''
        self.cursor.execute(query)
        self.conn.commit()
        
    def insert_session_data(self, session_data):
        # Insert session data into Session table
        self._insert_data('Sessions', session_data)

    def insert_session_history_data(self, session_history_data):
        # Convertir el diccionario a DataFrame
        df = pd.DataFrame(session_history_data)
        
        # Insertar el DataFrame en la tabla SessionHistory
        df.to_sql(self.tables_names['sessions_history'], self.conn, if_exists='append', index=False)

    def insert_session_summary_data(self, session_summary_data):
        # Insert session summary data into SessionSummary table
        self._insert_data('SessionsSummary', session_summary_data)

    def _insert_data(self, table_name, data_dict):
        # Validate data and table name
        if not isinstance(data_dict, dict):
            raise ValueError('Data must be a dictionary')
        
        # Check that data has the correct keys
        columns_query = f"PRAGMA table_info({table_name})"
        self.cursor.execute(columns_query)
        table_columns = [col[1] for col in self.cursor.fetchall()]
        data_columns = list(data_dict.keys())

        if set(data_columns) != set(table_columns):
            raise ValueError('Data must have the correct keys')

        # Insert data into the table
        columns = ', '.join(data_dict.keys())
        placeholders = ', '.join(['?'] * len(data_dict))
        values = tuple(data_dict.values())
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        
        self.cursor.execute(query, values)
        self.conn.commit()

    def get_all_session_ids(self):
        query = "SELECT SESSION_ID FROM Sessions"
        self.cursor.execute(query)
        session_ids = [row[0] for row in self.cursor.fetchall()]
        return session_ids
    
    def get_session_data_as_dataframe(self, session_id):
        return self._get_session_data_as_dataframe(self.tables_names['sessions'], session_id)

    def get_session_history_data_as_dataframe(self, session_id):
        return self._get_session_data_as_dataframe(self.tables_names['sessions_history'], session_id)

    def get_session_summary_data_as_dataframe(self, session_id):
        return self._get_session_data_as_dataframe(self.tables_names['session_summary'], session_id)
    
    def _get_session_data_as_dataframe(self, table_name, session_id):
        if isinstance(session_id, list):
            df_list = []
            columns_query = f"PRAGMA table_info({table_name})"
            self.cursor.execute(columns_query)
            table_columns = [col[1] for col in self.cursor.fetchall()]

            for sid in session_id:
                query = f"SELECT * FROM {table_name} WHERE SESSION_ID = ?"
                self.cursor.execute(query, (sid,))
                rows = self.cursor.fetchall()
                df = pd.DataFrame(rows, columns=table_columns)
                df_list.append(df)

            return pd.concat(df_list, ignore_index=True)
        else:
            if session_id is None:
                query = f"SELECT * FROM {table_name}"
                self.cursor.execute(query)
            else:
                query = f"SELECT * FROM {table_name} WHERE SESSION_ID = ?"
                self.cursor.execute(query, (session_id,))
                
            rows = self.cursor.fetchall()
            columns_query = f"PRAGMA table_info({table_name})"
            self.cursor.execute(columns_query)
            table_columns = [col[1] for col in self.cursor.fetchall()]
            df = pd.DataFrame(rows, columns=table_columns)
            return df

    def get_personal_information_as_dataframe(self):
        query = f"SELECT * FROM {self.tables_names['personal_information']}"
        self.cursor.execute(query)
        rows = self.cursor.fetchall()
        columns_query = f"PRAGMA table_info({self.tables_names['personal_information']})"
        self.cursor.execute(columns_query)
        table_columns = [col[1] for col in self.cursor.fetchall()]
        df = pd.DataFrame(rows, columns=table_columns)
        return df