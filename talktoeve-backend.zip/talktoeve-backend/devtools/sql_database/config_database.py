# Personal Information Template v1
DEFAULT_PERSONAL_INFO_v1 = { 'columns': ['NAME', 'AGE', 'HOBBIES_INTEREST', 'OCCUPATION', 'STUDIES', 'PERSONS_WITH_WHOM_HE_SHE_LIVES', 'FAMILY', 'FRIENDS', 'PARTNER'],
                         'values': ['UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN', 'UNKNOWN']}

# Session Table Template v1
DEFAULT_SESSION_TABLE_v1 = { 'columns': ['SESSION_ID', 'DATE', 'DURATION'],}

# SessionhISTORY  Table Template v1
DEFAULT_SESSION_HISTORY_TABLE_v1 = { 'columns': ['SESSION_ID', 'MESSAGE_ID', 'ROLE', 'MESSAGE', 'TAGS'],}

# SessionSummary Table Template v1
DEFAULT_SESSION_SUMMARY_TABLE_v1 = { 'columns': ['SESSION_ID', 'SUMMARY'],}