from databases import UserDatabase

import sys
# Eliminar la base de datos si existe
import os
# Obtenemos la ruta actual
current_path = os.path.dirname(os.path.abspath(__file__))

db_path = os.path.join(current_path, 'user.db')

if os.path.exists(db_path):
    os.remove(db_path)

db = UserDatabase(path = db_path) 

db.create_personal_information_table()
db.create_session_table()
db.create_session_history_table()
db.create_session_summary_table()



# Insertar información personal
personal_info = {
    'NAME': 'John Doe',
    'AGE': 30,
    'HOBBIES_INTEREST': 'Reading, hiking',
    'OCCUPATION': 'Software Engineer',
    'STUDIES': 'Computer Science',
    'PERSONS_WITH_WHOM_HE_SHE_LIVES': 'Alone',  
    'FAMILY': 'Unknown',
    'FRIENDS': 'Unknown',
    'PARTNER': 'Unknown'}

db.update_last_personal_information(personal_info)

# Obtener información personal como DataFrame
personal_info_df = db.get_personal_information_as_dataframe()
print("Personal Information DataFrame:")
print(personal_info_df)


# Obtener todos los ID de sesión disponibles
session_ids = db.get_all_session_ids()
print("Session IDs:", session_ids)


# Insertamos datos de diferentes sesiones
session_ids = ['1', '2', '3', '4', '5']
for session_id in session_ids:
    session_data = {
        'SESSION_ID': session_id,
        'DATE': '2020-10-01',
        'DURATION': 120
    }
    db.insert_session_data(session_data)
    
    # Add the messages for each session
    session_history_data = {'SESSION_ID': [session_id, session_id,session_id, session_id, session_id], 
                            'MESSAGE_ID': ['1', '2', '3', '4', '5'], 
                            'ROLE': ['User', 'Bot', 'User', 'Bot', 'User'], 
                            'MESSAGE': ['Hi', 'Hello', 'How are you?', 'I am fine', 'Goodbye'], 
                            'TAGS': ['Greeting','Greeting', 'Question', 'Answer', 'Goodbye']}
    
    db.insert_session_history_data(session_history_data)
   
    # Obtener datos de historial de sesión como DataFrame
    session_history_df = db.get_session_history_data_as_dataframe(session_id)
    print("Session History Data DataFrame:")
    print(session_history_df)
    
    
    session_summary_data = {'SESSION_ID': session_id, 'SUMMARY': 'Good interaction'}
    db.insert_session_summary_data(session_summary_data)
    
    # Obtener datos de resumen de sesión como DataFrame
    session_summary_df = db.get_session_summary_data_as_dataframe(session_id)
    print("Session Summary Data DataFrame:")
    print(session_summary_df)
        

# Obtener datos de sesión como DataFrame
session_data_df = db.get_session_data_as_dataframe(session_id = None)
print("Session Data DataFrame:")
print(session_data_df)

# Obtener datos de sesión como DataFrame
session_data_df = db.get_session_data_as_dataframe(session_id = ['1', '2'])
print("Session Data DataFrame:")
print(session_data_df)

# Obtener todos los ID de sesión disponibles
session_ids = db.get_all_session_ids()
print("Session IDs:", session_ids)