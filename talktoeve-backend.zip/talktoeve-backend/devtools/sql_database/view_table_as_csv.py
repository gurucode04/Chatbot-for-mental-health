import pandas as pd
import sqlite3

# Conectarse a la base de datos
conn = sqlite3.connect('ruta/a/la/base/de/datos.db')

# Definir el nombre de la tabla que deseas convertir en DataFrame
tabla = 'NombreDeLaTabla'

# Leer la tabla en un DataFrame
df = pd.read_sql_query(f"SELECT * FROM {tabla}", conn)

# Mostrar el DataFrame
print(df)

# Cerrar la conexión
conn.close()
