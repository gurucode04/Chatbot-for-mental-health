import sqlite3
import numpy as np
import pandas as pd
import io
import os

class Study_Database:
    def __init__(self, db_name, study_dict={}, hparam_dict={}):

        self.db_name = db_name
        self.study_dict = study_dict
        self.hparam_dict = hparam_dict
        
        if not (f'{db_name}' in os.listdir()):
            self.create_tables()

        # Converts np.array to TEXT when inserting
        sqlite3.register_adapter(np.ndarray, self.adapt_array)
        # Converts TEXT to np.array when selecting
        sqlite3.register_converter("ARRAY", self.convert_array)
        # Converts TEXT to state dict when selecting
        sqlite3.register_converter("STATE_DICT", self.convert_state_dict)
        
    
    def isert_trial(self, trial_id, loss, datetime_start, datetime_complete, duration, study_dict):
        conn = sqlite3.connect(self.db_name, detect_types=sqlite3.PARSE_DECLTYPES)
        cur = conn.cursor()
        study_dict_keys = list(study_dict.keys())

        cur.execute("INSERT INTO trials(trial_id, loss, datetime_start, datetime_complete, duration) VALUES (?, ?, ?, ?, ?)", (trial_id, loss, datetime_start, datetime_complete, duration))
        # update study_dict keys
        for i in range(len(study_dict_keys)):
            cur.execute(f"UPDATE trials SET '{study_dict_keys[i]}' = ? WHERE trial_id = ?", (study_dict[study_dict_keys[i]], trial_id))
        
        conn.commit()
        conn.close()
    
    def insert_fold(self, trial_id, fold, loss, datetime_start, datetime_complete, duration, state_dict):
        conn = sqlite3.connect(self.db_name, detect_types=sqlite3.PARSE_DECLTYPES)
        cur = conn.cursor()
        cur.execute("INSERT INTO folds(trial_id, fold, loss, datetime_start, datetime_complete, duration, state_dict) VALUES (?, ?, ?, ?, ?, ?, ?)", (trial_id, fold, loss, datetime_start, datetime_complete, duration, self.adapt_array(state_dict)))
        
        conn.commit()
        conn.close()

    def insert_results(self, trial_id, fold, y_real, y_pred, compuesto1, compuesto2, set_, embeddings, compuestos_emb):
        conn = sqlite3.connect(self.db_name, detect_types=sqlite3.PARSE_DECLTYPES)
        cur = conn.cursor()
        cur.execute("INSERT INTO results(trial_id, fold, y_real, y_pred, compuesto1, compuesto2, set_, embeddings, compuestos_emb) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", (trial_id, fold, y_real, y_pred, compuesto1, compuesto2, set_, embeddings, compuestos_emb))
        
        conn.commit()
        conn.close()

    def trials_dataframe(self):
        conn = sqlite3.connect(self.db_name, detect_types=sqlite3.PARSE_DECLTYPES)
        df = pd.read_sql_query("SELECT * FROM trials", conn)
        conn.close()
        return df
    
    def folds_dataframe(self):
        conn = sqlite3.connect(self.db_name, detect_types=sqlite3.PARSE_DECLTYPES)
        df = pd.read_sql_query("SELECT (trial_id, fold, loss, datetime_start, datetime_complete, duration) FROM folds", conn)
        conn.close()
        return df
    
    def create_tables(self):
        study_dict_keys, study_dict_dtypes = self.transform_dict(self.study_dict)
        hparam_dict_keys, hparam_dict_dtypes = self.transform_dict(self.hparam_dict)

        conn = sqlite3.connect(self.db_name, detect_types=sqlite3.PARSE_DECLTYPES)
        cur = conn.cursor()
        
        # create trials table
        cur.execute("CREATE TABLE IF NOT EXISTS trials (trial_id INTEGER PRIMARY KEY, loss REAL, datetime_start TEXT, datetime_complete TEXT, duration TEXT)")
        # add study_dict keys to trials table
        for i in range(len(study_dict_keys)):
            cur.execute(f"ALTER TABLE trials ADD COLUMN '{study_dict_keys[i]}' {study_dict_dtypes[i]}")
        
        # create folds table
        cur.execute("CREATE TABLE IF NOT EXISTS folds (trial_id INTEGER, fold INTEGER, loss REAL, datetime_start TEXT, datetime_complete TEXT, duration TEXT, state_dict STATE_DICT)")
        
        # create hparams table
        cur.execute("CREATE TABLE IF NOT EXISTS hparams (hparam_id INTEGER PRIMARY KEY)")
        # add hparam_dict keys to hparams table
        for i in range(len(hparam_dict_keys)):
            cur.execute(f"ALTER TABLE hparams ADD COLUMN '{hparam_dict_keys[i]}' {hparam_dict_dtypes[i]}")
        # add hparam_dict values to hparams table
        cur.execute(f"INSERT INTO hparams VALUES (NULL, {', '.join(['?' for i in range(len(hparam_dict_keys))])})", tuple(self.hparam_dict.values()))
        
        # create results table
        cur.execute("CREATE TABLE IF NOT EXISTS results (trial_id INTEGER, fold INTEGER, y_real ARRAY, y_pred ARRAY, compuesto1 ARRAY, compuesto2 ARRAY, set_ ARRAY, embeddings ARRAY, compuestos_emb ARRAY)")
        conn.commit()
        conn.close()

    def transform_dict(self, dict_):
        dict_keys = list(dict_.keys())
        dict_dtypes = [type(dict_[key]) for key in dict_keys]
        # convert study_dict_dtype to a sqlite datatype
        for i, dtype in enumerate(dict_dtypes):
            if dtype == int:
                dict_dtypes[i] = 'INTEGER'
            elif dtype == float:
                dict_dtypes[i] = 'REAL'
            elif dtype == str or dtype == bool:
                dict_dtypes[i] = 'TEXT'
            else:
                raise TypeError('Unsupported data type')
        return dict_keys, dict_dtypes
    
    def adapt_array(self, arr):
        out = io.BytesIO()
        np.save(out, arr)
        out.seek(0)
        return sqlite3.Binary(out.read())

    def convert_array(self, text):
        out = io.BytesIO(text)
        out.seek(0)
        return np.load(out)
    
    def convert_state_dict(self, text):
        out = io.BytesIO(text)
        out.seek(0)
        return np.load(out, allow_pickle=True).item()
