import os 
import sys
import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

current_dir = os.path.dirname(os.path.realpath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)

from modules.databases_sql.databases import SurveyDatabase

surveydb = SurveyDatabase()
survey_id = 0

df = surveydb.get_survey_responses(survey_id)

a = 20



