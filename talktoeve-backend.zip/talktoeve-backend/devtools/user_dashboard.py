import pandas as pd
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.databases_sql.databases import UserDatabase

path = os.path.join(parent_dir,'users','test_user','test_user.db')
user_db = UserDatabase(path=path)

attt ={ "start_filter_date": "2023-01-01",
        "end_filter_date": "2025-01-01",
        "aggregate": True,
        "wheited": False,
        "last_session": True,}
dict_ = user_db.get_user_dashboard(**attt)

import json
# Save the dictionary as .json
path = os.path.join(parent_dir,'users','test_user','test_user_dashboard.json')
json_data = json.dumps(dict_, indent=4)
with open(path, 'w') as json_file:
    json_file.write(json_data)
a = 20