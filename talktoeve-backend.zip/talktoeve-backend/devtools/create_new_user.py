import os 
import sys

current_dir = os.path.dirname(os.path.realpath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)

from modules.users_manager.user_manager import UserManager_v1


usermanager = UserManager_v1()

personal_info = {'username': 'ChuckBOT',
                'user_id': '001',
                'name': 'Chuck',
                'birthday': '1980-01-01',
                'nationality': 'Norwegian',
                'location': 'Oslo',
                'position': 'Engineer',
                'area': 'Engineering',
                'vessel': 'Norwegian Spirit',
                'shift': 'Day',
                'experience': '10',
                'studies': 'Engineering',}

usermanager.create_edit_user(personal_info=personal_info)

usermanager = UserManager_v1()

personal_info = {'username': 'TataBOT',
                'user_id': '002',
                'name': 'Tata',
                'birthday': '1970-01-01',
                'nationality': 'Egipcian',
                'location': 'El Cairo',
                'position': 'Machine Operator',
                'area': 'Engineering',
                'vessel': 'Norwegian Spirit',
                'shift': 'Night',
                'experience': '15',
                'studies': 'Engineering',}

usermanager.create_edit_user(personal_info=personal_info)

usermanager = UserManager_v1()

personal_info = {'username': 'LuisBOT',
                'user_id': '003',
                'name': 'Luis',
                'birthday': '1990-01-01',
                'nationality': 'Swedish',
                'location': 'Stockholm',
                'position': 'Officer',
                'area': 'Navigation',
                'vessel': 'La Linda',
                'shift': 'Day',
                'experience': '5',
                'studies': 'Navigation',}

usermanager.create_edit_user(personal_info=personal_info)


usermanager = UserManager_v1()
personal_info = {'username': 'TitiBOT',
                'user_id': '004',
                'name': 'Titi',
                'birthday': '1980-01-01',
                'nationality': 'Spanish',
                'location': 'Madrid',
                'position': 'Machine Operator',
                'area': 'Engineering',
                'vessel': 'La Linda',
                'shift': 'Night',
                'experience': '10',
                'studies': 'Engineering',}

usermanager.create_edit_user( personal_info=personal_info)



