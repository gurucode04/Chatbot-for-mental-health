import sys
import os
import numpy as np
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
grandparent_dir = os.path.dirname(parent_dir)
sys.path.append(parent_dir)
sys.path.append(grandparent_dir)

from modules.eve import Eve
from modules.global_configs import OPENAI_API_KEY
from openai import OpenAI

client = OpenAI(api_key=OPENAI_API_KEY)

users = ['ChuckBOT', 'TataBOT', 'TitiBOT', 'LuisBOT']
prompts = ["Your role as an assistant is to respond to the questions you'll have with Eve, your therapist. In order to answer them, you need to embody ChuckBOT, a sailor who works as an officer in the machinery department of the ship Margarita. You've been an employee for 10 years and are currently experiencing isolation, family separation, and adverse working conditions that are causing stress and affecting you professionally.",
    'Your role as TataBOT is to engage in therapeutic conversations with Eve, your virtual counselor. As Tata, an experienced engineer at PGI (PETROLEO Y GAS ETX), you work on specialized equipment maintenance aboard ice-class vessels in the Arctic. With a decade of service, you are currently grappling with the challenges of extreme weather conditions, extended work hours, and the constant struggle to balance work and personal life. Share your experiences, concerns, and seek guidance on how to cope with the unique pressures faced by offshore engineers in the Arctic region.',
    "Embrace the persona of TitiBOT, a dynamic member of PGI's offshore team. Titi, a navigation officer, has devoted 10 years to navigating through the icy waters of the Arctic on vessels like the Margarita. As TitiBOT, discuss the isolation, separation from family, and the mental toll of constantly adapting to unpredictable Arctic conditions. Dive into conversations with Eve, your virtual therapist, to explore coping mechanisms, emotional well-being, and strategies to maintain resilience in the face of demanding maritime challenges.",
    "Step into the shoes of LuisBOT, embodying the role of Luis, a dedicated technician in PGI's oil and gas exploration team. Luis has spent a decade managing intricate machinery on Arctic vessels, dealing with the isolation, separation from loved ones, and the intense work environment. Engage with Eve, your therapeutic partner, to discuss the impact of these challenges on your mental health, seek advice on maintaining a healthy work-life balance, and explore ways to thrive in the unique working conditions of PGI."
]

for it in range(4):
    # Initialize Eve
    nsessions = 8
    user = users[it]
    prompt = prompts[it]
    for session in range(nsessions):
        eve = Eve()
        eve.initialize(username=user)

        messages_stack = []
        system_messages = {"role": "system", 
                        "content": f"{prompt}"}
        messages_stack.append(system_messages)
        bot_message = ""
        n_messages = 20
        for it in range(n_messages):
            if it == 0:
                eve_message = {'role':'user',
                            'content' : f'Eve: Hi {user}, I am Eve your therapist. How are you feeling today?'}
                print(f"{eve_message['content']}")
                messages_stack.append(eve_message)
                
                response = client.chat.completions.create(
                model="gpt-3.5-turbo-1106",
                messages=messages_stack,
                )
                bot_message = response.choices[0].message.content
                print(f"Bot:{bot_message}")
                messages_stack.append({'role':'assistant','content':bot_message})
            else:
                
                response_dict = eve.response(bot_message, audio_flag=False, audio_response_flag = False)
                
                # Here we need to verify if survey is None or not
                if response_dict['survey'] is not None:
                    print(f"Survey: {response_dict['survey']}")
                    survey_id = response_dict['survey']['survey_id']
                    question_id = response_dict['survey']['question_id']
                    answer_id = np.random.choice(range(len(response_dict['survey']['answers'])))
                    response = {'username': user,'survey_id': survey_id, 'response': {question_id,answer_id}}
                    eve.user_manager.database.insert_survey_response(response)
                    
                if response_dict['eve_message'] is not None:
                    eve_message = {'role':'user',
                                'content' : f'Eve: {response_dict["eve_message"]}'}
                
                    print(f"{eve_message['content']}")
                    messages_stack.append(eve_message)
                    
                    response = client.chat.completions.create(
                    model="gpt-3.5-turbo-1106",
                    messages=messages_stack,
                    )
                    bot_message = response.choices[0].message.content
                    print(f"Bot:{bot_message}")
                    messages_stack.append({'role':'assistant','content':bot_message})
            
        eve.finalize()        
    
    
    
    
    
