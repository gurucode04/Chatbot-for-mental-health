# Introduction 
Eve represents an intelligent chatbot system meticulously crafted to address the primary objective of mitigating stress and anxiety levels while proactively combatting burnout. As a sophisticated conversational agent, Eve harnesses advanced natural language processing (NLP) algorithms to facilitate meaningful engagements with users. 

<br>

# Running the backend using docker

1. Building the image locally: `docker build -t backend:latest .`

2. Running the image locally: `docker run -e LOCAL=1 -p 8000:8000 backend:latest`
    
    When the backend container is up & running, you are able to access the API documentation on http://localhost:8000/docs

<br>

---

<br>

2. To run the application in default mode (exposed to all network interfaces): `docker run -p 8000:8000 tte_image`

<br>

# Testing the backend using docker

1. `docker run -e RUN_TESTS=1 backend:latest`

<br>

## API references

See the api.md file in documents/documentation.
For more see docs.md

## Contribute
TODO: Explain how other users and developers can contribute to make your code better. 
